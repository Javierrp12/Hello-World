import React, { ChangeEvent } from 'react';
import i18n from '../i18n/i18n';
import { Link } from 'react-router-dom';
import { Default } from '../Datastore/StateData/userLevelTypes';
import { eq, deq } from '../CommonFunctions/pointfreeUtilities';
import { languageSelection } from '../CommonFunctions/functionsSupport';
import Tooltip from "@reach/tooltip";
import './header.css';
import "@reach/tooltip/styles.css";

interface IHeaderProps {
  userLevel: string;
  date: string;
  isOnline: boolean;
  hostname: string;
  t: (word: string) => string;
  logoutCallback: () => void;
  updateShowloginStatusCallback: () => void;
}

export class Header extends React.Component<IHeaderProps> {

  render() {
    const { t, updateShowloginStatusCallback, logoutCallback } = this.props;
    const { isOnline, userLevel, date, hostname } = this.props;

    return (
      <React.Fragment>
        <header className='navbar navbar-expand d-flex justify-content-between bd-navbar p-0'>
          <div className="d-flex flex-column" data-cy="date-time-header">
            <label className='m-0 mr-2 ml-2'>{t('DeviceTime')} (UTC)</label>
            <label className='m-0 mr-2 ml-2'>{date}</label>
          </div>
          <div>
            <div className="d-flex justify-content-start" data-cy='status-header'>
              <div className={'connected-icon'}></div>
              <label className='m-0 mr-2 ml-2'>{t('Status')}: {isOnline ? 'Online' : 'Offline'}</label>
            </div>
          </div>
          <Link to='/' className='navbar-brand-ptdiag mr-2 ml-2 text-dark' data-cy='device-name-header'>{hostname}</Link>
          <div className='navbar-brand m-0 mr-2 ml-2 PowerTech-Logo' data-cy='logo-header'></div>
          <div className="form-group mx-sm-1" data-cy='language-selector-header-parent'>
            <label htmlFor="languageFormControlSelect" className=' m-0 mr-2 ml-2'>{t('Language')}</label>
            <select className="form-control form-control-sm" id="languageFormControlSelect" value={languageSelection(i18n.language)} onChange={this.handleLanguageChanged} data-cy='language-selector-header'>
              <option value='en'>English</option>
              <option value='de'>Deutsch</option>
            </select>
          </div>
          <div>
            <div className="d-flex justify-content-start" data-cy='user-header-parent'>
              {((eq(isOnline, true)) && (eq(userLevel, Default))) &&
                <div className='mr-2 ml-2'>
                  <Tooltip label={t('Log in')} style={{
                    background: "hsla(0, 0%, 0%, 0.75)",
                    color: "white",
                    border: "none",
                    borderRadius: "4px",
                    padding: "0.5em 1em",
                  }}>
                    <button className='btn btn-outline-dark user-icon-background' onClick={updateShowloginStatusCallback} data-cy='user-login-header'><i className="fas fa-user fa-lg"></i></button>
                  </Tooltip>
                </div>
              }
              {((deq(userLevel, Default)) && (eq(isOnline, true))) &&
                <div className='mr-2 ml-2'>
                  <Tooltip label={t('Log out')} style={{
                    background: "hsla(0, 0%, 0%, 0.75)",
                    color: "white",
                    border: "none",
                    borderRadius: "4px",
                    padding: "0.5em 1em",
                  }}>
                    <button className='btn btn-outline-dark ml-2 logout-icon-background' onClick={logoutCallback} data-cy='user-logout-button'><i className="fas fa-sign-out-alt fa-lg"></i></button>
                  </Tooltip>
                </div>
              }
              <label className='mr-4 ml-2'>{t('User')}: {userLevel}</label>
            </div>
          </div>
        </header>
      </React.Fragment >
    );
  }

  private handleLanguageChanged = (event: ChangeEvent<HTMLSelectElement>): void => {
    i18n.changeLanguage(event.target.value);
  }

}
