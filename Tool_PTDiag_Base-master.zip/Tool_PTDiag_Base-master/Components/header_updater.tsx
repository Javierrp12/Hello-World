import React, { ChangeEvent } from 'react';
import i18n from '../i18n/i18n';
import { Link } from 'react-router-dom';
import { languageSelection } from '../CommonFunctions/functionsSupport';
import './header.css';

interface IHeaderProps {
  userLevel: string;
  isOnline: boolean;
  hostname: string;
  t: (word: string) => string;
}

export class Header extends React.Component<IHeaderProps> {

  render() {
    const { t } = this.props;
    const { isOnline, userLevel,hostname } = this.props;

    return (
      <React.Fragment>
        <header className='navbar navbar-expand d-flex justify-content-between bd-navbar p-0'>
          <div>
            <div className="d-flex justify-content-start" data-cy='status-header'>
              <div className={'connected-icon'}></div>
              <label className='m-0 mr-2 ml-2'>{t('Status')}: {isOnline ? 'Online' : 'Offline'}</label>
            </div>
          </div>
          <Link to='/' className='navbar-brand-ptdiag mr-2 ml-2 text-dark' data-cy='device-name-header'>{hostname}</Link>
          <div className='navbar-brand m-0 mr-2 ml-2 PowerTech-Logo' data-cy='logo-header'></div>
          <div className="form-group mx-sm-1" data-cy='language-selector-header-parent'>
            <label htmlFor="languageFormControlSelect" className=' m-0 mr-2 ml-2'>{t('Language')}</label>
            <select className="form-control form-control-sm" id="languageFormControlSelect" value={languageSelection(i18n.language)} onChange={this.handleLanguageChanged} data-cy='language-selector-header'>
              <option value='en'>English</option>
              <option value='de'>Deutsch</option>
            </select>
          </div>
          <div>
            <div className="d-flex justify-content-start" data-cy='user-header-parent'>
              <div className='mr-2 ml-2'>
                <button className='btn btn-outline-dark user-icon-background' data-cy='user-login-header'><i className="fas fa-user fa-lg"></i></button>
              </div>
              <label className='mr-4 ml-2'>{t('User')}: {userLevel}</label>
            </div>
          </div>
        </header>
      </React.Fragment >
    );
  }

  private handleLanguageChanged = (event: ChangeEvent<HTMLSelectElement>): void => {
    i18n.changeLanguage(event.target.value);
  }

}
