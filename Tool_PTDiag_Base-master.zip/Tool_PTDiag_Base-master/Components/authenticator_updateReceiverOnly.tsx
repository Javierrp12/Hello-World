import React from 'react';
import { eq, deq, safeProp } from '../CommonFunctions/pointfreeUtilities';
import { getRequestDelay, safeObjectSearch } from '../CommonFunctions/functionsSupport';

interface IAuthenticatorProps {
  hostname: string;
  updateUnauthorizedCallback: (authorized: boolean) => void;
}

interface IAuthenticatorState {
  errorMessage: null | string;
}

interface ICredentials {
  user: string;
  password: string;
}

export class Authenticator extends React.Component<IAuthenticatorProps, IAuthenticatorState> {
  constructor(props: IAuthenticatorProps) {
    super(props);
    this.state = {
      errorMessage: null
    }
  }

  render() {
    const { hostname } = this.props;
    const { errorMessage } = this.state;

    return (
      <React.Fragment>
        <header className='navbar navbar-expand d-flex justify-content-center bd-navbar p-0'>
          <div className='navbar-brand-ptdiag mr-4 ml-2 text-dark'>{hostname}</div>
          <div className='navbar-brand m-0 mr-2 ml-4 PowerTech-Logo'></div>
        </header>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col m-2'>
              <div className='d-flex align-items-center flex-column col'>
                {deq(errorMessage, null) &&
                  <h4 className='text-center m-1 p-2 text-danger'>
                    {errorMessage}
                  </h4>
                }
              </div>
            </div>
          </div>
        </div>
      </React.Fragment >
    );
  }

  componentDidMount() {
    /* Try to login */
    this.authenticate({ user: 'Default', password: '' }, 100, this.props.updateUnauthorizedCallback);
  }

  private authenticate = (credentials: ICredentials, delayTime: number, updateUnauthorizedCallback: (authorized: boolean) => void): void => {
    const retry = () => {
      setInterval(() => {
        this.authenticate(credentials, delayTime, updateUnauthorizedCallback);
      }, 1000);
    }
    const url = `/api/v1/login?user=${credentials.user}&password=${credentials.password}`;
    getRequestDelay(url, delayTime).run().listen({
      onRejected: (error: any) => {
        const NotFound = 404;
        const TooManyRequests = 429;
        if (eq(safeProp('response', error).getOrElse(), undefined)) {
          /* Target Disconnected */
          return this.setState({ errorMessage: error.toString() });
        }

        if (eq(safeObjectSearch('response.status', error).getOrElse(0), NotFound)) {
          /* Error in request -> Server Error */
          this.setState({ errorMessage: 'Error in Request' });
        }

        if (eq(safeObjectSearch('response.status', error).getOrElse(0), TooManyRequests)) {
          /* Already logged, stop trying to reconnect. */
          return;
        }

        return retry();
      },
      onResolved: () => {
        updateUnauthorizedCallback(true);
      }
    });
  }

}
