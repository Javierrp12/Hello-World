import React from 'react';
import { Modules } from '../../Datastore/ModelData/modulesTypes';
import { IModulesState } from '../../Datastore/InitialDataInterfaces';
import { safeGetValuesObject } from '../../CommonFunctions/functionsSupport';
import { safeProp } from '../../CommonFunctions/pointfreeUtilities';
import './modulesTab.css';

interface IModulesTabProps {
  activeModule: keyof typeof Modules;
  modulesState: IModulesState;
  handleClickCallback: (moduleName: keyof typeof Modules) => void;
}

export class ModulesTab extends React.Component<IModulesTabProps> {

  render() {
    const { activeModule, modulesState } = this.props;
    const { handleClickCallback } = this.props;
    const modules = safeGetValuesObject(Modules).getOrElse([]);

    if (modules.length === 0) {
      return <div>No modules has been configured</div>;
    }

    return (
      <div className='d-flex justify-content-end' data-cy={'module-tabs'}>
        {modules.map((module: string) => (
          <button
            key={module}
            className={`btn btn-ptdiag pl-4 pr-4 ${(module === activeModule) ? 'active' : ''}`}
            onClick={() => handleClickCallback(module as keyof typeof Modules)}>
            {module}
            < small className={`square bg-${safeProp(module, modulesState).getOrElse('none')}`} ></small>
          </button >
        ))}
      </div >
    );
  }

}
