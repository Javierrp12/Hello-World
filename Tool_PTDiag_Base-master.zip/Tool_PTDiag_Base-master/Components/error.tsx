import React from 'react';
import { ModalWindow } from '../Components/Views/modalWindow';
import { IErrorInfo } from '../Datastore/ErrorData/errorActionCreator';
import { safeProp } from '../CommonFunctions/pointfreeUtilities';
import './error.css';

interface IErrorModalProps {
  errorInfo: IErrorInfo;
  t: (word: string) => string;
  closeErrorModalCallback: () => void;
}

export class ErrorModal extends React.Component<IErrorModalProps> {

  render() {
    const { t, closeErrorModalCallback } = this.props;
    const { errorInfo } = this.props;

    return (
      <ModalWindow>
        <div className='modal-ptdiag'>
          <div className='modal-dialog modal-dialog-centered'>
            <div className='modal-content'>
              <div className='modal-header errorSymbol' data-cy='modal-title'>
                <div className='display-view-title pl-4'>{t('Error in Request')}</div>
                <button className='close' onClick={closeErrorModalCallback}><span>x</span></button>
              </div>
              <div className='modal-body' data-cy='modal-content'>
                <div className='display-error-subtitel'>{safeProp('error', errorInfo).getOrElse('')}</div>
              </div>
              <div className='modal-footer' data-cy='modal-buttons'>
                <button className='btn btn-secondary m-2' onClick={closeErrorModalCallback}>{t('Close')}</button>
              </div>
            </div>
          </div>
        </div>
      </ModalWindow >
    );
  }
}