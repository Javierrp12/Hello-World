import React, { ChangeEvent } from 'react';
import i18next from 'i18next';
import { handleRedirect } from '../CommonFunctions/commonFunctions';
import { eq, deq, safeProp, chain } from '../CommonFunctions/pointfreeUtilities';
import { getRequestDelay, safeObjectSearch, checkRequestResult } from '../CommonFunctions/functionsSupport';
import { ViewTypes } from '../Datastore/ModelData/viewTypes';

const compose = require('folktale/core/lambda/compose');

interface IAuthenticatorProps {
  showLogin: boolean;
  hostname: string;
  redirectToUpdate: (infoData: string) => void;
  updateShowloginStatusCallback: () => void;
}

interface IAuthenticatorState {
  userlevel: string;
  password: string;
  errorMessage: null | string;
}

interface ICredentials {
  user: string;
  password: string;
}

export class Authenticator extends React.Component<IAuthenticatorProps, IAuthenticatorState> {
  constructor(props: IAuthenticatorProps) {
    super(props);
    this.state = {
      userlevel: 'Service',
      password: '',
      errorMessage: null
    };
  }

  render() {
    const { showLogin, hostname } = this.props;
    const { updateShowloginStatusCallback, redirectToUpdate } = this.props;
    const { userlevel, password, errorMessage } = this.state;

    return (
      <React.Fragment>
        <header className="navbar navbar-expand d-flex justify-content-center bd-navbar p-0">
          <div className="navbar-brand-ptdiag mr-4 ml-2 text-dark">{hostname}</div>
          <div className="navbar-brand m-0 mr-2 ml-4 PowerTech-Logo"></div>
        </header>
        <div className="container-fluid">
          <div className="row">
            <div className="col m-2">
              {eq(showLogin, true) && (
                <button className="btn btn-secondary" onClick={updateShowloginStatusCallback}>
                  {i18next.t('Back')}
                </button>
              )}
              <div className="d-flex align-items-center flex-column col">
                {deq(errorMessage, null) && <h4 className="text-center m-1 p-2 text-danger">{errorMessage}</h4>}
                {eq(showLogin, true) && (
                  <React.Fragment>
                    <form className="col-6 col-md-5 col-lg-4 col-xl-3" onSubmit={(event) => this.handleSubmit(event, userlevel, password, showLogin, updateShowloginStatusCallback, redirectToUpdate)}>
                      <div className="form-group">
                        <label htmlFor="userlevelFormControlSelect">{i18next.t('UserLevel')}</label>
                        <select className="form-control" id="userlevelFormControlSelect" name="userlevel" value={userlevel} onChange={this.handleUserlevelChange}>
                          <option value="Service">{i18next.t('Service')}</option>
                          <option value="PTService">{i18next.t('PTService')}</option>
                        </select>
                      </div>
                      <div className="form-group">
                        <label htmlFor="inputPassword">{i18next.t('Password')}</label>
                        <input type="password" className="form-control" id="inputPassword" name="password" value={password} onChange={this.handlePasswordChanged} required autoComplete="on" />
                      </div>
                      <div className="text-center">
                        <button className="btn btn-ptdiag" type="submit">
                          {i18next.t('Login')}
                        </button>
                      </div>
                    </form>
                  </React.Fragment>
                )}
                {eq(showLogin, false) && (
                  <React.Fragment>
                    <div className="display-view-title">{i18next.t('Loading App')}</div>
                    <div className="spinner-border text-ptdiag mt-5" role="status"></div>
                  </React.Fragment>
                )}
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }

  componentDidMount() {
    if (eq(this.props.showLogin, false)) {
      /* Try to login */
      this.authenticate({ user: 'Default', password: '' }, 100, this.props.showLogin, this.props.updateShowloginStatusCallback, this.props.redirectToUpdate);
    }
  }

  private handleUserlevelChange = (event: ChangeEvent<HTMLSelectElement>): void => {
    this.setState({ userlevel: event.target.value });
  };

  private handlePasswordChanged = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ password: event.target.value });
  };

  private handleSubmit = (event: React.FormEvent<HTMLFormElement>, user: string, password: string, showLogin: boolean, updateShowloginStatusCallback: () => void, redirectToUpdate: (infoData: string) => void) => {
    event.preventDefault();
    this.authenticate({ user, password }, 1000, showLogin, updateShowloginStatusCallback, redirectToUpdate);
  };

  private authenticate = (credentials: ICredentials, delayTime: number, showLogin: boolean, updateShowloginStatusCallback: () => void, redirectToUpdate: (infoData: string) => void): void => {
    const retry = () => {
      setInterval(() => {
        this.authenticate(credentials, delayTime, showLogin, updateShowloginStatusCallback, redirectToUpdate);
      }, 1000);
    };
    const url = `/api/v1/login?user=${credentials.user}&password=${credentials.password}`;
    getRequestDelay(url, delayTime)
      .run()
      .listen({
        onRejected: (error: any) => {
          const NotFound = 404;
          const TooManyRequests = 429;
          if (eq(safeProp('response', error).getOrElse(), undefined)) {
            /* Target Disconnected */
            return this.setState({ errorMessage: error.toString() });
          }

          if (eq(safeObjectSearch('response.status', error).getOrElse(0), NotFound)) {
            /* Error in request -> Server Error */
            this.setState({ errorMessage: 'Error in Request' });
          }

          if (eq(safeObjectSearch('response.status', error).getOrElse(0), TooManyRequests)) {
            /* Already logged, stop trying to reconnect. */
            return;
          }

          if (eq(showLogin, true)) {
            return this.setState({ errorMessage: 'Invalid Credentials' });
          }

          return retry();
        },
        onResolved: (data: any) => {
          const getRequestResultCode = safeObjectSearch('data.result.code');
          const getRequestResult = safeObjectSearch('data.result');
          const getResultsData = safeObjectSearch('data');
          const getRequestData = compose(chain(checkRequestResult(getRequestResult(data).getOrElse({}), getResultsData(data).getOrElse({}))), getRequestResultCode);

          getRequestData(data).matchWith({
            Ok: () => {
              return eq(showLogin, true) ? updateShowloginStatusCallback() : this.requestMUStatus(redirectToUpdate);
            },
            Error: (error: any) => {
              const errorInformation = error.merge();
              return this.setState({ errorMessage: `${safeProp('code', errorInformation).getOrElse('')} - ${safeProp('info', errorInformation).getOrElse('')}` });
            }
          });
        }
      });
  };

  private requestMUStatus = (redirectToUpdate: (infoData: string) => void) => {
    const getRequestResultCode = safeObjectSearch('data.result.code');
    const getRequestResult = safeObjectSearch('data.result');
    const getResultsData = safeObjectSearch('data');

    getRequestDelay('/api/v1/getAppInfo', 1000)
      .run()
      .listen({
        onRejected: () => this.setState({ errorMessage: 'Error in request' }),
        onResolved: (data: any) => {
          const getRequestData = compose(chain(checkRequestResult(getRequestResult(data).getOrElse({}), getResultsData(data).getOrElse({}))), getRequestResultCode);
          getRequestData(data).matchWith({
            Ok: (dataRequest: any) => {
              const requestData = dataRequest.merge();
              const getFormerlyCrashed = safeObjectSearch('data.muAppDetection.formerlyCrashed');
              const getMUStatus = safeObjectSearch('data.muAppDetection.started');
              const getMUReady = safeObjectSearch('data.muAppDetection.ready');
              return eq(getFormerlyCrashed(requestData).getOrElse(true), false) && eq(getMUStatus(requestData).getOrElse(false), true)
                ? eq(getMUReady(requestData).getOrElse(false), true)
                  ? handleRedirect(ViewTypes.SystemOverview)
                  : this.requestMUStatus(redirectToUpdate)
                : eq(getMUStatus(requestData).getOrElse(false), true)
                ? redirectToUpdate('The MU-App is not running at the moment.')
                : redirectToUpdate('The MU-App has shown some problems.');
            },
            Error: () => this.setState({ errorMessage: 'Error in request' })
          });
        }
      });
  };
}
