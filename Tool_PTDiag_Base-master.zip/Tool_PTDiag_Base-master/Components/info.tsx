import React from 'react';
import { ModalWindow } from '../Components/Views/modalWindow';
import './info.css';

interface IInfoModalProps {
  info: string;
  t: (word: string) => string;
  closeInfoModalCallback: () => void;
}

export class InfoModal extends React.Component<IInfoModalProps> {

  render() {
	const { t, closeInfoModalCallback } = this.props;
    const { info } = this.props;

    return (
      <ModalWindow>
        <div className='modal-ptdiag'>
          <div className='modal-dialog modal-dialog-centered'>
            <div className='modal-content'>
              <div className='modal-header infoSymbol' data-cy='modal-title'>
                <div className='display-view-title pl-4'>Info</div>
                <button className='close' onClick={closeInfoModalCallback}><span>x</span></button>
              </div>
              <div className='modal-body' data-cy='modal-content'>
                <div className='display-error-subtitle'>{info}</div>
              </div>
              <div className='modal-footer' data-cy='modal-buttons'>
                <button className='btn btn-secondary m-2' onClick={closeInfoModalCallback}>{t('Close')}</button>
              </div>
            </div>
          </div>
        </div>
      </ModalWindow >
    );
  }
}
