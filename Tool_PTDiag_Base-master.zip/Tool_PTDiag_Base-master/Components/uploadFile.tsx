import React from 'react';
import i18next from 'i18next';

interface IUploadFileProps {
  uploadFileStatus: string;
  hostname: string;
  getDateTimeCallback: () => void;
}

export class UploadFile extends React.Component<IUploadFileProps> {
  timerOnlineDataId: number | undefined;

  render() {
    const { uploadFileStatus, hostname } = this.props;

    return (
      <React.Fragment>
        <header className='navbar navbar-expand d-flex justify-content-center bd-navbar p-0' data-cy='header-uploadFile'>
          <div className='navbar-brand-ptdiag mr-4 ml-2 text-dark'>{hostname}</div>
          <div className='navbar-brand m-0 mr-2 ml-4 PowerTech-Logo'></div>
        </header>
        <div className='container'>
          <div className='row'>
            <div className='col text-center'>
              <div className='mt-5'>
                <div className='display-view-title' data-cy='view-title'>{i18next.t(uploadFileStatus)}</div>
                <div className="spinner-border text-ptdiag mt-5" role="status"></div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }

  componentWillUnmount() {
    clearInterval(this.timerOnlineDataId);
  }

}