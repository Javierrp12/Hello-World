import React from 'react';

interface IDataProps {
  name: string;
  view: string;
  userLevel: string;
}

export class Data extends React.Component<IDataProps> {

  render() {
    return null;
  }
}