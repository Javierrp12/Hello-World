import React from 'react';
import { ButtonRouting } from '../RoutingComponents/routingbutton';
import './navegation.css';

interface INavegationProps {
  routes: IChildRoutes[];
}

interface IChildRoutes {
  name: string;
  url: string;
  view: string;
}

export class Navegation extends React.Component<INavegationProps> {

  render() {
    const { routes } = this.props;

    return (
      <ul className='nav nav-tabs nav-fill' data-cy="navegationBar-parent">
        {routes.map((item) => {
          return (
            <ButtonRouting key={item.url} to={item.url} exact={false} view={item.view}>{item.name}</ButtonRouting>
          )
        })}
      </ul>
    );
  }
}