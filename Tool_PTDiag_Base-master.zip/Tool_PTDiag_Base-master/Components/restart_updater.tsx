import React, { Component } from 'react';
import i18next from 'i18next';
import { handleRedirectToUpdateReceiver } from '../../Base/CommonFunctions/commonFunctions';
import { chain } from '../../Base/CommonFunctions/pointfreeUtilities';
import { maybeA, restartProcess, safeObjectSearch } from '../../Base/CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface IRestartProps {
  hostname: string;
}

export class Restart extends Component<IRestartProps> {

  render() {
    const { hostname } = this.props;

    this.handleRestartProcess();
    return (
      <React.Fragment>
        <header className='navbar navbar-expand d-flex justify-content-center bd-navbar p-0' data-cy='header-restart'>
          <div className='navbar-brand-ptdiag mr-4 ml-2 text-dark'>{hostname}</div>
          <div className='navbar-brand m-0 mr-2 ml-4 PowerTech-Logo'></div>
        </header>
        <div className='container'>
          <div className='row'>
            <div className='col text-center'>
              <div className='mt-5'>
                <div className='display-view-title' data-cy='view-title'>{i18next.t('Restarting system')}</div>
                <div className="spinner-border text-ptdiag mt-5" role="status"></div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }

  componentDidMount() {
    this.handleRestartProcess();
  }

  private handleRestartProcess = () => {
    const retry = () => {
      setTimeout(() => {
        this.handleRestartProcess();
      }, 5000)
    }

    const getHost = compose(chain(safeObjectSearch('location.hostname')), maybeA);
    restartProcess(`https://${getHost(window).getOrElse('')}`, 5000).run().listen({
      onRejected: () => {
        retry();
      },
      onResolved: () => handleRedirectToUpdateReceiver()
    });
  }

}