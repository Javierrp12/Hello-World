import React from 'react';
import i18next from "i18next";
import { handleRedirectToUpdateReceiver } from '../CommonFunctions/commonFunctions';
import { chain, map, eq, safeProp } from '../CommonFunctions/pointfreeUtilities';
import { restartProcess, maybeA, safeObjectSearch, reloadWindow } from '../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface IRestartProps {
  option: string;
  hostname: string;
}

export class Restart extends React.Component<IRestartProps> {

  render() {
    const restartOption = (option: string) => {
      const restartOptions = {
        'rebootSystem': 'Restarting system',
        'restartApp': 'Restarting App',
        'terminateApp': 'App stopped'
      }
      return safeProp(option, restartOptions);
    }

    const { option, hostname } = this.props;

    return (
      <React.Fragment>
        <header className='navbar navbar-expand d-flex justify-content-center bd-navbar p-0' data-cy='header-restart'>
          <div className='navbar-brand-ptdiag mr-4 ml-2 text-dark'>{hostname}</div>
          <div className='navbar-brand m-0 mr-2 ml-4 PowerTech-Logo'></div>
        </header>
        <div className='container'>
          <div className='row'>
            <div className='col text-center'>
              <div className='mt-5'>
                <div className='display-view-title' data-cy='view-title'>{i18next.t(restartOption(option).getOrElse(''))}</div>
                {!eq(option, 'terminateApp') &&
                  <div className="spinner-border text-ptdiag mt-5" role="status"></div>
                }
                {eq(option, 'terminateApp') &&
                  <div className="text-primary mt-5">
                    <button className='btn btn-ptdiag m-2' onClick={handleRedirectToUpdateReceiver}>{i18next.t('Redirect to Update Receiver')}</button>
                  </div>
                }
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }

  componentDidMount() {
    this.handleRestartProcess();
  }

  handleRestartProcess = () => {
    const retry = () => {
      setTimeout(() => {
        this.handleRestartProcess();
      }, 5000)
    }
    const getHost = compose(chain(safeObjectSearch('location.host')), maybeA);
    const getReload = compose(compose(map(reloadWindow), chain(safeProp('location'))), maybeA);
    const url = `https://${getHost(window).getOrElse('')}`;

    restartProcess(url, 2000).run().listen({
      onRejected: () => {
        retry();
      },
      onResolved: () => getReload(window)
    });
  }

}