import React, { ChangeEvent } from 'react';
import i18next from 'i18next';
import { chain, eq, safeProp } from '../CommonFunctions/pointfreeUtilities';
import { getRequestDelay, safeObjectSearch, checkRequestResult } from '../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface IAuthenticatorProps {
  showLogin: boolean;
  hostname: string;
  updateShowloginStatusCallback: () => void;
  updateUnauthorizedCallback: (authorized: boolean) => void;
}

interface IAuthenticatorState {
  userlevel: string;
  password: string;
  errorMessage: null | string;
}

interface ICredentials {
  user: string;
  password: string;
}

export class Authenticator extends React.Component<IAuthenticatorProps, IAuthenticatorState> {
  constructor(props: IAuthenticatorProps) {
    super(props);
    this.state = {
      userlevel: 'Service',
      password: '',
      errorMessage: null
    };
  }

  render() {
    const { showLogin, hostname } = this.props;
    const { updateShowloginStatusCallback, updateUnauthorizedCallback } = this.props;
    const { userlevel, password, errorMessage } = this.state;

    return (
      <React.Fragment>
        <header className="navbar navbar-expand d-flex justify-content-center bd-navbar p-0" data-cy="header-login">
          <div className="navbar-brand-ptdiag mr-4 ml-2 text-dark">{hostname}</div>
          <div className="navbar-brand m-0 mr-2 ml-4 PowerTech-Logo"></div>
        </header>
        <div className="container-fluid">
          <div className="row">
            <div className="col m-2">
              {eq(showLogin, true) && (
                <button className="btn btn-secondary" onClick={updateShowloginStatusCallback} data-cy="back-button-login">
                  {i18next.t('Back')}
                </button>
              )}
              <div className="d-flex align-items-center flex-column col">
                {errorMessage !== null && (
                  <h4 className="text-center m-1 p-2 text-danger" data-cy="error-msg-login">
                    {errorMessage}
                  </h4>
                )}
                {eq(showLogin, true) && (
                  <React.Fragment>
                    <form className="col-6 col-md-5 col-lg-4 col-xl-3" onSubmit={(event) => this.handleSubmit(event, userlevel, password, showLogin, updateShowloginStatusCallback, updateUnauthorizedCallback)}>
                      <div className="form-group" data-cy="user-login-parent">
                        <label htmlFor="userlevelFormControlSelect">{i18next.t('UserLevel')}</label>
                        <select className="form-control" id="userlevelFormControlSelect" name="userlevel" value={userlevel} onChange={this.handleUserlevelChange}>
                          <option value="Service">{i18next.t('Service')}</option>
                          <option value="PTService">{i18next.t('PTService')}</option>
                        </select>
                      </div>
                      <div className="form-group" data-cy="password-login-parent">
                        <label htmlFor="inputPassword">{i18next.t('Password')}</label>
                        <input type="password" className="form-control" id="inputPassword" name="password" value={password} onChange={this.handlePasswordChanged} required autoComplete="on" />
                      </div>
                      <div className="text-center">
                        <button className="btn btn-ptdiag" type="submit" data-cy="login-button">
                          {i18next.t('Login')}
                        </button>
                      </div>
                    </form>
                  </React.Fragment>
                )}
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }

  componentDidMount() {
    const showLogin = this.props.showLogin;
    if (eq(showLogin, false)) {
      /* Try to login */
      this.authenticate({ user: 'Default', password: '' }, 100, this.props.showLogin, this.props.updateShowloginStatusCallback, this.props.updateUnauthorizedCallback);
    }
  }

  private handleUserlevelChange = (event: ChangeEvent<HTMLSelectElement>): void => {
    this.setState({ userlevel: event.target.value });
  };

  private handlePasswordChanged = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ password: event.target.value });
  };

  private handleSubmit = (event: React.FormEvent<HTMLFormElement>, user: string, password: string, showLogin: boolean, updateShowloginStatusCallback: () => void, updateUnauthorizedCallback: (authorized: boolean) => void) => {
    event.preventDefault();
    this.authenticate({ user, password }, 500, showLogin, updateShowloginStatusCallback, updateUnauthorizedCallback);
  };

  private authenticate = (credentials: ICredentials, delayTime: number, showLogin: boolean, updateShowloginStatusCallback: () => void, updateUnauthorizedCallback: (authorized: boolean) => void): void => {
    const retry = () => {
      setInterval(() => {
        this.authenticate(credentials, delayTime, showLogin, updateShowloginStatusCallback, updateUnauthorizedCallback);
      }, 1000);
    };
    const url = `/api/v1/login?user=${credentials.user}&password=${credentials.password}`;
    getRequestDelay(url, delayTime)
      .run()
      .listen({
        onRejected: (error: any) => {
          const NotFound = 404;
          const TooManyRequests = 429;
          if (eq(safeProp('response', error).getOrElse(), undefined)) {
            /* Target Disconnected */
            return this.setState({ errorMessage: error.toString() });
          }

          if (eq(safeObjectSearch('response.status', error).getOrElse(0), NotFound)) {
            /* Error in request -> Server Error */
            return this.setState({ errorMessage: 'Error in Request' });
          }

          if (eq(safeObjectSearch('response.status', error).getOrElse(0), TooManyRequests)) {
            /* Already logged, stop trying to reconnect. */
            return;
          }

          if (eq(showLogin, true)) {
            return this.setState({ errorMessage: 'Invalid Credentials' });
          }

          return retry();
        },
        onResolved: (data: any) => {
          const getRequestResultCode = safeObjectSearch('data.result.code');
          const getRequestResult = safeObjectSearch('data.result');
          const getResultsData = safeObjectSearch('data');
          const getRequestData = compose(chain(checkRequestResult(getRequestResult(data).getOrElse({}), getResultsData(data).getOrElse({}))), getRequestResultCode);

          getRequestData(data).matchWith({
            Ok: () => {
              return eq(showLogin, true) ? updateShowloginStatusCallback() : updateUnauthorizedCallback(true);
            },
            Error: (error: any) => {
              const errorInformation = error.merge();
              return this.setState({
                errorMessage: `${safeProp('code', errorInformation).getOrElse('')} - ${safeProp('info', errorInformation).getOrElse('')}`
              });
            }
          });
        }
      });
  };
}
