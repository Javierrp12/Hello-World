import React from 'react';
import { IFlags, ILevels } from '../../../Datastore/InitialDataInterfaces';
import { ModulesTabConnector } from '../../../ConnectingComponents/TabModules/modulesTabConnector';
import { ModulesTab } from '../../ModulesTab/modulesTab';
import { safeProp, eq } from '../../../CommonFunctions/pointfreeUtilities';

const ConnectorModulesTab = ModulesTabConnector(ModulesTab);

interface IDebugServiceProps {
  activeModule: string;
  debugStatus: string;
  flagsStatus: IFlags;
  levelStatus: ILevels;
  debugMessages: IEntry[];
  updateDebugInfo: () => void;
  setCommandDebug: (commandData: ICommand) => void;
  getDebugMessages: () => void;
  clearDebugMessages: () => void;
  t: (word: string) => string;
}

interface IEntry {
  entry: string
}

interface ICommand {
  command: string;
  level?: string;
}

export class DebugService extends React.Component<IDebugServiceProps> {
  private timerDebugMessagesId: number | undefined;

  render() {
    const { t, clearDebugMessages, setCommandDebug } = this.props;
    const { activeModule, debugStatus, flagsStatus, levelStatus, debugMessages } = this.props;

    return (
      <React.Fragment>
        <div className='display-view-title' data-cy='view-title'>{t('Debug Service')}</div>
        <div className='text-right'><ConnectorModulesTab /></div>
        <div className='container-fluid'>
          <div className='row mt-2 mb-2'>
            <div className='col-3 col-xl-2'>
              <div className='d-flex flex-column'>
                <button className={`btn btn-ptdiag ${(eq(debugStatus, 'running')) ? 'disabled' : ''}`} onClick={() => setCommandDebug({ command: 'start' })}>{t('Start Debug Service')}</button>
                <button className={`btn btn-ptdiag mt-1 ${(eq(debugStatus, 'stopped')) ? 'disabled' : ''}`} onClick={() => setCommandDebug({ command: 'stop' })}>{t('Stop Debug Service')}</button>
                <button className='btn btn-ptdiag mt-1' onClick={clearDebugMessages}>{t('Clear Debug Messages')}</button>
              </div>
            </div>
            <div className='col-2'>{t('Debug Service Flags')}</div>
            <div className='col-2'>
              <div className='form-check'>
                <input className='form-check-input' type='checkbox' id='keepRunning' checked={safeProp('keepRunning', flagsStatus).getOrElse(false)} onChange={() => setCommandDebug({ command: `${(!eq(safeProp('keepRunning', flagsStatus).getOrElse(false), true)) ? 'set' : 'clear'}KeepRunning` })} />
                <label className='form-check-label' htmlFor='keepRunning'>{t('Keep Running')}</label>
              </div>
              <div className='form-check'>
                <input className='form-check-input' type='checkbox' id='runOnBoot' checked={safeProp('runOnBoot', flagsStatus).getOrElse(false)} onChange={() => setCommandDebug({ command: `${(!eq(safeProp('runOnBoot', flagsStatus).getOrElse(false), true)) ? 'set' : 'clear'}RunOnBoot` })} />
                <label className='form-check-label' htmlFor='runOnBoot'>{t('Run on Boot')}</label>
              </div>
            </div>
            {(activeModule === 'MU') &&
              <React.Fragment>
                <div className='col'>{t('Debug Service Messages levels')}:</div>
                <div className='col'>
                  <div className='form-check'>
                    <input className='form-check-input' type='checkbox' id='error' checked={safeProp('Error', levelStatus).getOrElse(false)} onChange={() => setCommandDebug({ command: `${(!eq(safeProp('Error', levelStatus).getOrElse(false), true)) ? 'addLevel' : 'muteLevel'}`, level: 'error' })} />
                    <label className='form-check-label' htmlFor='error'>{t('Error')}</label>
                  </div>
                  <div className='form-check'>
                    <input className='form-check-input' type='checkbox' id='warning' checked={safeProp('Warning', levelStatus).getOrElse(false)} onChange={() => setCommandDebug({ command: `${(!eq(safeProp('Warning', levelStatus).getOrElse(false), true)) ? 'addLevel' : 'muteLevel'}`, level: 'warning' })} />
                    <label className='form-check-label' htmlFor='warning'>{t('Warning')}</label>
                  </div>
                  <div className='form-check'>
                    <input className='form-check-input' type='checkbox' id='info' checked={safeProp('Info', levelStatus).getOrElse(false)} onChange={() => setCommandDebug({ command: `${(!eq(safeProp('Info', levelStatus).getOrElse(false), true)) ? 'addLevel' : 'muteLevel'}`, level: 'info' })} />
                    <label className='form-check-label' htmlFor='info'>{t('Info')}</label>
                  </div>
                  <div className='form-check'>
                    <input className='form-check-input' type='checkbox' id='debug' checked={safeProp('Debug', levelStatus).getOrElse(false)} onChange={() => setCommandDebug({ command: `${(!eq(safeProp('Debug', levelStatus).getOrElse(false), true)) ? 'addLevel' : 'muteLevel'}`, level: 'debug' })} />
                    <label className='form-check-label' htmlFor='debug'>{t('Debug')}</label>
                  </div>
                </div>
              </React.Fragment>
            }
          </div>
        </div>
        <table className='table table-hover table-fixHead display-view-table'>
          <thead>
            <tr>
              <th scope='col'>{t('Message')}</th>
            </tr>
          </thead>
          <tbody>
            {debugMessages.map((msg, index) => {
              return (
                <tr key={`${msg.entry}_${index}`}><td>{msg.entry}</td></tr>
              );
            })}
          </tbody>
        </table>
      </React.Fragment>
    );
  }

  componentDidMount() {
    this.props.updateDebugInfo();
    this.timerDebugMessagesId = window.setInterval(
      () => {
        this.props.getDebugMessages();
      }, 1000);
  }

  componentWillUnmount() {
    clearInterval(this.timerDebugMessagesId);
  }

}