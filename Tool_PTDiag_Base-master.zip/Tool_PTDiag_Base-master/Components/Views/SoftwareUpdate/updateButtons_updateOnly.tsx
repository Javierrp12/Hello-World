import React, { Component } from 'react';
import { eq } from '../../../CommonFunctions/pointfreeUtilities';

interface IUpdateButtons {
  isFileValid: boolean;
  translation: (word: string) => string;
  handleClick: () => void;
  handleStartUpdateProcess: () => void;
}

export class UpdateButtons extends Component<IUpdateButtons> {

  render() {
    const { translation, handleClick, handleStartUpdateProcess, isFileValid } = this.props;

    return (
      <React.Fragment>
        <div className='row'>
          <div className='col-12' data-cy='softwareupdate-buttons'>
            <div className="d-flex justify-content-center col">
              <button className='btn btn-ptdiag mr-2' onClick={handleClick}>{translation('Import File')}</button>
              <button className='btn btn-ptdiag' disabled={eq(isFileValid, false)} onClick={handleStartUpdateProcess}>{translation('Update Software')}</button>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}