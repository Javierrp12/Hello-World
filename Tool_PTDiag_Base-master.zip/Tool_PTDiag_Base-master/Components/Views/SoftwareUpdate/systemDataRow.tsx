import React, { Component } from 'react';
import { IAppInfo, ISytemInfo } from '../../../Datastore/InitialDataInterfaces';
import { toString } from '../../../CommonFunctions/pointfreeUtilities';
import { safeObjectSearch } from '../../../CommonFunctions/functionsSupport';

interface ISystemDataRowProps {
  appInfo: IAppInfo;
  systemInfo: ISytemInfo;
  translation: (word: string) => string;
}

export class SystemDataRow extends Component<ISystemDataRowProps> {

  render() {
    const { translation, appInfo, systemInfo } = this.props;
    return (
      <React.Fragment>
        <div className='row'>
          <div className='col-12' data-cy='softwareupdate-projectinfo'>
            <div className='h5 ptdiag-color-text'>{translation('Project')}: {toString(safeObjectSearch('project.name', appInfo).getOrElse(''))}</div>
            <div className='h5 ptdiag-color-text'>{translation('Firmware Package')}: {toString(safeObjectSearch('project.packageName', appInfo).getOrElse(''))}</div>
            <div className="d-flex justify-content-center col">
              <table className='table table-striped table-bordered col-6'>
                <thead>
                  <tr>
                    <th scope="col">{translation('Name')}</th>
                    <th scope="col">{translation('Info')}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{translation('Project ID')}</td>
                    <td>{toString(safeObjectSearch('project.projectID', appInfo).getOrElse(''))}</td>
                  </tr>
                  <tr>
                    <td>{translation('Package Build Date')}</td>
                    <td>{toString(safeObjectSearch('project.buildDate', appInfo).getOrElse(''))}</td>
                  </tr>
                  <tr>
                    <td>{translation('Package Version')}</td>
                    <td>{toString(safeObjectSearch('project.version', appInfo).getOrElse(''))}</td>
                  </tr>
                  <tr>
                    <td>{translation('MU OS Version')}</td>
                    <td>{toString(safeObjectSearch('os_version', systemInfo).getOrElse(''))}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}