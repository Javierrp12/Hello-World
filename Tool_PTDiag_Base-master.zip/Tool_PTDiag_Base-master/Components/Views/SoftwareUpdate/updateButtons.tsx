import React, { Component } from 'react';
import { Default, Service } from '../../../Datastore/StateData/userLevelTypes';
import { eq } from '../../../CommonFunctions/pointfreeUtilities';
import { filterPerUserLevel } from '../../../CommonFunctions/functionsSupport';

interface IUpdateButtons {
  userlevel: string;
  isFileValid: boolean;
  translation: (word: string) => string;
  handleClick: () => void;
  handleStartUpdateProcess: () => void;
}

export class UpdateButtons extends Component<IUpdateButtons> {

  render() {
    const { translation, handleClick, handleStartUpdateProcess, userlevel, isFileValid } = this.props;

    return (
      <React.Fragment>
        <div className='row'>
          <div className='col-12' data-cy='softwareupdate-buttons'>
            <div className="d-flex justify-content-center col">
              {filterPerUserLevel(userlevel, Service) &&
                <React.Fragment>
                  <button className='btn btn-ptdiag mr-2' onClick={handleClick}>{translation('Import File')}</button>
                  <button className='btn btn-ptdiag' disabled={eq(isFileValid, false)} onClick={handleStartUpdateProcess}>{translation('Update Software')}</button>
                </React.Fragment>
              }
              {eq(userlevel, Default) &&
                <React.Fragment>
                  <button className='btn btn-secondary mr-2' disabled={true}>{translation('Import File')}</button>
                  <button className='btn btn-secondary' disabled={true}>{translation('Update Software')}</button>
                </React.Fragment>
              }
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}