import React, { Component, ChangeEvent } from 'react';
import { PTDeveloper } from '../../../Datastore/StateData/userLevelTypes';
import { safeProp } from '../../../CommonFunctions/pointfreeUtilities';
import { filterPerUserLevel } from '../../../CommonFunctions/functionsSupport';

interface IFileDataRowProps {
  fileData: any;
  isFileValid: boolean;
  forceUpdating: string;
  ignoreUpdating: string;
  userlevel: string;
  handleChange: (event: ChangeEvent<HTMLSelectElement>) => void;
  translation: (word: string) => string;
}

export class FileDataRow extends Component<IFileDataRowProps> {

  render() {
    const { translation, handleChange } = this.props;
    const { userlevel, fileData, isFileValid, forceUpdating, ignoreUpdating } = this.props;
    return (
      <React.Fragment>
        <div className='row'>
          <div className='col-12' data-cy='softwareupdate-fileinfo'>
            <div className='h5 ptdiag-color-text'>{translation('File')}: {safeProp('file_name', fileData).getOrElse('')}</div>
            <div className='h5 ptdiag-color-text'>{translation('Project')}: {safeProp('project_name', fileData).getOrElse('')}</div>
            <div className="d-flex justify-content-center col">
              <table className='table table-striped table-bordered col-6'>
                <thead>
                  <tr>
                    <th scope="col">{translation('Name')}</th>
                    <th scope="col">{translation('Info')}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>{translation('Package Version')}</td>
                    <td>{safeProp('package_version', fileData).getOrElse('')}</td>
                  </tr>
                  <tr>
                    <td>{translation('MU OS Version')}</td>
                    <td>{safeProp('os_version', fileData).getOrElse('')}</td>
                  </tr>
                  {filterPerUserLevel(userlevel, PTDeveloper) &&
                    <React.Fragment>
                      <tr>
                        <td>{translation('Force updating')}</td>
                        <td>
                          <select className='form-control' disabled={isFileValid === false} name='forceUpdating' value={forceUpdating} onChange={handleChange}>
                            <option value='None'>{translation('none')}</option>
                            <option value='all'>{translation('All')} (RUs + MU App + MU Dist)</option>
                            <option value='sw'>{translation('Project Software')} (RUs + MU App)</option>
                            <option value='ru'>{translation('Power Modules Embedded Software')} (RUs)</option>
                            <option value='mu'>{translation('Management Unit App Software')} (MU App)</option>
                            <option value='os'>{translation('Management Unit Operating System')} (MU Dist)</option>
                          </select>
                        </td>
                      </tr>
                      <tr>
                        <td>{translation('Ignore updating')}</td>
                        <td>
                          <select className='form-control' name='ignoreUpdating' value={ignoreUpdating} onChange={handleChange} disabled={isFileValid === false}>
                            <option value='None'>{translation('none')}</option>
                            <option value='sw'>{translation('Project Software')} (RUs + MU App)</option>
                            <option value='ru'>{translation('Power Modules Embedded Software')} (RUs)</option>
                            <option value='mu'>{translation('Management Unit App Software')} (MU App)</option>
                            <option value='os'>{translation('Management Unit Operating System')} (MU Dist)</option>
                          </select>
                        </td>
                      </tr>
                    </React.Fragment>
                  }
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}