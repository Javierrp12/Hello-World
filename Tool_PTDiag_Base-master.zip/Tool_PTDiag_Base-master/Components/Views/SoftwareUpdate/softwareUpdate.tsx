import React, { createRef, ChangeEvent } from 'react';
import { IAppInfo, ISytemInfo, ISoftwareUpdateModel } from '../../../Datastore/InitialDataInterfaces';
import { Service } from '../../../Datastore/StateData/userLevelTypes';
import { IUpdateFlags } from '../../../Datastore/StateData/stateActionCreator';
import { SystemDataRow } from './systemDataRow';
import { FileDataRow } from './fileDataRow';
import { UpdateButtons } from './updateButtons';
import { filterPerUserLevel } from '../../../CommonFunctions/functionsSupport';
import '../view.css';

interface ISoftwareUpdateProps {
  appInfo: IAppInfo;
  systemInfo: ISytemInfo;
  fileData: ISoftwareUpdateModel;
  isFileValid: boolean;
  userlevel: string;
  redirectToUpdater: boolean;
  port: number;
  t: (word: string) => string;
  sendPackageCallback: (file: File) => void;
  startUpdateProcess: (flags: IUpdateFlags) => void;
}

interface ISoftwareUpdateState {
  forceUpdating: string;
  ignoreUpdating: string;
}

export class SoftwareUpdate extends React.Component<ISoftwareUpdateProps, ISoftwareUpdateState> {
  importLink: React.RefObject<HTMLInputElement>;
  constructor(props: ISoftwareUpdateProps) {
    super(props);
    this.state = {
      forceUpdating: 'None',
      ignoreUpdating: 'None'
    }
    this.importLink = createRef<HTMLInputElement>();
  }

  render() {
    const { t, appInfo, systemInfo, fileData, userlevel } = this.props;
    const { forceUpdating, ignoreUpdating } = this.state;

    return (
      <React.Fragment>
        <div className='display-view-title' data-cy='view-title'>{t('Software Update')}</div>
        <div className='container-fluid m-2'>
          <SystemDataRow appInfo={appInfo} translation={t} systemInfo={systemInfo} />
          <FileDataRow translation={t} userlevel={userlevel} fileData={fileData} isFileValid={true} forceUpdating={forceUpdating} ignoreUpdating={ignoreUpdating} handleChange={this.handleChange} />
          <UpdateButtons translation={t} isFileValid={true} userlevel={userlevel} handleClick={this.handleClick} handleStartUpdateProcess={() => this.handleStartUpdateProcess(this.state)} />
          <div className='row'>
            <div className='col text-center'>
              {filterPerUserLevel(userlevel, Service) &&
                <React.Fragment>
                  <div className='form-group'>
                    <input type='file' className='form-control-file visually-hidden' accept='.ccon' ref={this.importLink} onClick={this.handleClearFileName} onChange={this.handleFile} />
                  </div>
                </React.Fragment>
              }
            </div>
          </div>
        </div>
      </React.Fragment >
    );
  }

  private handleClick = (): void => {
    this.importLink.current!.click();
  }

  private handleClearFileName = (): void => {
    this.importLink.current!.value = '';
  }

  private handleFile = (event: ChangeEvent<HTMLInputElement>): void => {
    const selectedFile = event.target.files![0];
    this.props.sendPackageCallback(selectedFile);
  }

  private handleChange = (event: ChangeEvent<HTMLSelectElement>): void => {
    const key: string = event.target.name;

    switch (key) {
      case "forceUpdating":
        this.setState({ "forceUpdating": event.target.value });
        break;

      case "ignoreUpdating":
        this.setState({ "ignoreUpdating": event.target.value });
        break;

      default:
        /* Do nothing */
        break;
    }
  }

  private handleStartUpdateProcess = (state: ISoftwareUpdateState): void => {
    this.props.startUpdateProcess(state);
  }

}
