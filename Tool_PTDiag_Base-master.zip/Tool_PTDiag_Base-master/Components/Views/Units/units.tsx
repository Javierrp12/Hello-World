import React, { Component, ChangeEvent } from 'react';
import { ModulesTab } from '../../ModulesTab/modulesTab';
import { ModulesTabConnector } from '../../../ConnectingComponents/TabModules/modulesTabConnector';
import { IUnitsItem } from '../../../Datastore/InitialDataInterfaces';
import { IParametersDataModify } from '../../../ConnectingComponents/Units/unitsConnector';
import { UnitsList } from './unitsList';
import { Legend } from '../Parameters/Legend/legend';
import { chain, filter } from '../../../CommonFunctions/pointfreeUtilities';
import { safeNewArray, filterSearchStringSignal } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

const ConnectorModulesTab = ModulesTabConnector(ModulesTab);

interface IUnitsProps {
  activeModule: string;
  unitsData: IUnitsItem[];
  categories: string[];
  category: string;
  parameterInfoData: any;
  t: (word: string) => string;
  changeParameterCallback: (data: IParametersDataModify) => void;
  resetParameterCallback: (data: IParametersDataModify) => void;
  categoryChangeCallback: (category: ICategoryChange) => void;
  updateParameterUnitsInfo: () => void;
  saveParametersUnits: () => void;
  factorySettingsUnitsCallback: () => void;
}

interface ICategoryChange {
  category: string;
}

interface IUnitsState {
  search: string;
}

export class Units extends Component<IUnitsProps, IUnitsState> {
  constructor(props: IUnitsProps) {
    super(props);
    this.state = {
      search: ''
    }
  }

  render() {
    const { t, categoryChangeCallback, saveParametersUnits, factorySettingsUnitsCallback, changeParameterCallback, resetParameterCallback } = this.props;
    const { activeModule, category, categories, unitsData, parameterInfoData } = this.props;
    const { search } = this.state;

    const filterUnits = compose(chain(filter(filterSearchStringSignal(search, 'name'))), safeNewArray);

    return (
      <React.Fragment>
        <div className='display-view-title' data-cy='view-title'>{t('Units Adjusment')}</div>
        <div className='text-right'><ConnectorModulesTab /></div>
        <div className='m-2'>
          <div className="form-inline">
            <div className="form-group mx-sm-3 mb-2">
              <label htmlFor="categoriesFormControlSelect" className='mr-2'>{t('Categories')}</label>
              <select className="form-control" id="categoriesFormControlSelect" value={category} onChange={(event) => categoryChangeCallback({ category: event.target.value })}>
                {categories.map(category => (<option key={category}>{category}</option>))}
              </select>
            </div>
            <button className='btn btn-ptdiag m-2' onClick={saveParametersUnits}>{t('Save Units')}</button>
            <button className='btn btn-ptdiag' onClick={factorySettingsUnitsCallback}>{t('Restore Units')}</button>
            <div className="form-group m-2">
              <input type="search" className="form-control" placeholder={`${t('Search')}...`} id="search-input" aria-describedby="search" name='search' value={search} onChange={(event) => this.handleSearchChanged(event)} />
            </div>
          </div>
          <UnitsList
			activeModule={activeModule}
			category={category}
            unitsData={filterUnits(unitsData)}
            parameterInfoData={parameterInfoData}
            translation={t}
            changeParameterCallback={changeParameterCallback}
            resetParameterCallback={resetParameterCallback}
          />
          <Legend translation={t} />
        </div>
      </React.Fragment>
    );
  }

  componentDidMount() {
    this.props.updateParameterUnitsInfo();
  }

  private handleSearchChanged = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ search: event.target.value })
  }

}
