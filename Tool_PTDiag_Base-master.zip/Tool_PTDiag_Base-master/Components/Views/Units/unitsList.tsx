import React from 'react';
import { IUnitsItem } from '../../../Datastore/InitialDataInterfaces';
import { IParametersDataModify } from '../../../ConnectingComponents/Units/unitsConnector';
import { SymbolEntry } from './symbolEntry';
import { NumericEntry } from './numericEntry';
import { safeProp, map, eq } from '../../../CommonFunctions/pointfreeUtilities';
import { safeNewArray } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface IUnitsListProps {
  activeModule: string;
  category: string;
  unitsData: IUnitsItem[];
  parameterInfoData: any;
  translation: (word: string) => string;
  changeParameterCallback: (data: IParametersDataModify) => void;
  resetParameterCallback: (data: IParametersDataModify) => void;
}

export class UnitsList extends React.Component<IUnitsListProps> {

  render() {
    const { activeModule, category, unitsData, parameterInfoData } = this.props;
    const { translation, changeParameterCallback, resetParameterCallback } = this.props;

    return (
      <React.Fragment>
        <div className="table-responsive">
          <table className='table table-hover table-fixHead display-view-table'>
            <thead>
              <tr>
                <th scope='col'></th>
                <th scope='col'></th>
                <th scope='col'>{translation('Parameter')}</th>
                <th scope='col'></th>
                <th scope='col'>{translation('Value')}</th>
                <th scope='col'>{translation('Range')}</th>
                <th scope='col'>{translation('Default')}</th>
              </tr>
            </thead>
            <tbody>
              {this.getUnitEntry(activeModule, category, unitsData, parameterInfoData, translation, changeParameterCallback, resetParameterCallback)}
            </tbody>
          </table>
        </div>
      </React.Fragment>
    );
  }

  private getUnitEntry = (activeModule: string, category: string, unitsData: IUnitsItem[], parameterInfoData: any, translation: (word: string) => string, changeParameterCallback: (data: IParametersDataModify) => void, resetParameterCallback: (data: IParametersDataModify) => void) => {
    const getUnitEntry = (x: any, index: number) => (eq(safeProp('defaultValue', x).getOrElse(), undefined))
      ? <SymbolEntry key={`${index}_${activeModule}_${category}_${x.name}`} entryData={x} /> :
      <NumericEntry key={`${index}_${activeModule}_${category}_${x.name}`} entryData={x} parameterInfoData={parameterInfoData} translation={translation} changeParameterCallback={changeParameterCallback} resetParameterCallback={resetParameterCallback} />;
    const getUnitEntryArray = compose(map(map(getUnitEntry)), safeNewArray);
    return getUnitEntryArray(unitsData).matchWith({
      Just: (value: any) => value.getOrElse([]),
      Nothing: () =>
        <tr>
          <td colSpan={7} className='text-center'>{translation('No Entries Found')}</td>
        </tr>
    });
  }

}