import React, { Component, ChangeEvent } from 'react';
import { IUnitsItem } from '../../../Datastore/InitialDataInterfaces';
import { IParametersDataModify } from '../../../ConnectingComponents/Units/unitsConnector';
import { prop, safeProp, safeHead, chain, map, filter, eq } from '../../../CommonFunctions/pointfreeUtilities';
import { safeNewArray, getParameterFlag, eq3, alt, checkValue, eq2 } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface INumericEntryProps {
  entryData: IUnitsItem;
  parameterInfoData: any
  translation: (word: string) => string;
  changeParameterCallback: (data: IParametersDataModify) => void;
  resetParameterCallback: (data: IParametersDataModify) => void;
}

interface INumericEntryState {
  value: string;
  validValue: string;
}

export class NumericEntry extends Component<INumericEntryProps, INumericEntryState> {
  constructor(props: INumericEntryProps) {
    super(props);
    this.state = {
      value: '',
      validValue: 'disabled'
    }
  }

  render() {
    const { entryData, parameterInfoData } = this.props;
    const { translation, changeParameterCallback, resetParameterCallback } = this.props;
    const { value, validValue } = this.state;

    const getFlagUnit = compose(safeHead, compose(chain(filter(eq3(safeProp('name', entryData).getOrElse(''), 'name'))), safeNewArray));
    const getTempFlag = compose(getParameterFlag('tempFlag', 'temp'), getFlagUnit);
    const getStoreFlag = compose(getParameterFlag('storedFlag', 'stored'), getFlagUnit);
    const getValue = compose(map(alt(prop('temp'), prop('stored'))), getFlagUnit);

    return (
      <React.Fragment>
        <tr>
          <td className={`${eq2(true, 'changeableOnTheFly', entryData) ? 'changeable_On_The_Fly' : ''}`}></td>
          <td className={getTempFlag(parameterInfoData)}></td>
          <td className={`${getStoreFlag(parameterInfoData)} boldItem`}>{safeProp('name', entryData).getOrElse('---')}</td>
          <td>
            <form onSubmit={this.handleSubmit}>
              <div className='form-group'>
                <input className={`form-control-sm ${eq(validValue, 'disabled') ? 'invalidEntry' : ''}`} type="text" placeholder={getValue(parameterInfoData).getOrElse(safeProp('defaultValue', entryData).getOrElse('---'))} value={value} onChange={this.handleValueChanged} />
              </div>
            </form>
          </td>
          <td>
            <button className={`btn btn-outline-dark btn-sm mr-2 ${validValue} ${validValue}_button`} onClick={() => this.handleClick(validValue, entryData, value, changeParameterCallback)}>{translation('Apply')} </button>
            {eq(getTempFlag(parameterInfoData), 'tempFlag') &&
              <button className='btn btn-outline-dark btn-sm mr-2' onClick={() => resetParameterCallback({ parameter: safeProp('name', entryData).getOrElse('') })}>{translation('Reset')} </button>
            }
          </td>
          <td>{`${safeProp('minimum', entryData).getOrElse('-')} ... ${safeProp('maximum', entryData).getOrElse('-')}`}</td>
          <td>{safeProp('defaultValue', entryData).getOrElse('---')}</td>
        </tr>
      </React.Fragment>
    )
  }

  private handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
  }

  private handleValueChanged = (event: ChangeEvent<HTMLInputElement>) => {
    this.setState({ value: event.currentTarget.value, validValue: checkValue(event.currentTarget.value).getOrElse('') });
  }

  private handleClick = (validValue: string, entryData: IUnitsItem, value: string, changeParameterCallback: (data: IParametersDataModify) => void) => eq(validValue, '') ? changeParameterCallback({ parameter: safeProp('name', entryData).getOrElse(''), value }) : {};

}