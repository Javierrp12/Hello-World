import React, { Component } from 'react';
import { IUnitsItem } from '../../../Datastore/InitialDataInterfaces';
import { safeProp } from '../../../CommonFunctions/pointfreeUtilities';

interface ISymbolEntryProps {
  entryData: IUnitsItem;
}

export class SymbolEntry extends Component<ISymbolEntryProps> {

  render() {
    const { entryData } = this.props;

    return (
      <React.Fragment>
        <tr>
          <td></td>
          <td></td>
          <td className={'boldItem'}>{safeProp('name', entryData).getOrElse('---')}</td>
          <td>{safeProp('value', entryData).getOrElse('---')}</td>
          <td>---</td>
          <td>---</td>
          <td></td>
        </tr>
      </React.Fragment>
    );
  }
}