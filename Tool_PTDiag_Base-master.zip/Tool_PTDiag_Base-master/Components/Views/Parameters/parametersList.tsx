import React from 'react';
import { IParametersDataModify } from '../../../ConnectingComponents/Parameters/parametersConnector';
import { IParametersItem } from '../../../Datastore/InitialDataInterfaces';
import { NumericEntry } from './numericEntry';
import { BooleanEntry } from './booleanEntry';
import { map, eq, safeProp, filter } from '../../../CommonFunctions/pointfreeUtilities';
import { safeNewArray, filterParameterPerUserLevelVisibility } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface IParametersListProps {
  activeModule: string;
  category: string;
  parametersData: IParametersItem[];
  parameterInfoData: any;
  userlevel: string;
  translation: (word: string) => string;
  changeParameterCallback: (data: IParametersDataModify) => void;
  resetParameterCallback: (data: IParametersDataModify) => void;
}

export class ParametersList extends React.Component<IParametersListProps> {

  render() {
    const { translation, changeParameterCallback, resetParameterCallback } = this.props;
    const { activeModule, category, parametersData, parameterInfoData, userlevel } = this.props;

    return (
      <React.Fragment>
        <table className='table table-hover table-fixHead display-view-table mt-2'>
          <thead>
            <tr>
              <th scope='col'></th>
              <th scope='col'></th>
              <th scope='col'>{translation('Parameter')}</th>
              <th scope='col'>{translation('Value')}</th>
              <th scope='col'></th>
              <th scope='col'>{translation('Range')}</th>
              <th scope='col'>{translation('Default')}</th>
              <th scope='col'>{translation('Unit')}</th>
            </tr>
          </thead>
          <tbody data-cy='parameters-table'>
            {this.getParameterEntry(activeModule, category, parametersData, parameterInfoData, userlevel, translation, changeParameterCallback, resetParameterCallback)}
          </tbody>
        </table>
      </React.Fragment>
    );
  }

  private getParameterEntry = (activeModule: string, category: string, parametersData: IParametersItem[], parameterInfoData: any, userlevel: string, translation: (word: string) => string, changeParameterCallback: (data: IParametersDataModify) => void, resetParameterCallback: (data: IParametersDataModify) => void) => {
    const getParameterEntry = (x: any, index: number) => (eq(safeProp('dataType', x).getOrElse(), "Boolean"))
      ? <BooleanEntry key={`${index}_${activeModule}_${category}_${x.name}`} entryData={x} parameterInfoData={parameterInfoData} userlevel={userlevel} translation={translation} changeParameterCallback={changeParameterCallback} resetParameterCallback={resetParameterCallback} /> :
      <NumericEntry key={`${index}_${activeModule}_${category}_${x.name}`} entryData={x} parameterInfoData={parameterInfoData} userlevel={userlevel} translation={translation} changeParameterCallback={changeParameterCallback} resetParameterCallback={resetParameterCallback} />;
    const getParameterEntryArray = compose(map(map(getParameterEntry)), compose(map(filter(filterParameterPerUserLevelVisibility(userlevel, 'visibleBy'))), safeNewArray));
    return getParameterEntryArray(parametersData).matchWith({
      Just: (value: any) => value.getOrElse([]),
      Nothing: () =>
        <tr>
          <td colSpan={7} className='text-center'>{translation('No Entries Found')}</td>
        </tr>
    });

  }

}
