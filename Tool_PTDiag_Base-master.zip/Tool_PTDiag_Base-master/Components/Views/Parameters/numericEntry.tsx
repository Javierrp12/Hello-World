import React, { Component, ChangeEvent } from 'react';
import { IParametersItem } from '../../../Datastore/InitialDataInterfaces';
import { IParametersDataModify } from '../../../ConnectingComponents/Parameters/parametersConnector';
import { map, chain, prop, filter, safeProp, safeHead, eq, replace } from '../../../CommonFunctions/pointfreeUtilities';
import { eq2, eq3, getParameterFlag, alt, safeNewArray, checkValue, safeObjectSearch, filterPerUserLevel } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface INumericEntryProps {
  entryData: IParametersItem;
  parameterInfoData: any;
  userlevel: string;
  translation: (word: string) => string;
  changeParameterCallback: (data: IParametersDataModify) => void;
  resetParameterCallback: (data: IParametersDataModify) => void;
}

interface INumericEntryState {
  value: string;
  validValue: string;
}

export class NumericEntry extends Component<INumericEntryProps, INumericEntryState> {
  constructor(props: INumericEntryProps) {
    super(props);
    this.state = {
      value: '',
      validValue: 'disabled'
    }
  }

  render() {
    const { entryData, parameterInfoData, userlevel } = this.props;
    const { translation, changeParameterCallback, resetParameterCallback } = this.props;
    const { value, validValue } = this.state;

    const getFlagParameter = compose(safeHead, compose(chain(filter(eq3(safeProp('name', entryData).getOrElse(''), 'name'))), safeNewArray));
    const getTempFlag = compose(getParameterFlag('tempFlag', 'temp'), getFlagParameter);
    const getStoreFlag = compose(getParameterFlag('storedFlag', 'stored'), getFlagParameter);
    const getValue = compose(map(alt(prop('temp'), prop('stored'))), getFlagParameter);
    const parameterDisabled = filterPerUserLevel(userlevel, safeProp('changeableBy', entryData).getOrElse(''));

    return (
      <React.Fragment>
        <tr>
          <td className={`${eq2(true, 'changeableOnTheFly', entryData) ? 'changeable_On_The_Fly' : ''}`}></td>
          <td className={getTempFlag(parameterInfoData)}></td>
          <td className={`${getStoreFlag(parameterInfoData)} boldItem`}>{replace('_ncof', '', safeProp('name', entryData).getOrElse('---'))}</td>
          <td>
            <form onSubmit={this.handleSubmit}>
              <div className='form-group'>
                <input className={`form-control-sm ${eq(validValue, 'disabled') ? 'invalidEntry' : ''}`} disabled={!parameterDisabled} type="text" placeholder={getValue(parameterInfoData).getOrElse(safeProp('defaultValue', entryData).getOrElse('---'))} value={value} onChange={this.handleValueChanged} />
              </div>
            </form>
          </td>
          <td>
            {parameterDisabled &&
              <React.Fragment>
                <button className={`btn btn-outline-dark btn-sm mr-2 ${validValue} ${validValue}_button`} onClick={() => this.handleClick(validValue, entryData, value, changeParameterCallback)}>{translation('Apply')} </button>
                {eq(getTempFlag(parameterInfoData), 'tempFlag') &&
                  <button className='btn btn-outline-dark btn-sm mr-2' onClick={() => {
                    resetParameterCallback({ parameter: safeProp('name', entryData).getOrElse('') });
                    this.setState({ value: '', validValue: 'disabled' });
                  }}>{translation('Reset')} </button>
                }
              </React.Fragment>
            }
          </td>
          <td>{`${safeObjectSearch('range_Service.min', entryData).getOrElse('-')} ... ${safeObjectSearch('range_Service.max', entryData).getOrElse('-')}`}</td>
          <td>{safeProp('defaultValue', entryData).getOrElse('---')}</td>
          <td>{safeProp('unit', entryData).getOrElse('---')}</td>
        </tr>
      </React.Fragment>
    );
  }

  private handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
  }

  private handleValueChanged = (event: ChangeEvent<HTMLInputElement>) => {
    this.setState({ value: event.currentTarget.value, validValue: checkValue(event.currentTarget.value).getOrElse('') });
  }

  private handleClick = (validValue: string, entryData: IParametersItem, value: string, changeParameterCallback: (data: IParametersDataModify) => void) => eq(validValue, '') ? changeParameterCallback({ parameter: safeProp('name', entryData).getOrElse(''), value }) : {};

}