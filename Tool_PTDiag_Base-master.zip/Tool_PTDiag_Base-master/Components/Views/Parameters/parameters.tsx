import React, { createRef, ChangeEvent } from 'react';
import { IParametersItem, ISytemInfo, IAppInfo } from '../../../Datastore/InitialDataInterfaces';
import { IParametersDataModify } from '../../../ConnectingComponents/Parameters/parametersConnector';
import { Service, PTService } from '../../../Datastore/StateData/userLevelTypes';
import { IParameterDataFile } from '../../../Datastore/StateData/stateActionCreator';
import { IErrorInfo } from '../../../Datastore/ErrorData/errorActionCreator';
import { ModulesTab } from '../../ModulesTab/modulesTab';
import { ModulesTabConnector } from '../../../ConnectingComponents/TabModules/modulesTabConnector';
import { Legend } from './Legend/legend';
import { ParametersList } from './parametersList';
import { prepareToExportData } from '../../../CommonFunctions/commonFunctions';
import { chain, eq, map, filter, toString, reduce, intercalate, sortBy, toLowerCase, safeProp } from '../../../CommonFunctions/pointfreeUtilities';
import {
  filterPerUserLevel, safeNewArray, filterSearchStringSignal, safeObjectSearch, titleText, parametersFormat, safeGetKeysObject, parameterEntryToString,
  parameterChangedEntryToString, parameterChangedTemporarilyEntryToJSON, readFile, safeParseJSON, validateResultParameterJSON
} from '../../../CommonFunctions/functionsSupport';
import './parameters.css'

const compose = require('folktale/core/lambda/compose');

interface IParametersProps {
  activeModule: string;
  appInfo: IAppInfo;
  systemInfo: ISytemInfo;
  parametersData: IParametersItem[];
  categories: string[];
  category: string;
  parameterInfoData: any;
  modulesParametersData: any;
  modulesParametersInfo: any;
  userlevel: string;
  t: (word: string) => string;
  saveAllModulesParameters: () => void;
  saveParameters: () => void;
  factorySettingsCallback: () => void;
  updateParameterInfo: () => void;
  updateErrorStatusCallback: (erroInfo: IErrorInfo) => void;
  changeTemporalyFileCallback: (parameters: IParameterDataFile[]) => void;
  categoryChangeCallback: (category: IChangeCategory) => void;
  changeParameterCallback: (data: IParametersDataModify) => void;
  resetParameterCallback: (data: IParametersDataModify) => void;
}

interface IParametersState {
  search: string;
  optionSelected: string;
}

interface IChangeCategory {
  category: string;
}

const ConnectorModulesTab = ModulesTabConnector(ModulesTab);

export class Parameters extends React.Component<IParametersProps, IParametersState> {
  private exportLink: React.RefObject<HTMLAnchorElement>;
  private importLink: React.RefObject<HTMLInputElement>;
  constructor(props: IParametersProps) {
    super(props);
    this.state = {
      search: '',
      optionSelected: 'allParameters'
    }
    this.exportLink = createRef<HTMLAnchorElement>();
    this.importLink = createRef<HTMLInputElement>();
  }

  render() {
    const { t, saveAllModulesParameters, categoryChangeCallback, saveParameters, factorySettingsCallback, changeParameterCallback, resetParameterCallback, updateErrorStatusCallback, changeTemporalyFileCallback } = this.props;
    const { appInfo, systemInfo, userlevel, activeModule, category, categories, parametersData, parameterInfoData, modulesParametersData, modulesParametersInfo } = this.props;
    const { optionSelected, search } = this.state;

    const toLowerCaseParameter = (x: any) => toLowerCase(safeProp('name', x).getOrElse(''));
    const sortParameters = compose(chain(filter(filterSearchStringSignal(search, 'name'))), map(sortBy(toLowerCaseParameter)));
    const filterStrings = (entry: IParametersItem) => typeof entry !== 'string';
    const filterParameters = compose(sortParameters, compose(map(filter(filterStrings)), safeNewArray));

    return (
      <React.Fragment>
        <div className='display-view-title' data-cy='view-title'>{t('Parameters Adjustment')}</div>
        <div className='text-right'><ConnectorModulesTab /></div>
        <div className='m-2'>
          {filterPerUserLevel(userlevel, Service) &&
            <div className='border-bottom'>
              <button className='btn btn-ptdiag m-2' onClick={saveAllModulesParameters} data-cy='saveAllModulesParameters-button'>{t('Save All Modules Parameters')}</button>
              {filterPerUserLevel(userlevel, PTService) &&
                <React.Fragment>
                  <div className='form-group visually-hidden'>
                    <input type='file' className='form-control-file' accept='.json' ref={this.importLink} onClick={this.handleClearFileName} onChange={(event) => this.handleFile(event, appInfo, systemInfo, modulesParametersData, userlevel, updateErrorStatusCallback, changeTemporalyFileCallback)} />
                  </div>
                  <button className='btn btn-ptdiag m-2' onClick={this.handleClick} data-cy='temporarily-file-button'>{t('ImportChangedTemporarilyParametersFile')}</button>
                </React.Fragment>
              }
              <div className='form-check-inline border pr-2'>
                <button className='btn btn-ptdiag m-2' onClick={() => this.handleExportFile(optionSelected, userlevel, appInfo, systemInfo, modulesParametersData, modulesParametersInfo)} data-cy='parameters-export-button'>{t('Export Parameters')}</button>
                <div data-cy='parameters-export-parent'>
                  <div className="form-check">
                    <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="allParameters" checked={eq(optionSelected, 'allParameters')} onChange={() => this.handleExportOptionsChange('allParameters')} />
                    <label className="form-check-label" htmlFor="inlineRadio1">{t('All parameters')}</label>
                  </div>
                  <div className="form-check">
                    <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="changedParameters" checked={eq(optionSelected, 'changedParameters')} onChange={() => this.handleExportOptionsChange('changedParameters')} />
                    <label className="form-check-label" htmlFor="inlineRadio2">{t('Changed Parameters')}</label>
                  </div>
                  {filterPerUserLevel(userlevel, PTService) &&
                    <div className="form-check">
                      <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="changedTemporarilyParameters" checked={eq(optionSelected, 'changedTemporarilyParameters')} onChange={() => this.handleExportOptionsChange('changedTemporarilyParameters')} />
                      <label className="form-check-label" htmlFor="inlineRadio2">{t('Changed Temporarily Parameters')}</label>
                    </div>
                  }
                </div>
              </div>
              <a className='visually-hidden' href='/#' ref={this.exportLink}>Export Parameters Data</a>
            </div>
          }
          <div className="form-inline">
            <div className="form-group mx-sm-3">
              <label htmlFor="categoriesFormControlSelect" className='mr-2'>{t('Categories')}</label>
              <select className="form-control" id="categoriesFormControlSelect" value={category} onChange={(event) => categoryChangeCallback({ category: event.target.value })} data-cy='parameters-categories'>
                {categories.map(category => (<option key={category}>{category}</option>))}
              </select>
            </div>
            {filterPerUserLevel(userlevel, Service) &&
              <React.Fragment>
                <button className='btn btn-ptdiag m-2' onClick={saveParameters} data-cy='saveParameters-button'>{t('Save Parameters')}</button>
                <button className='btn btn-ptdiag' onClick={factorySettingsCallback}data-cy='restoreParameters-button'>{t('Restore Parameters')}</button>
              </React.Fragment>
            }
            <div className="form-group mx-sm-3">
              <input type="search" className="form-control" placeholder={`${t('Search')}...`} id="search-input" aria-describedby="search" name='search' value={search} onChange={this.handleSearchChanged} data-cy='parameters-search' />
            </div>
          </div>
          <ParametersList
			activeModule={activeModule}
			category={category}
            parametersData={filterParameters(parametersData)}
            parameterInfoData={parameterInfoData}
            changeParameterCallback={changeParameterCallback}
            resetParameterCallback={resetParameterCallback}
            userlevel={userlevel}
            translation={t}
          />
          <Legend translation={t} />
        </div>
      </React.Fragment>
    );
  }

  componentDidMount() {
    this.props.updateParameterInfo();
  }

  private handleSearchChanged = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ "search": event.target.value })
  }

  private handleExportOptionsChange = (option: string): void => {
    this.setState({ optionSelected: option })
  }

  private handleExportFile = (optionSelected: string, userlevel: string, appInfo: IAppInfo, systemInfo: ISytemInfo, modulesParametersData: any, modulesParametersInfo: any): void => {
    return eq(optionSelected, 'changedParameters')
      ? this.handleExportChangeParameters(appInfo, systemInfo, modulesParametersData, modulesParametersInfo)
      : eq(optionSelected, 'changedTemporarilyParameters')
        ? this.handleExportChangeTemporarilyParameters(appInfo, systemInfo, modulesParametersInfo)
        : this.handledExport(userlevel, appInfo, systemInfo, modulesParametersData, modulesParametersInfo);
  }

  private handledExport = (userlevel: string, appInfo: IAppInfo, systemInfo: ISytemInfo, modulesParametersData: any, modulesParametersInfo: any): void => {
    const arrayToString = compose(map(reduce(parameterEntryToString(userlevel, appInfo, systemInfo, modulesParametersData, modulesParametersInfo), [])), safeGetKeysObject)
    const getParametersDataString = compose(map(intercalate('\n')), arrayToString);
    const getProjectName = titleText(toString(safeObjectSearch('project.name', appInfo).getOrElse('')), ':');
    const getProjectPackage = titleText(toString(safeObjectSearch('project.packageName', appInfo).getOrElse('')), ':');
    const expectedString = parametersFormat(getProjectName('Project'), getProjectPackage('Package'), getParametersDataString(modulesParametersData).getOrElse(''));
    prepareToExportData({ name: 'ParametersData.txt', type: 'text/txt;charset=utf-8', expectedString: expectedString('Project\nPackage\n\nData') }, this.exportLink);
  }

  private handleExportChangeParameters = (appInfo: IAppInfo, systemInfo: ISytemInfo, modulesParametersData: any, modulesParametersInfo: any): void => {
    const arrayToString = compose(map(reduce(parameterChangedEntryToString(appInfo, systemInfo, modulesParametersData, modulesParametersInfo), [])), safeGetKeysObject)
    const getParametersDataString = compose(map(intercalate('\n')), arrayToString);
    const getProjectName = titleText(toString(safeObjectSearch('project.name', appInfo).getOrElse('')), ':');
    const getProjectPackage = titleText(toString(safeObjectSearch('project.packageName', appInfo).getOrElse('')), ':');
    const expectedString = parametersFormat(getProjectName('Project'), getProjectPackage('Package'), getParametersDataString(modulesParametersData).getOrElse(''));
    prepareToExportData({ name: 'ParametersChangedData.txt', type: 'text/txt;charset=utf-8', expectedString: expectedString('Project\nPackage\n\nData') }, this.exportLink);
  }

  private handleExportChangeTemporarilyParameters = (appInfo: IAppInfo, systemInfo: ISytemInfo, modulesParametersInfo: any): void => {
    const projectName = safeObjectSearch('project.name');
    const packageName = safeObjectSearch('project.packageName');
    const getParametersData = compose(map(reduce(parameterChangedTemporarilyEntryToJSON(appInfo, systemInfo, modulesParametersInfo), [])), safeGetKeysObject);
    const expectedObj = { project: projectName(appInfo).getOrElse(''), "firmware package": packageName(appInfo).getOrElse(''), modules: getParametersData(modulesParametersInfo).getOrElse([]) };
    prepareToExportData({ name: 'ParametersChangedData.json', type: 'text/json;charset=utf-8', expectedString: JSON.stringify(expectedObj, null, 4) }, this.exportLink);
  }

  private handleClick = (): void => {
    this.importLink.current!.click();
  }

  private handleClearFileName = (): void => {
    this.importLink.current!.value = '';
  }

  private handleFile = (event: ChangeEvent<HTMLInputElement>, appInfo: IAppInfo, systemInfo: ISytemInfo, modulesParametersData: any, userlevel: string, updateErrorStatusCallback: (erroInfo: IErrorInfo) => void, changeTemporalyFileCallback: (parameters: IParameterDataFile[]) => void): void => {
    readFile(event.target.files![0]).run().listen({
      onRejected: (error: string) => {
        updateErrorStatusCallback({ isOnline: true, error: `Error Reading file - ${error}` })
      },
      onResolved: (value: string) => {
        safeParseJSON(value).matchWith({
          Ok: (value: any) => {
            validateResultParameterJSON(value.merge(), appInfo, systemInfo, modulesParametersData, userlevel).matchWith({
              Ok: (value: any) => changeTemporalyFileCallback(value.merge()),
              Error: (error: any) => updateErrorStatusCallback({ isOnline: true, error: `Invalid file - ${error.merge()}` })
            });
          },
          Error: (error: any) => updateErrorStatusCallback({ isOnline: true, error: `Invalid file - ${error.merge()}` })
        });
      }
    });
  }

}