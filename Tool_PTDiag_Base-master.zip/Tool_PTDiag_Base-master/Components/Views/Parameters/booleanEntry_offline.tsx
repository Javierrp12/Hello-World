import React, { Component } from 'react';
import { IParametersItem } from '../../../Datastore/InitialDataInterfaces';
import { toUpperCase, toLowerCase, concat, split, replace, toString, map, chain, prop, filter, safeProp, safeHead, eq, intercalate } from '../../../CommonFunctions/pointfreeUtilities';
import { eq2, eq3, getParameterFlag, altBo, safeNewArray } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface IBooleanEntryProps {
  entryData: IParametersItem;
  parameterInfoData: any;
  userlevel: string;
  translation: (word: string) => string;
}

export class BooleanEntry extends Component<IBooleanEntryProps> {
  render() {
    const { entryData, parameterInfoData } = this.props;

    const getFlagParameter = compose(safeHead, compose(chain(filter(eq3(safeProp('name', entryData).getOrElse(''), 'name'))), safeNewArray));
    const getTempFlag = compose(getParameterFlag('tempFlag', 'temp'), getFlagParameter);
    const getStoreFlag = compose(getParameterFlag('storedFlag', 'stored'), getFlagParameter);
    const capitalize = (x: string[]) => {
      const [first, ...remaing] = x;
      return concat(toUpperCase(first), intercalate('', remaing));
    };
    const toArrayString = compose(map(split('')), map(toString));
    const getDefault = compose(map(eq('1')), safeProp('defaultValue'));
    const getDefaultValue = compose(map(capitalize), compose(toArrayString, getDefault));
    const getValue = compose(map(altBo(prop('temp'), prop('stored'))), getFlagParameter);

    return (
      <React.Fragment>
        <tr>
          <td className={`${eq2(true, 'changeableOnTheFly', entryData) ? 'changeable_On_The_Fly' : ''}`}></td>
          <td className={getTempFlag(parameterInfoData)}></td>
          <td className={`${getStoreFlag(parameterInfoData)} boldItem`}>{replace('_ncof', '', safeProp('name', entryData).getOrElse('---'))}</td>
          <td>
            <div className="form-check form-check-inline">
              <input className="form-check-input" disabled={true} type="radio" id={`inlineTrue_${entryData.name}`} value="true" checked={eq(toLowerCase(toString(getValue(parameterInfoData).getOrElse(getDefaultValue(entryData).getOrElse('false')))), 'true')} />
              <label className="form-check-label" htmlFor={`inlineTrue_${entryData.name}`}>
                True
              </label>
            </div>
            <div className="form-check form-check-inline">
              <input className="form-check-input" disabled={true} type="radio" id={`inlineFalse_${entryData.name}`} value="false" checked={eq(toLowerCase(toString(getValue(parameterInfoData).getOrElse(getDefaultValue(entryData).getOrElse('false')))), 'false')} />
              <label className="form-check-label" htmlFor={`inlineTrue_${entryData.name}`}>
                False
              </label>
            </div>
          </td>
          <td>---</td>
          <td>{getDefaultValue(entryData).getOrElse('')}</td>
          <td>---</td>
        </tr>
      </React.Fragment>
    );
  }
}
