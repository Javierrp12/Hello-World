import React, { Component } from 'react';
import { IParametersItem } from '../../../Datastore/InitialDataInterfaces';
import { map, chain, prop, filter, safeProp, safeHead, replace } from '../../../CommonFunctions/pointfreeUtilities';
import { eq2, eq3, getParameterFlag, alt, safeNewArray, safeObjectSearch } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface INumericEntryProps {
  entryData: IParametersItem;
  parameterInfoData: any;
  userlevel: string;
  translation: (word: string) => string;
}

export class NumericEntry extends Component<INumericEntryProps> {

  render() {
    const { entryData, parameterInfoData } = this.props;

    const getFlagParameter = compose(safeHead, compose(chain(filter(eq3(safeProp('name', entryData).getOrElse(''), 'name'))), safeNewArray));
    const getTempFlag = compose(getParameterFlag('tempFlag', 'temp'), getFlagParameter);
    const getStoreFlag = compose(getParameterFlag('storedFlag', 'stored'), getFlagParameter);
    const getValue = compose(map(alt(prop('temp'), prop('stored'))), getFlagParameter);

    return (
      <React.Fragment>
        <tr>
          <td className={`${eq2(true, 'changeableOnTheFly', entryData) ? 'changeable_On_The_Fly' : ''}`}></td>
          <td className={getTempFlag(parameterInfoData)}></td>
          <td className={`${getStoreFlag(parameterInfoData)} boldItem`}>{replace('_ncof', '', safeProp('name', entryData).getOrElse('---'))}</td>
          <td>
            <form onSubmit={this.handleSubmit}>
              <div className='form-group'>
                <input className={'form-control-sm'} disabled={true} type='text' value={getValue(parameterInfoData).getOrElse(safeProp('defaultValue', entryData).getOrElse('---'))} />
              </div>
            </form>
          </td>
          <td>{`${safeObjectSearch('range_Service.min', entryData).getOrElse('-')} ... ${safeObjectSearch('range_Service.max', entryData).getOrElse('-')}`}</td>
          <td>{safeProp('defaultValue', entryData).getOrElse('---')}</td>
          <td>{safeProp('unit', entryData).getOrElse('---')}</td>
        </tr>
      </React.Fragment>
    );
  }

  private handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
  }

}