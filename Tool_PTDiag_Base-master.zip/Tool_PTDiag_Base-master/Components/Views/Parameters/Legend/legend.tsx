import React, { Component } from 'react';

interface ILegendProps {
  translation: (word: string) => string;
}

export class Legend extends Component<ILegendProps> {

  render() {
    const { translation } = this.props;
    return (
      <React.Fragment>
        <div data-cy='parameter-legend'>
          <div>{translation('Legend')}</div>
          <div className='pl-5 pr-5 col-6 col-lg-4 col-xl-3 icon-Changeable-On-The-Fly-legend'><span>{translation('Changeable on the Fly')}</span></div>
          <div className='pl-5 pr-5 col-6 col-lg-4 col-xl-3 icon-temporal-legend'><span>{translation('Temporal changed')}</span></div>
          <div className='pl-5 pr-5 col-6 col-lg-4 col-xl-3 storedFlag'><span>{translation('Permanent changed')}</span></div>
        </div>
      </React.Fragment>
    )
  }
}