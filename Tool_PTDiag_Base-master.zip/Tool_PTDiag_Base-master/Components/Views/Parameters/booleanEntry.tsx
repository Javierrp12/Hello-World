import React, { Component, ChangeEvent } from 'react';
import { IParametersItem } from '../../../Datastore/InitialDataInterfaces';
import { IParametersDataModify } from '../../../ConnectingComponents/Parameters/parametersConnector';
import { toUpperCase, toLowerCase, concat, split, replace, toString, map, chain, prop, filter, safeProp, safeHead, eq, intercalate } from '../../../CommonFunctions/pointfreeUtilities';
import { eq2, eq3, getParameterFlag, altBo, safeNewArray, filterPerUserLevel } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface IBooleanEntryProps {
  entryData: IParametersItem;
  parameterInfoData: any;
  userlevel: string;
  translation: (word: string) => string;
  changeParameterCallback: (data: IParametersDataModify) => void;
  resetParameterCallback: (data: IParametersDataModify) => void;
}

interface IBooleanEntryState {
  radioStatus: string | undefined;
}

export class BooleanEntry extends Component<IBooleanEntryProps, IBooleanEntryState> {
  constructor(props: IBooleanEntryProps) {
    super(props);
    this.state = {
      radioStatus: undefined
    };
  }

  render() {
    const { entryData, parameterInfoData, userlevel } = this.props;
    const { translation, changeParameterCallback, resetParameterCallback } = this.props;
    const { radioStatus } = this.state;

    const getFlagParameter = compose(safeHead, compose(chain(filter(eq3(safeProp('name', entryData).getOrElse(''), 'name'))), safeNewArray));
    const getTempFlag = compose(getParameterFlag('tempFlag', 'temp'), getFlagParameter);
    const getStoreFlag = compose(getParameterFlag('storedFlag', 'stored'), getFlagParameter);
    const capitalize = (x: string[]) => {
      const [first, ...remaing] = x;
      return concat(toUpperCase(first), intercalate('', remaing));
    };
    const toArrayString = compose(map(split('')), map(toString));
    const getDefault = compose(map(eq('1')), safeProp('defaultValue'));
    const getDefaultValue = compose(map(capitalize), compose(toArrayString, getDefault));
    const getValue = compose(map(altBo(prop('temp'), prop('stored'))), getFlagParameter);
    const getChangedValue = eq(toLowerCase(toString(getValue(parameterInfoData).getOrElse(getDefaultValue(entryData).getOrElse('false')))));
    const parameterDisabled = filterPerUserLevel(userlevel, safeProp('changeableBy', entryData).getOrElse(''));
    const getRadioState = radioStatus || toLowerCase(toString(getValue(parameterInfoData).getOrElse(getDefaultValue(entryData).getOrElse('false'))));

    return (
      <React.Fragment>
        <tr>
          <td className={`${eq2(true, 'changeableOnTheFly', entryData) ? 'changeable_On_The_Fly' : ''}`}></td>
          <td className={getTempFlag(parameterInfoData)}></td>
          <td className={`${getStoreFlag(parameterInfoData)} boldItem`}>{replace('_ncof', '', safeProp('name', entryData).getOrElse('---'))}</td>
          <td>
            <div className="form-check form-check-inline">
              <input className="form-check-input" type="radio" id={`inlineTrue_${entryData.name}`} disabled={!parameterDisabled} value="true" checked={eq(getRadioState, 'true')} onChange={this.handleValueChanged} />
              <label className="form-check-label" htmlFor={`inlineTrue_${entryData.name}`}>
                True
              </label>
            </div>
            <div className="form-check form-check-inline">
              <input className="form-check-input" type="radio" id={`inlineFalse_${entryData.name}`} disabled={!parameterDisabled} value="false" checked={eq(getRadioState, 'false')} onChange={this.handleValueChanged} />
              <label className="form-check-label" htmlFor={`inlineTrue_${entryData.name}`}>
                False
              </label>
            </div>
          </td>
          <td>
            {parameterDisabled && (
              <React.Fragment>
                <button className={`btn btn-outline-dark btn-sm mr-2 ${getChangedValue(getRadioState) ? 'disabled disabled_button' : ''}`} onClick={() => this.handleClick(getChangedValue(getRadioState), entryData, getRadioState, changeParameterCallback)}>
                  {translation('Apply')}{' '}
                </button>
                {eq(getTempFlag(parameterInfoData), 'tempFlag') && (
                  <button
                    className="btn btn-outline-dark btn-sm mr-2"
                    onClick={() => {
                      resetParameterCallback({ parameter: safeProp('name', entryData).getOrElse('') });
                      this.setState({ radioStatus: undefined });
                    }}
                  >
                    {translation('Reset')}{' '}
                  </button>
                )}
              </React.Fragment>
            )}
          </td>
          <td>---</td>
          <td>{getDefaultValue(entryData).getOrElse('')}</td>
          <td>---</td>
        </tr>
      </React.Fragment>
    );
  }

  private handleValueChanged = (event: ChangeEvent<HTMLInputElement>) => {
    this.setState({ radioStatus: event.currentTarget.value });
  };

  private handleClick = (validValue: boolean, entryData: IParametersItem, radioStatus: string, changeParameterCallback: (data: IParametersDataModify) => void) =>
    eq(validValue, false) ? changeParameterCallback({ parameter: safeProp('name', entryData).getOrElse(''), value: toString(radioStatus) }) : {};
}
