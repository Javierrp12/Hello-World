import React from 'react';
import { IHistoryLogItem } from '../../../Datastore/InitialDataInterfaces';

interface IHistoryLogListProps {
  historyLogEntries: IHistoryLogItem[];
  translation: (word: string) => string;
}

export class HistoryLogList extends React.Component<IHistoryLogListProps> {

  render() {
    const { historyLogEntries } = this.props;
    const { translation } = this.props;

    if (historyLogEntries.length === 0) {
      return <tr><td className='text-center font-weight-bold' colSpan={5}>{translation('No Entries Found')}</td></tr>;
    }

    return (
      historyLogEntries.map((item: IHistoryLogItem, index: number) => (
        <tr key={index}>
          <td>{item.dateTime}</td>
          <td>{item.user}</td>
          <td>{item.action}</td>
          <td>{item.info}</td>
          <td>{item.moduleName}</td>
        </tr>
      ))
    );
  }

}
