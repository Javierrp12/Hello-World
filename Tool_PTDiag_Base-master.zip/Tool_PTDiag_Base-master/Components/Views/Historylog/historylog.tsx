import React, { createRef } from 'react';
import { HistoryLogList } from './historyloglist';
import { ISytemInfo, IAppInfo, IHistoryLogItem } from '../../../Datastore/InitialDataInterfaces';
import { ViewColumn } from '../viewColumnSort';
import { prepareToExportData } from '../../../CommonFunctions/commonFunctions';
import { intercalate, safeProp, sortBy, toLowerCase, toString, map } from '../../../CommonFunctions/pointfreeUtilities';
import {
  getIconColumn, getColumnDirection, checkDirection, safeNewArray, byColumn, reverseArray,
  historylogEntryToString, titleText, safeObjectSearch, historyLogFormat
} from '../../../CommonFunctions/functionsSupport';
import '../view.css';

const compose = require('folktale/core/lambda/compose');

interface IHistoryLogProps {
  appInfo: IAppInfo;
  historyLogEntries: IHistoryLogItem[];
  systemInfo: ISytemInfo;
  getHistorylog: () => void;
  clearHistorylog: () => void;
  t: (word: string) => string;
}

interface IHistoryLogState {
  currentColumn: string;
  direction: string;
}

export class HistoryLog extends React.Component<IHistoryLogProps, IHistoryLogState> {
  exportLink: React.RefObject<HTMLAnchorElement>;
  constructor(props: IHistoryLogProps) {
    super(props);
    this.state = {
      currentColumn: 'timestamp',
      direction: 'up'
    }
    this.exportLink = createRef<HTMLAnchorElement>();
  }

  render() {
    const { historyLogEntries, appInfo } = this.props;
    const { t, getHistorylog, clearHistorylog } = this.props;
    const { currentColumn, direction } = this.state;

    return (
      <React.Fragment>
        <div className='display-view-title' data-cy='view-title'>{t('HistoryLog')}</div>
        <div className='m-2'>
          <button className='btn btn-ptdiag m-2' onClick={clearHistorylog} data-cy='historylog-delete-button'>{t('Delete History Log')}</button>
          <button className='btn btn-ptdiag m-2' onClick={getHistorylog} data-cy='historylog-refresh-button'>{t('Refresh History Log')}</button>
          <button className='btn btn-ptdiag' onClick={() => this.handledExport(appInfo, historyLogEntries)} data-cy='historylog-export-button'>{t('Export History Log')}</button>
          <a className='visually-hidden' href='/#' ref={this.exportLink}>Export HistoryLog Data</a>
        </div>
        <table className='table table-hover table-fixHead display-view-table'>
          <thead>
            <tr>
              <ViewColumn translation={t} column={'TimeStamp'} unit='(UTC)' handleClickSortCallback={(column) => this.handleClickSort(column, currentColumn, direction)} checkForSymbolCallback={(column) => getIconColumn(direction, 'fas fa-sort', currentColumn, toLowerCase(column))} />
              <ViewColumn translation={t} column={'User'} handleClickSortCallback={(column) => this.handleClickSort(column, currentColumn, direction)} checkForSymbolCallback={(column) => getIconColumn(direction, 'fas fa-sort', currentColumn, toLowerCase(column))} />
              <ViewColumn translation={t} column={'Action'} handleClickSortCallback={(column) => this.handleClickSort(column, currentColumn, direction)} checkForSymbolCallback={(column) => getIconColumn(direction, 'fas fa-sort', currentColumn, toLowerCase(column))} />
              <ViewColumn translation={t} column={'Info'} handleClickSortCallback={(column) => this.handleClickSort(column, currentColumn, direction)} checkForSymbolCallback={(column) => getIconColumn(direction, 'fas fa-sort', currentColumn, toLowerCase(column))} />
              <ViewColumn translation={t} column={'Module'} handleClickSortCallback={(column) => this.handleClickSort(column, currentColumn, direction)} checkForSymbolCallback={(column) => getIconColumn(direction, 'fas fa-sort', currentColumn, toLowerCase(column))} />
            </tr>
          </thead>
          <tbody data-cy='historylog-table'>
            <HistoryLogList
              historyLogEntries={this.sortHistoryLogs(historyLogEntries, currentColumn, direction)}
              translation={t}
            />
          </tbody>
        </table>
      </React.Fragment>
    );
  }

  componentDidMount() {
    this.props.getHistorylog();
  }

  private handledExport = (appInfo: IAppInfo, historyLogEntries: IHistoryLogItem[]): void => {
    const getProjectName = titleText(toString(safeObjectSearch('project.name', appInfo).getOrElse('')), ':');
    const getProjectPackage = titleText(toString(safeObjectSearch('project.packageName', appInfo).getOrElse('')), ':');
    const arrayToString = compose(map(map(historylogEntryToString)), safeNewArray)
    const gethistorylogDataString = compose(map(intercalate('\n')), arrayToString);
    const expectedString = historyLogFormat(getProjectName('Project'), getProjectPackage('Package'), gethistorylogDataString(historyLogEntries).getOrElse(''));
    prepareToExportData({ name: 'HistoryLogs.txt', type: 'text/txt;charset=utf-8', expectedString: expectedString('Project\nPackage\n\nData') }, this.exportLink);
  }

  private handleClickSort = (column: string, currentColumn: string, direction: string): void => {
    const setDirection = compose(checkDirection(direction), getColumnDirection(toLowerCase(column)));
    this.setState({ currentColumn: toLowerCase(column), direction: setDirection(currentColumn) });
  }

  private sortHistoryLogs = (historyLogEntries: IHistoryLogItem[], currentColumn: string, direction: string): IHistoryLogItem[] => {
    const historyLogColumns = {
      timestamp: 'dateTime',
      module: 'moduleName',
      action: 'action',
      info: 'info',
      user: 'user'
    };
    const createNewSortedArray = compose(map(sortBy(byColumn(safeProp(currentColumn, historyLogColumns).getOrElse(''), 'dateTime'))), safeNewArray);
    const sortHistoryLogArray = compose(map(reverseArray(direction)), createNewSortedArray);
    return sortHistoryLogArray(historyLogEntries).getOrElse([]);
  }

}
