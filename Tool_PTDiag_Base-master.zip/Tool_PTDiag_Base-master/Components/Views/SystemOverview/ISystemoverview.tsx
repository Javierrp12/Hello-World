export interface IComponent {
  height: number;
  isOnline: boolean;
  module: string;
  name: string;
  state: string;
  symbol: string;
  type: string;
  width: number;
  xPosition: number;
  yPosition: number;
  speed: number;
  command: string;
  info: IInfo[];
  componentKey?: string;
}

export interface IAnalogValue {
  name: string;
  dataStore: string;
  category: string;
  module: string;
  xAPosition: number;
  yAPosition: number;
  value: string;
  hideName: string;
}

export interface IDigitalFlag {
  name: string;
  dataStore: string;
  category: string;
  module: string;
  xDPosition: number;
  yDPosition: number;
  status: boolean;
  hiddenIfFalse: boolean;
  severity: string;
}

export interface IExtraComponents {
  name: string;
  xPosition: number;
  yPosition: number;
  height: number;
  width: number;
  type: string;
  componentKey?: string;
}

export interface IInfo {
  name: string;
  trigered: boolean;
  state: string;
}

export interface IComponentstate {
  'Init': { name: string, color: string },
  'Selftest': { name: string, color: string },
  'Run': { name: string, color: string },
  'Ready': { name: string, color: string },
  'Stop': { name: string, color: string },
  'TemporaryError': { name: string, color: string },
  'Error': { name: string, color: string },
  'Undefined': { name: string, color: string },
}

export interface IConnections {
  name: string;
  type: string;
  xPosition: number;
  yPosition: number;
  orientation: string
  height: number;
  width: number;
  componentKey?: string;
}