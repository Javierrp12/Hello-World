import React, { createRef } from 'react';
import { useStrictMode, Stage, Layer } from 'react-konva';
import { KonvaEventObject } from 'konva/types/Node';
import { Modules } from '../../../Datastore/ModelData/modulesTypes';
import { PTDeveloper } from '../../../Datastore/StateData/userLevelTypes';
import {
  IComponent, IAnalogValue, IExtraComponents, IConnections, IDigitalFlag
} from './ISystemoverview';
import {
  IDeleteDigitalData, IDeleteAnalogData, IDeleteComponentData, IAnalogData,
  IDigitalData, IComponentData, IComponentSize
} from '../../../Datastore/ModelData/modelActionCreator';
import { prepareToExportData } from '../../../CommonFunctions/commonFunctions';
import { prop, reduce, map } from '../../../CommonFunctions/pointfreeUtilities';
import {
  filterPerUserLevel, maybeA, safeGetKeysObject, addComponentKeyToComponent,
  deleteComponent, dragEndComponent, SizeEndComponent, SizeEndConnection, deleteAnalog,
  dragEndAnalog, deleteDigital, dragEndDigital, createArrayComponents, safeGetValuesObject,
  objToString, clearData, clearComponentData, clearAnalogValuesData, clearDigitalFlagsData,
  schematicFormat, titleText
} from '../../../CommonFunctions/functionsSupport';
import { AddComponentModalConnector } from '../../../ConnectingComponents/SystemOverview/addComponentModalConnector';
import { AddComponentModal } from './addComponentModal';
import { SchematicComponent } from './SchematicComponents/schematicComponent';
import { SchematicAnalogValue } from './SchematicComponents/schematicAnalogValue';
import { SchematicDigitalFlags } from './SchematicComponents/schematicDigitalFlag';
import { SchematicConnection } from './SchematicComponents/schematicConnection';
import { SchematicExtraComponent } from './SchematicComponents/schematicExtraComponent';
import './systemOverview.css';

const compose = require('folktale/core/lambda/compose');
const curry = require('folktale/core/lambda/curry');

interface ISystemOverviewProps {
  schematicComponents: any;
  schematicExtraComponents: any;
  schematicConnections: any;
  schematicAnalogValues: any;
  schematicDigitalFlags: any;
  editMode: boolean;
  userlevel: string;
  updateModuleActive: (moduleName: keyof typeof Modules) => void;
  updateEditModeCallback: () => void;
  updateAnalogValuePositionCallback: (analogData: IAnalogData) => void;
  updateDigitalFlagPositionCallback: (digitalData: IDigitalData) => void;
  updateComponentPositionCallback: (componentData: IComponentData) => void;
  updateComponentSizeCallback: (componentData: IComponentSize) => void;
  deleteComponentCallback: (componentData: IDeleteComponentData) => void;
  deleteAnalogValueCallback: (analogData: IDeleteAnalogData) => void;
  deleteDigitalFlagCallback: (digitalData: IDeleteDigitalData) => void;
  t: (word: string) => string;
}

interface ISystemOverviewState {
  scaleFactor: number;
  showModalAddComponent: boolean;
  width: number;
  heigth: number;
}

interface IExtraComponentProps {
  schematicExtraComponents: any;
  editMode: boolean;
  deleteComponentCallback: (componentData: IDeleteComponentData) => void;
  updateComponentPositionCallback: (componentData: IComponentData) => void;
  updateComponentSizeCallback: (componentData: IComponentSize) => void;
}

interface IComponentProps {
  schematicComponents: any;
  editMode: boolean;
  updateModuleActive: (moduleName: keyof typeof Modules) => void;
  deleteComponentCallback: (componentData: IDeleteComponentData) => void;
  updateComponentPositionCallback: (componentData: IComponentData) => void;
}

interface ISchematicConnections {
  schematicConnections: any;
  editMode: boolean;
  deleteComponentCallback: (componentData: IDeleteComponentData) => void;
  updateComponentPositionCallback: (componentData: IComponentData) => void;
  updateComponentSizeCallback: (componentData: IComponentSize) => void;
}

interface ISchematicAnalogProps {
  schematicAnalogValues: any;
  editMode: boolean;
  deleteAnalogValueCallback: (analogData: IDeleteAnalogData) => void;
  updateAnalogValuePositionCallback: (analogData: IAnalogData) => void;
}

interface ISchematicDigitalProps {
  schematicDigitalFlags: any;
  editMode: boolean;
  deleteDigitalFlagCallback: (digitalData: IDeleteDigitalData) => void;
  updateDigitalFlagPositionCallback: (digitalData: IDigitalData) => void;
}

useStrictMode(true);
const ConnectorModalAddComponent = AddComponentModalConnector(AddComponentModal);

export class SystemOverview extends React.Component<ISystemOverviewProps, ISystemOverviewState> {
  private exportLink: React.RefObject<HTMLAnchorElement>;
  private defaultWidthWindow: number = 1824;
  private defaultHeightWindow: number = 772;
  constructor(props: ISystemOverviewProps) {
    super(props);
    this.state = {
      scaleFactor: 0.5,
      width: (window.innerWidth * 0.97),
      heigth: (window.innerHeight * 0.80),
      showModalAddComponent: false,
    }
    this.exportLink = createRef<HTMLAnchorElement>();
  }

  render() {
    const { userlevel, editMode, schematicComponents, schematicExtraComponents,
      schematicConnections, schematicAnalogValues, schematicDigitalFlags } = this.props;
    const { t, updateEditModeCallback, deleteComponentCallback, updateModuleActive, updateComponentPositionCallback, updateComponentSizeCallback } = this.props;
    const { deleteAnalogValueCallback, updateAnalogValuePositionCallback, deleteDigitalFlagCallback, updateDigitalFlagPositionCallback } = this.props;
    const { showModalAddComponent, scaleFactor, width, heigth } = this.state;

    return (
      <React.Fragment>
        {showModalAddComponent === true &&
          <ConnectorModalAddComponent handleShowModalAddComponent={() => this.handleShowModalAddComponent(showModalAddComponent)} />
        }
        <div className='display-view-title' data-cy='view-title'>{t('System Overview')}</div>
        { filterPerUserLevel(userlevel, PTDeveloper) &&
          <div>
            <div className="form-check" data-cy='systemoverview-editmode-parent'>
              <input className="form-check-input" type="checkbox" checked={editMode} onChange={updateEditModeCallback} id="editMode" />
              <label className="form-check-label" htmlFor="editMode">
                {t('Schematic Edit Mode')}
              </label>
            </div>
            {editMode === true &&
              <React.Fragment>
                <button className='btn btn-ptdiag m-2' onClick={() => this.handleShowModalAddComponent(showModalAddComponent)} data-cy='systemoverview-add-button'>{t('Add Component')}</button>
                <button className='btn btn-ptdiag m-2' onClick={() => this.handleExportSchematic(schematicComponents, schematicExtraComponents, schematicConnections, schematicAnalogValues, schematicDigitalFlags)} data-cy='systemoverview-export-button'>{t('Export Schematic')}</button>
                <a className='visually-hidden' href='/#' ref={this.exportLink}>Export Schematic</a>
              </React.Fragment>
            }
          </div>
        }
        <Stage className={`state-parent ${(editMode === true) ? 'border' : ''}`} width={width} height={heigth} scaleX={scaleFactor} scaleY={scaleFactor} >
          <Layer>
            {
              this.drawSchematicExtraComponents({ schematicExtraComponents, editMode, deleteComponentCallback, updateComponentPositionCallback, updateComponentSizeCallback })
            }
            {
              this.drawSchematicComponents({ schematicComponents, editMode, updateModuleActive, deleteComponentCallback, updateComponentPositionCallback })
            }
            {
              this.drawSchematicConnections({ schematicConnections, editMode, deleteComponentCallback, updateComponentPositionCallback, updateComponentSizeCallback })
            }
            {
              this.drawSchematicAnalogValues({ schematicAnalogValues, editMode, deleteAnalogValueCallback, updateAnalogValuePositionCallback })
            }
            {
              this.drawSchematicDigitalFlags({ schematicDigitalFlags, editMode, deleteDigitalFlagCallback, updateDigitalFlagPositionCallback })
            }
          </Layer>
        </Stage>
      </React.Fragment >
    );
  }

  componentDidMount() {
    const innerWidth: number = maybeA(window).map(prop('innerWidth')).getOrElse(1);
    const defaultWidthWindow: number = maybeA(this.defaultWidthWindow).getOrElse(1);
    const defaultHeightWindow: number = maybeA(this.defaultHeightWindow).getOrElse(1);
    this.updateSystemOverviewDimentions(innerWidth, defaultWidthWindow, defaultHeightWindow);
    window.addEventListener('resize', this.updateDimensions);
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.updateDimensions);
  }

  private updateDimensions = (): void => {
    const innerWidth: number = maybeA(window).map(prop('innerWidth')).getOrElse(1);
    const defaultWidthWindow: number = maybeA(this.defaultWidthWindow).getOrElse(1);
    const defaultHeightWindow: number = maybeA(this.defaultHeightWindow).getOrElse(1);
    this.updateSystemOverviewDimentions(innerWidth, defaultWidthWindow, defaultHeightWindow);
  }

  private updateSystemOverviewDimentions = (innerWidth: number = 1, defaultWidthWindow: number = 1, defaultHeightWindow: number = 1): void => {
    const scaleFactor = (innerWidth * 0.95) / defaultWidthWindow;
    this.setState({ scaleFactor: scaleFactor, width: defaultWidthWindow * scaleFactor, heigth: defaultHeightWindow * scaleFactor });
  }

  private handleShowModalAddComponent = (showModalAddComponent: boolean): void => {
    this.setState({ showModalAddComponent: !showModalAddComponent });
  }

  private drawSchematicExtraComponents = (extraData: IExtraComponentProps) => {
    const createExtraComponent = curry(1, (x: IExtraComponents) => <SchematicExtraComponent
      key={`ExtraComponent_${x.type}_${x.name}`}
      componentData={{
        name: x.name, x: x.xPosition, y: x.yPosition, width: x.width,
        height: x.height, type: x.type, fontSize: 18, fontFamily: 'Segoe UI',
        componentKey: x.componentKey, editMode: extraData.editMode
      }}
      handleClickDelete={(event: KonvaEventObject<MouseEvent>): void => extraData.deleteComponentCallback(deleteComponent('schematicExtraComponents', event))}
      handleDragEnd={(event: KonvaEventObject<MouseEvent>): void => extraData.updateComponentPositionCallback(dragEndComponent('schematicExtraComponents', event))}
      handleTransformEnd={(event: KonvaEventObject<MouseEvent>): void => extraData.updateComponentSizeCallback(SizeEndComponent('schematicExtraComponents', event))}
    />);
    const addComponentKey = reduce(addComponentKeyToComponent(extraData.schematicExtraComponents), []);
    const drawExtraComponents = compose(compose(map(map(createExtraComponent)), map(addComponentKey)), safeGetKeysObject);
    return drawExtraComponents(extraData.schematicExtraComponents).getOrElse([]);
  }

  private drawSchematicComponents = (componentData: IComponentProps) => {
    const createComponent = curry(1, (x: IComponent) => <SchematicComponent
      key={`Component_${x.name}`}
      componentData={{
        name: x.name, x: x.xPosition, y: x.yPosition, width: x.width,
        height: x.height, type: x.type, fontSize: 18, fontFamily: 'Segoe UI',
        componentKey: x.componentKey, editMode: componentData.editMode, isOnline: x.isOnline,
        state: x.state, symbol: x.symbol, speed: x.speed, command: x.command, info: x.info, module: x.module
      }}
      handleClickRedirect={(module: string) => componentData.updateModuleActive(module as keyof typeof Modules)}
      handleClickDelete={(event: KonvaEventObject<MouseEvent>) => componentData.deleteComponentCallback(deleteComponent('schematicComponents', event))}
      handleDragEnd={(event: KonvaEventObject<MouseEvent>) => componentData.updateComponentPositionCallback(dragEndComponent('schematicComponents', event))}
    />);
    const addComponentKey = reduce(addComponentKeyToComponent(componentData.schematicComponents), []);
    const drawComponents = compose(compose(map(map(createComponent)), map(addComponentKey)), safeGetKeysObject);
    return drawComponents(componentData.schematicComponents).getOrElse([]);
  }

  private drawSchematicConnections = (componentData: ISchematicConnections) => {
    const createConnection = curry(1, (x: IConnections) => <SchematicConnection
      key={`Connection_${x.name}`}
      componentData={{
        name: x.name, x: x.xPosition, y: x.yPosition, width: x.width,
        height: x.height, type: x.type, componentKey: x.componentKey,
        editMode: componentData.editMode, orientation: x.orientation
      }}
      handleClickDelete={(event: KonvaEventObject<MouseEvent>): void => componentData.deleteComponentCallback(deleteComponent('schematicConnections', event))}
      handleDragEnd={(event: KonvaEventObject<MouseEvent>): void => componentData.updateComponentPositionCallback(dragEndComponent('schematicConnections', event))}
      handleTransformEnd={(event: KonvaEventObject<MouseEvent>): void => componentData.updateComponentSizeCallback(SizeEndConnection(x, 'schematicConnections', event))}
    />);
    const addComponentKey = reduce(addComponentKeyToComponent(componentData.schematicConnections), []);
    const drawConnections = compose(compose(map(map(createConnection)), map(addComponentKey)), safeGetKeysObject);
    return drawConnections(componentData.schematicConnections).getOrElse([]);
  }

  private drawSchematicAnalogValues = (componentData: ISchematicAnalogProps) => {
    const createAnalogValue = curry(1, (x: IAnalogValue) => <SchematicAnalogValue
      key={`${x.module}_${x.name}`}
      componentData={{
        name: x.name, x: x.xAPosition, y: x.yAPosition, editMode: componentData.editMode,
        value: x.value, module: x.module, datastore: x.dataStore, category: x.category, hideName: x.hideName,
        fontSize: 18, fontFamily: 'Segoe UI'
      }}
      handleClickDelete={(event: KonvaEventObject<MouseEvent>) => componentData.deleteAnalogValueCallback(deleteAnalog('schematicAnalogValues', event))}
      handleDragEnd={(event: KonvaEventObject<MouseEvent>) => componentData.updateAnalogValuePositionCallback(dragEndAnalog('schematicAnalogValues', event))}
    />);
    const drawAnalogValues = compose(compose(map(map(createAnalogValue)), map(reduce(createArrayComponents, []))), safeGetValuesObject);
    return drawAnalogValues(componentData.schematicAnalogValues).getOrElse([]);
  }

  private drawSchematicDigitalFlags = (componentData: ISchematicDigitalProps) => {
    const createDigitalFlag = curry(1, (x: IDigitalFlag) => <SchematicDigitalFlags
      key={`${x.module}_${x.name}`}
      componentData={{
        name: x.name, x: x.xDPosition, y: x.yDPosition, editMode: componentData.editMode,
        status: x.status, module: x.module, datastore: x.dataStore, category: x.category,
        fontSize: 18, fontFamily: 'Segoe UI', severity: x.severity, hiddenIfFalse: x.hiddenIfFalse
      }}
      handleClickDelete={(event: KonvaEventObject<MouseEvent>) => componentData.deleteDigitalFlagCallback(deleteDigital('schematicDigitalFlags', event))}
      handleDragEnd={(event: KonvaEventObject<MouseEvent>) => componentData.updateDigitalFlagPositionCallback(dragEndDigital('schematicDigitalFlags', event))}
    />);
    const drawSchematicDigitalFlags = compose(compose(map(map(createDigitalFlag)), map(reduce(createArrayComponents, []))), safeGetValuesObject);
    return drawSchematicDigitalFlags(componentData.schematicDigitalFlags).getOrElse([]);
  }

  private handleExportSchematic = (schematicComponents: any, schematicExtraComponents: any, schematicConnections: any, schematicAnalogValues: any, schematicDigitalFlags: any): void => {
    const getSchematicComponent = compose(compose(map(objToString), map(reduce(clearComponentData(schematicComponents), {}))), safeGetKeysObject);
    const getSchematicAnalogValues = compose(compose(map(objToString), map(reduce(clearData(clearAnalogValuesData, schematicAnalogValues), {}))), safeGetKeysObject);
    const getschematicDigitalFlags = compose(compose(map(objToString), map(reduce(clearData(clearDigitalFlagsData, schematicDigitalFlags), {}))), safeGetKeysObject);
    const getSchematicExtraComponents = objToString;
    const getSchematicConnections = objToString;

    const getSchematicComponentsFormat = titleText(getSchematicComponent(schematicComponents).getOrElse(''), '=');
    const getSchematicAnalogValuesFormat = titleText(getSchematicAnalogValues(schematicAnalogValues).getOrElse(''), '=');
    const getSchematicDigitalFlagsFormat = titleText(getschematicDigitalFlags(schematicDigitalFlags).getOrElse(''), '=');
    const getSchematicExtraComponentsFormat = titleText(getSchematicExtraComponents(schematicExtraComponents), '=');
    const getSchematicConnectionsFormat = titleText(getSchematicConnections(schematicConnections), '=');
    const expectedString = schematicFormat(getSchematicComponentsFormat('schematicComponents'),
      getSchematicExtraComponentsFormat('schematicExtraComponents'),
      getSchematicConnectionsFormat('schematicConnections'),
      getSchematicAnalogValuesFormat('schematicAnalogValues'),
      getSchematicDigitalFlagsFormat('schematicDigitalFlags'));

    prepareToExportData({
      name: 'schematicElements.js',
      type: 'text/js;charset=utf-8',
      expectedString: expectedString('var schematicComponents\n\nvar schematicExtraComponents\n\nvar schematicConnections \n\nvar schematicAnalogValues \n\nvar schematicDigitalFlags')
    },
      this.exportLink);
  }

}
