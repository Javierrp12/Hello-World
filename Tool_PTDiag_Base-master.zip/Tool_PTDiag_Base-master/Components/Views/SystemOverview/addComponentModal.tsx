import React, { ChangeEvent } from 'react';
import { baseComponentsData } from './baseComponentData';
import { ModalWindow } from '../modalWindow';
import { ModuleSection } from './ComponentSections/moduleSection';
import { ConverterSection } from './ComponentSections/converterSection';
import { FANSection } from './ComponentSections/fanSection';
import { ContactorSection } from './ComponentSections/contactorSection';
import { ComponentSection } from './ComponentSections/componentSection';
import { RectangleSection } from './ComponentSections/rectangleSection';
import { AnalogValueSection } from './ComponentSections/analogValueSection';
import { DigitalValueSection } from './ComponentSections/digitalFlagSection';
import { ConnectionSection } from './ComponentSections/connectionSection';
import { safeHead, safeProp, map, filter } from '../../../CommonFunctions/pointfreeUtilities';
import { getFirstValueOption, getModuleSignals, addComponentData, safeObjectSearch } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');
const curry = require('folktale/core/lambda/curry');

interface IAddComponentModalProps {
  options: IOption[];
  modules: string[];
  userlevel: string;
  modulesData: any;
  signalAnalog: string;
  signalDigital: string;
  t: (word: string) => string;
  handleShowModalAddComponent: () => void;
  addComponentToSchematicCallback: (componentData: any) => void;
}

interface IAddComponentModalState {
  option: string;
  module: string;
  name: string;
  signalAnalog: string;
  signalDigital: string;
  symbol: string;
  symbolFan: string;
  symbolContactor: string;
  connection: string;
  orientation: string;
  signalDigitalCheck: boolean;
  signalAnalogCheck: boolean;
  width: number;
  height: number;
  length: number;
}

interface IOption {
  option: string;
  value: string;
}

interface IModuleCurrentState {
  userlevel: string;
  modulesData: any;
}

export class AddComponentModal extends React.Component<IAddComponentModalProps, IAddComponentModalState> {
  constructor(props: IAddComponentModalProps) {
    super(props);
    this.state = {
      option: getFirstValueOption(this.props.options).getOrElse(''),
      module: safeHead(this.props.modules).getOrElse(''),
      name: '',
      signalAnalog: this.props.signalAnalog,
      signalDigital: this.props.signalDigital,
      symbol: 'None',
      symbolFan: 'MainFan',
      symbolContactor: 'Contactor',
      connection: 'None',
      orientation: 'vertical',
      signalDigitalCheck: false,
      signalAnalogCheck: false,
      width: 10,
      height: 10,
      length: 10
    };
  }

  render() {
    const { t, handleShowModalAddComponent, addComponentToSchematicCallback } = this.props;
    const { options, modules, modulesData, userlevel } = this.props;
    const { option, module, symbol, name, symbolFan, symbolContactor, width, height, length, signalAnalog, signalDigital, signalDigitalCheck, signalAnalogCheck, connection, orientation } = this.state;

    return (
      <ModalWindow>
        <div className="modal-ptdiag">
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header" data-cy="modal-title">
                <div className="display-view-title">{t('Add Component')}</div>
                <button className="close" onClick={handleShowModalAddComponent}>
                  <span>x</span>
                </button>
              </div>
              <div className="modal-body" data-cy="modal-content">
                <div className="form-group">
                  <label htmlFor="formControlComponentsOptions">{t('Components')}</label>
                  <select className="form-control" id="formControlComponentsOptions" name="option" value={option} onChange={this.handleOptionSelect}>
                    {options.map((option: IOption) => (
                      <option key={option.option} value={option.value}>
                        {option.option}
                      </option>
                    ))}
                  </select>
                </div>
                {this.addComponentSection(option, userlevel, modulesData, module, signalAnalog, signalDigital, signalDigitalCheck, signalAnalogCheck, name, modules, symbol, symbolFan, symbolContactor, width, height, length, connection, orientation, t)}
              </div>
              <div className="modal-footer" data-cy="modal-buttons">
                <button className="btn btn-secondary m-2" onClick={handleShowModalAddComponent}>
                  {t('Close')}
                </button>
                <button className="btn btn-ptdiag" onClick={() => this.handleAddComponent(this.state, modulesData, userlevel, handleShowModalAddComponent, addComponentToSchematicCallback)}>
                  {t('Add Component')}
                </button>
              </div>
            </div>
          </div>
        </div>
      </ModalWindow>
    );
  }

  private handleOptionSelect = (event: ChangeEvent<HTMLSelectElement>): void => {
    this.setState({ option: event.target.value });
  };

  private handleModuleSelect = (event: ChangeEvent<HTMLSelectElement>, state: IModuleCurrentState): void => {
    event.persist();
    const getModule = safeObjectSearch('target.value');
    const getModuleData = safeProp('modulesData');
    const getState = safeProp('userlevel');
    this.setState({ module: getModule(event).getOrElse('') }, () => {
      const signalAnalogData = safeHead(getModuleSignals(getModuleData(state).getOrElse({}), getModule(event).getOrElse(''), 'analog', getState(state).getOrElse(''))).getOrElse({});
      const signalDigitalData = safeHead(getModuleSignals(getModuleData(state).getOrElse({}), getModule(event).getOrElse(''), 'digital', getState(state).getOrElse(''))).getOrElse({});

      this.setState({
        signalAnalog: `${safeProp('category', signalAnalogData).getOrElse('')}_${safeProp('name', signalAnalogData).getOrElse('')}`,
        signalDigital: `${safeProp('category', signalDigitalData).getOrElse('')}_${safeProp('name', signalDigitalData).getOrElse('')}`
      });
    });
  };

  private handleSymbolSelect = (event: ChangeEvent<HTMLSelectElement>): void => {
    this.setState({ symbol: event.target.value });
  };

  private hadleNameInput = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ name: event.target.value });
  };

  private handleSymbolFanSelect = (event: ChangeEvent<HTMLSelectElement>): void => {
    this.setState({ symbolFan: event.target.value });
  };

  private handleSymbolContactorSelect = (event: ChangeEvent<HTMLSelectElement>): void => {
    this.setState({ symbolContactor: event.target.value });
  };

  private handleWidthInput = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ width: Number(event.target.value) });
  };

  private handleHeightInput = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ height: Number(event.target.value) });
  };

  private handleAnalogSignalSelect = (event: ChangeEvent<HTMLSelectElement>): void => {
    this.setState({ signalAnalog: event.target.value });
  };

  private handleDigitalSignalSelect = (event: ChangeEvent<HTMLSelectElement>): void => {
    this.setState({ signalDigital: event.target.value });
  };

  private handleOrientationInput = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ orientation: event.target.value });
  };

  private handleConnectionSelect = (event: ChangeEvent<HTMLSelectElement>): void => {
    this.setState({ connection: event.target.value });
  };

  private handleLengthInput = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ length: Number(event.target.value) });
  };

  private handleCheckDigitalInput = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ signalDigitalCheck: event.target.checked });
  };

  private handleCheckAnalogInput = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ signalAnalogCheck: event.target.checked });
  };

  private addComponentSection = (
    option: string,
    userlevel: string,
    modulesData: any,
    module: string,
    signalAnalog: string,
    signalDigital: string,
    signalDigitalCheck: boolean,
    signalAnalogCheck: boolean,
    name: string,
    modules: string[],
    symbol: string,
    symbolFan: string,
    symbolContactor: string,
    width: number,
    height: number,
    length: number,
    connection: string,
    orientation: string,
    t: (word: string) => string
  ) => {
    const componentSections = {
      module: <ModuleSection module={module} name={name} modules={modules} translation={t} symbol={symbol} handleModuleChange={(event) => this.handleModuleSelect(event, { modulesData, userlevel })} handleSymbolChange={this.handleSymbolSelect} handleNameChange={this.hadleNameInput} />,
      converter: <ConverterSection module={module} name={name} modules={modules} translation={t} handleModuleChange={(event) => this.handleModuleSelect(event, { modulesData, userlevel })} handleNameChange={this.hadleNameInput} />,
      aif: <ComponentSection name={name} translation={t} handleNameChange={this.hadleNameInput} />,
      fan: <FANSection name={name} symbolFan={symbolFan} translation={t} handleNameChange={this.hadleNameInput} handleFanSymbolChange={this.handleSymbolFanSelect} />,
      legend: <ComponentSection name={name} translation={t} handleNameChange={this.hadleNameInput} />,
      contactors: <ContactorSection name={name} symbolContactor={symbolContactor} translation={t} handleNameChange={this.hadleNameInput} handleContactorSymbolChange={this.handleSymbolContactorSelect} />,
      info: <ComponentSection name={name} translation={t} handleNameChange={this.hadleNameInput} />,
      text: <ComponentSection name={name} translation={t} handleNameChange={this.hadleNameInput} />,
      rectangle: <RectangleSection name={name} width={width} height={height} translation={t} handleNameChange={this.hadleNameInput} handleHeightChange={this.handleHeightInput} handleWidthChange={this.handleWidthInput} />,
      '3Phase': <ComponentSection name={name} translation={t} handleNameChange={this.hadleNameInput} />,
      diode: <ComponentSection name={name} translation={t} handleNameChange={this.hadleNameInput} />,
      fuse: <ComponentSection name={name} translation={t} handleNameChange={this.hadleNameInput} />,
      analogValue: (
        <AnalogValueSection
          module={module}
          modules={modules}
          modulesData={modulesData}
          userlevel={userlevel}
          translation={t}
          signalAnalog={signalAnalog}
          signalAnalogCheck={signalAnalogCheck}
          handleModuleChanged={(event) => this.handleModuleSelect(event, { modulesData, userlevel })}
          handleSignalChanged={this.handleAnalogSignalSelect}
          handleAnalogCheck={this.handleCheckAnalogInput}
        />
      ),
      digitalFlag: (
        <DigitalValueSection
          module={module}
          modules={modules}
          signalDigitalCheck={signalDigitalCheck}
          modulesData={modulesData}
          userlevel={userlevel}
          translation={t}
          signalDigital={signalDigital}
          handleModuleChanged={(event) => this.handleModuleSelect(event, { modulesData, userlevel })}
          handleSignalChanged={this.handleDigitalSignalSelect}
          handleDigitalCheck={this.handleCheckDigitalInput}
        />
      ),
      connection: (
        <ConnectionSection
          name={name}
          length={length}
          orientation={orientation}
          connection={connection}
          translation={t}
          handleNameChange={this.hadleNameInput}
          handleOrientationChange={this.handleOrientationInput}
          handleConnectionChanged={this.handleConnectionSelect}
          handleLengthChanged={this.handleLengthInput}
        />
      )
    };
    return safeProp(option, componentSections).getOrElse(null);
  };

  private handleAddComponent = (state: IAddComponentModalState, modulesData: any, userlevel: string, closeModalWindowFn: () => void, addComponent: (componentData: any) => void) => {
    const getFanData = (state: IAddComponentModalState) => {
      return state.symbolFan === 'MainFan' ? { name: state.name, symbol: state.symbolFan, componentType: 'schematicComponents' } : { name: state.name, symbol: state.symbolFan, height: 60, width: 60, componentType: 'schematicComponents' };
    };
    const getAnalogValueData = (state: IAddComponentModalState) => {
      const filterSignal = curry(2, (signalName: string, x: any) => `${x.category}_${x.name}` === signalName);
      const checkData = curry(2, (_state: any, x: any) => ({ module: _state.module, dataStore: x.datastore, category: x.category, name: x.name, componentType: 'schematicAnalogValues', hideName: state.signalAnalogCheck }));
      const getAnalogValueData = compose(map(checkData(state)), compose(safeHead, filter(filterSignal(state.signalAnalog))));
      return getAnalogValueData(getModuleSignals(modulesData, state.module, 'analog', userlevel)).getOrElse({});
    };
    const getDigitalFlagData = (state: IAddComponentModalState) => {
      const filterSignal = curry(2, (signalName: string, x: any) => `${x.category}_${x.name}` === signalName);
      const checkData = curry(2, (_state: any, x: any) => ({ module: _state.module, dataStore: x.datastore, category: x.category, name: x.name, componentType: 'schematicDigitalFlags', hiddenIfFalse: state.signalDigitalCheck, severity: x.severity }));
      const getDigitalValueData = compose(map(checkData(state)), compose(safeHead, filter(filterSignal(state.signalDigital))));
      return getDigitalValueData(getModuleSignals(modulesData, state.module, 'digital', userlevel)).getOrElse({});
    };
    const getConnectionData = (state: IAddComponentModalState) => {
      return state.orientation === 'vertical'
        ? { name: state.name, width: 1, height: Number(state.length), type: state.connection, orientation: state.orientation, componentType: 'schematicConnections' }
        : { name: state.name, height: 1, width: Number(state.length), type: state.connection, orientation: state.orientation, componentType: 'schematicConnections' };
    };

    const component = {
      module: { name: state.name, module: state.module, symbol: state.symbol, componentType: 'schematicComponents' },
      converter: { name: state.name, componentType: 'schematicComponents' },
      aif: { name: state.name, componentType: 'schematicComponents' },
      fan: getFanData(state),
      legend: { name: state.name, componentType: 'schematicComponents' },
      contactors: { name: state.name, symbol: state.symbolContactor, componentType: 'schematicComponents' },
      fuse: { name: state.name, componentType: 'schematicComponents' },
      info: { name: state.name, componentType: 'schematicComponents' },
      text: { name: state.name, componentType: 'schematicExtraComponents' },
      rectangle: { name: state.name, height: state.height, width: state.width, componentType: 'schematicExtraComponents' },
      '3Phase': { name: state.name, componentType: 'schematicExtraComponents' },
      diode: { name: state.name, componentType: 'schematicExtraComponents' },
      analogValue: getAnalogValueData(state),
      digitalFlag: getDigitalFlagData(state),
      connection: getConnectionData(state)
    };

    const addNewComponent = map(addComponentData(safeProp(state.option, baseComponentsData)));
    addNewComponent(safeProp(state.option, component)).matchWith({
      Just: (value: any) => addComponent(value.getOrElse()),
      Nothing: () => 'Nothing was found'
    });
    closeModalWindowFn();
  };
}
