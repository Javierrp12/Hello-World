import React, { Component, ChangeEvent } from 'react';
import { getModuleSignals } from '../../../../CommonFunctions/functionsSupport';

interface IDigitalValueSectionProps {
  module: string;
  signalDigital: string;
  userlevel: string;
  modules: string[];
  modulesData: any;
  signalDigitalCheck: boolean;
  translation: (word: string) => string;
  handleModuleChanged: (event: ChangeEvent<HTMLSelectElement>) => void;
  handleSignalChanged: (event: ChangeEvent<HTMLSelectElement>) => void;
  handleDigitalCheck: (event: ChangeEvent<HTMLInputElement>) => void;
}

export class DigitalValueSection extends Component<IDigitalValueSectionProps> {
  render() {
    const { module, modules, signalDigital, userlevel, modulesData, signalDigitalCheck } = this.props;
    const { translation, handleModuleChanged, handleSignalChanged, handleDigitalCheck } = this.props;

    return (
      <React.Fragment>
        <div className="form-group">
          <label htmlFor="moduleSelect">{translation('Module')}</label>
          <select className="form-control" id="moduleSelect" name='module' value={module} onChange={handleModuleChanged}>
            {modules.map((module: string) => <option key={module} value={module}>{module}</option>)}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="formControlSignal">{translation('Signal')}</label>
          <select className="form-control" id="formControlSignal" name='signalDigital' value={signalDigital} onChange={handleSignalChanged}>
            {
              getModuleSignals(modulesData, module, 'digital', userlevel).map((signal: any) => (
                <option key={`${signal.category}_${signal.name}`} value={`${signal.category}_${signal.name}`}>{signal.name}</option>
              ))
            }
          </select>
        </div>
        <div className="form-group form-check">
          <input type="checkbox" className="form-check-input" name='signalDigitalCheck' id="digitalSignalCheck" checked={signalDigitalCheck} onChange={handleDigitalCheck} />
          <label className="form-check-label" htmlFor="digitalSignalCheck"> Hidden if "False"</label>
        </div>
      </React.Fragment>
    );
  }
}