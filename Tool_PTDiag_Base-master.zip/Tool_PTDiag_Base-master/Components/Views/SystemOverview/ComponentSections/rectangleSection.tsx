import React, { Component, ChangeEvent } from 'react';

interface IRectangleSectionProps {
  name: string;
  height: number;
  width: number;
  translation: (word: string) => string;
  handleNameChange: (event: ChangeEvent<HTMLInputElement>) => void;
  handleHeightChange: (event: ChangeEvent<HTMLInputElement>) => void;
  handleWidthChange: (event: ChangeEvent<HTMLInputElement>) => void;
}

export class RectangleSection extends Component<IRectangleSectionProps> {

  render() {
    const { translation, handleNameChange, handleHeightChange, handleWidthChange, name, height, width } = this.props;
    return (
      <React.Fragment>
        <div className="form-group">
          <label htmlFor="componentNameInput">{translation('Name')}</label>
          <input type="text" className="form-control" id="componentNameInput" name='name' value={name} onChange={handleNameChange} />
        </div>
        <div className="form-group">
          <label htmlFor="heightInput">{translation('Height')}</label>
          <input className="form-control" type="number" id="heightInput" name='height' value={height} onChange={handleHeightChange} />
        </div>
        <div className="form-group">
          <label htmlFor="widthInput">{translation('Width')}</label>
          <input className="form-control" type="number" id="widthInput" name='width' value={width} onChange={handleWidthChange} />
        </div>
      </React.Fragment>
    );
  }
}