import React, { Component, ChangeEvent } from 'react';
import { getModuleSignals } from '../../../../CommonFunctions/functionsSupport';

interface IAnalogValueSectionProps {
  module: string;
  signalAnalog: string;
  userlevel: string;
  modules: string[];
  modulesData: any;
  signalAnalogCheck: boolean;
  translation: (word: string) => string;
  handleModuleChanged: (event: ChangeEvent<HTMLSelectElement>) => void;
  handleSignalChanged: (event: ChangeEvent<HTMLSelectElement>) => void;
  handleAnalogCheck: (event: ChangeEvent<HTMLInputElement>) => void;
}

export class AnalogValueSection extends Component<IAnalogValueSectionProps> {
  render() {
    const { module, modules, signalAnalog, userlevel, modulesData, signalAnalogCheck } = this.props;
    const { translation, handleModuleChanged, handleSignalChanged, handleAnalogCheck } = this.props;
    return (
      <React.Fragment>
        <div className="form-group">
          <label htmlFor="moduleSelect">{translation('Module')}</label>
          <select className="form-control" id="moduleSelect" name='module' value={module} onChange={handleModuleChanged}>
            {modules.map((module: string) => {
              return (
                <option key={module} value={module}>{module}</option>
              );
            })}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="formControlSignal">{translation('Signal')}</label>
          <select className="form-control" id="formControlSignal" name='signalAnalog' value={signalAnalog} onChange={handleSignalChanged}>
            {
              getModuleSignals(modulesData, module, 'analog', userlevel).map((signal: any) => (
                <option key={`${signal.category}_${signal.name}`} value={`${signal.category}_${signal.name}`}>{signal.name}</option>
              ))
            }
          </select>
        </div>
        <div className="form-group form-check">
          <input type="checkbox" className="form-check-input" name='signalAnalogCheck' id="signalAnalogCheck" checked={signalAnalogCheck} onChange={handleAnalogCheck} />
          <label className="form-check-label" htmlFor="signalAnalogCheck"> Hide signal name</label>
        </div>
      </React.Fragment>
    );
  }
}