import React, { Component, ChangeEvent } from 'react';

interface IConnectionSectionProps {
  name: string;
  orientation: string;
  connection: string;
  length: number;
  translation: (word: string) => string;
  handleNameChange: (event: ChangeEvent<HTMLInputElement>) => void;
  handleOrientationChange: (event: ChangeEvent<HTMLInputElement>) => void;
  handleConnectionChanged: (event: ChangeEvent<HTMLSelectElement>) => void;
  handleLengthChanged: (event: ChangeEvent<HTMLInputElement>) => void;
}

export class ConnectionSection extends Component<IConnectionSectionProps> {

  render() {
    const { translation, handleNameChange, handleOrientationChange, handleConnectionChanged, handleLengthChanged, name, orientation, connection, length } = this.props;
    return (
      <React.Fragment>
        <div className="form-group">
          <label htmlFor="componentNameInput">{translation('Name')}</label>
          <input type="text" className="form-control" id="componentNameInput" name='name' value={name} onChange={handleNameChange} />
        </div>
        <div className='text-center'>
          <div className="form-check form-check-inline">
            <input className="form-check-input" type="radio" name="orientation" id="inlineVerticalType" value='vertical' checked={orientation === 'vertical'} onChange={handleOrientationChange} />
            <label className="form-check-label" htmlFor="inlineVerticalType">Vertical</label>
          </div>
          <div className="form-check form-check-inline">
            <input className="form-check-input" type="radio" name="orientation" id="inlineHorizontalType" value='horizontal' checked={orientation === 'horizontal'} onChange={handleOrientationChange} />
            <label className="form-check-label" htmlFor="inlineHorizontalType">Horizontal</label>
          </div>
        </div>
        <div className="form-group">
          <label htmlFor="widthInput">{translation('Length')}</label>
          <input className="form-control" type="number" id="lengthInput" name='length' value={length} onChange={handleLengthChanged} />
        </div>
        <div className="form-group">
          <label htmlFor="moduleSymbolSelect">{translation('Type')}</label>
          <select className="form-control" id="moduleSymbolSelect" name='connection' value={connection} onChange={handleConnectionChanged}>
            <option value='None'>None</option>
            <option value='Input'>Input</option>
            <option value='Connection'>Connection</option>
            <option value='Output'>Output</option>
          </select>
        </div>
      </React.Fragment>
    );
  }
}