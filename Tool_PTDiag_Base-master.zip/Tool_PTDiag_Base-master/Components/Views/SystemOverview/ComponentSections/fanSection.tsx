import React, { Component, ChangeEvent } from 'react';

interface IFANSectionProps {
  name: string;
  symbolFan: string;
  translation: (word: string) => string;
  handleNameChange: (event: ChangeEvent<HTMLInputElement>) => void;
  handleFanSymbolChange: (event: ChangeEvent<HTMLSelectElement>) => void;
}

export class FANSection extends Component<IFANSectionProps> {

  render() {
    const { translation, handleNameChange, handleFanSymbolChange, name, symbolFan } = this.props;
    return (
      <React.Fragment>
        <div className="form-group">
          <label htmlFor="componentNameInput">{translation('Name')}</label>
          <input type="text" className="form-control" id="componentNameInput" name='name' value={name} onChange={handleNameChange} />
        </div>
        <div className="form-group">
          <label htmlFor="moduleSymbolSelect">{translation('Symbol')}</label>
          <select className="form-control" id="moduleSymbolSelect" name='symbolFan' value={symbolFan} onChange={handleFanSymbolChange}>
            <option value='MainFan'>MainFan</option>
            <option value='Auxiliary Fan'>Auxiliary Fan</option>
          </select>
        </div>
      </React.Fragment>
    );
  }
}