import React, { Component, ChangeEvent } from 'react';

interface IComponentSectionProps {
  name: string;
  translation: (word: string) => string;
  handleNameChange: (event: ChangeEvent<HTMLInputElement>) => void;
}

export class ComponentSection extends Component<IComponentSectionProps> {
  render() {
    const { translation, handleNameChange, name } = this.props;
    return (
      <React.Fragment>
        <div className="form-group">
          <label htmlFor="componentNameInput">{translation('Name')}</label>
          <input type="text" className="form-control" id="componentNameInput" name="name" value={name} onChange={handleNameChange} />
        </div>
      </React.Fragment>
    );
  }
}
