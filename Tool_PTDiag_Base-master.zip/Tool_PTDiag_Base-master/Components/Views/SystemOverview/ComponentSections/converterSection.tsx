import React, { Component, ChangeEvent } from 'react';

interface IConverterSectionProps {
  module: string;
  name: string;
  modules: string[];
  translation: (word: string) => string;
  handleModuleChange: (event: ChangeEvent<HTMLSelectElement>) => void;
  handleNameChange: (event: ChangeEvent<HTMLInputElement>) => void;
}

export class ConverterSection extends Component<IConverterSectionProps> {

  render() {
    const { translation, handleModuleChange, handleNameChange, module, modules, name } = this.props;
    return (
      <React.Fragment>
        <div className="form-group">
          <label htmlFor="componentNameInput">{translation('Name')}</label>
          <input type="text" className="form-control" id="componentNameInput" name='name' value={name} onChange={handleNameChange} />
        </div>
        <div className="form-group">
          <label htmlFor="moduleSelect">{translation('Module')}</label>
          <select className="form-control" id="moduleSelect" name='module' value={module} onChange={handleModuleChange}>
            {modules.map((module: string) => {
              return (
                <option key={module} value={module}>{module}</option>
              );
            })}
          </select>
        </div>
      </React.Fragment>
    );
  }
}