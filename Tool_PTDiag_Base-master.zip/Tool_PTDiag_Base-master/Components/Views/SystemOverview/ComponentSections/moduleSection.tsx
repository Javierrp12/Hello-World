import React, { Component, ChangeEvent } from 'react';

interface IModuleSectionProps {
  module: string;
  name: string;
  modules: string[];
  symbol: string;
  translation: (word: string) => string;
  handleModuleChange: (event: ChangeEvent<HTMLSelectElement>) => void;
  handleNameChange: (event: ChangeEvent<HTMLInputElement>) => void;
  handleSymbolChange: (event: ChangeEvent<HTMLSelectElement>) => void;
}

export class ModuleSection extends Component<IModuleSectionProps> {

  render() {
    const { translation, handleModuleChange, handleSymbolChange, handleNameChange, module, modules, name, symbol } = this.props;
    return (
      <React.Fragment>
        <div className="form-group">
          <label htmlFor="componentNameInput">{translation('Name')}</label>
          <input type="text" className="form-control" id="componentNameInput" name='name' value={name} onChange={handleNameChange} />
        </div>
        <div className="form-group">
          <label htmlFor="moduleSelect">{translation('Module')}</label>
          <select className="form-control" id="moduleSelect" name='module' value={module} onChange={handleModuleChange}>
            {modules.map((module: string) => {
              return (
                <option key={module} value={module}>{module}</option>
              );
            })}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="moduleSymbolSelect">{translation('Symbol')}</label>
          <select className="form-control" id="moduleSymbolSelect" name='symbol' value={symbol} onChange={handleSymbolChange}>
            <option value='None'>None</option>
            <option value='dcac'>DC/AC</option>
            <option value='dcdc'>Isolated DC/DC</option>
            <option value='dc-dc'>DC/DC</option>
          </select>
        </div>
      </React.Fragment>
    );
  }

}
