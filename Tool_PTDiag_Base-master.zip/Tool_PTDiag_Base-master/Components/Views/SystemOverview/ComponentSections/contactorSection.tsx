import React, { Component, ChangeEvent } from 'react';

interface IContactorSectionProps {
  name: string;
  symbolContactor: string;
  translation: (word: string) => string;
  handleNameChange: (event: ChangeEvent<HTMLInputElement>) => void;
  handleContactorSymbolChange: (event: ChangeEvent<HTMLSelectElement>) => void;
}

export class ContactorSection extends Component<IContactorSectionProps> {
  render() {
    const { translation, handleNameChange, handleContactorSymbolChange, name, symbolContactor } = this.props;
    return (
      <React.Fragment>
        <div className="form-group">
          <label htmlFor="componentNameInput">{translation('Name')}</label>
          <input type="text" className="form-control" id="componentNameInput" name="name" value={name} onChange={handleNameChange} />
        </div>
        <div className="form-group">
          <label htmlFor="moduleSymbolSelect">{translation('Symbol')}</label>
          <select className="form-control" id="moduleSymbolSelect" name="symbolContactor" value={symbolContactor} onChange={handleContactorSymbolChange}>
            <option value="Contactor">AC Contactor</option>
            <option value="DCContactor">DC Contactor</option>
          </select>
        </div>
      </React.Fragment>
    );
  }
}
