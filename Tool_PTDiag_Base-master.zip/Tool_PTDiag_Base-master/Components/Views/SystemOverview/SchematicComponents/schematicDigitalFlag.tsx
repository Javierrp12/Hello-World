import React, { Component } from 'react';
import { useStrictMode, Text, Circle } from 'react-konva';
import { KonvaEventObject } from 'konva/types/Node';
import { safeProp, eq } from '../../../../CommonFunctions/pointfreeUtilities';

useStrictMode(true);

interface ISchematicDigitalFlagsProps {
  componentData: ISchematicFlag
  handleClickDelete: (event: KonvaEventObject<MouseEvent>) => void;
  handleDragEnd: (event: KonvaEventObject<MouseEvent>) => void;
}

interface ISchematicFlag {
  x: number;
  y: number;
  name: string;
  module: string;
  datastore: string;
  category: string;
  fontSize: number;
  fontFamily: string;
  status: boolean;
  severity: string;
  hiddenIfFalse: boolean;
  editMode: boolean;
}

export class SchematicDigitalFlags extends Component<ISchematicDigitalFlagsProps> {

  render() {
    const { componentData } = this.props;
    const { handleClickDelete, handleDragEnd } = this.props;
    const xOffsetLed: number = -8;
    const yOffsetLed: number = 7;
    const x: number = componentData.x;
    const y: number = componentData.y;
    return (
      <React.Fragment>
        <Text
          x={x}
          y={y}
          text={componentData.name}
          digitalModule={componentData.module}
          digitalDatastore={componentData.datastore}
          digitalCategory={componentData.category}
          digitalName={componentData.name}
          componentType={'DigitalFlag'}
          fontSize={componentData.fontSize}
          fontFamily={componentData.fontFamily}
          draggable={eq(componentData.editMode, true) ? true : false}
          visible={(!(eq(componentData.hiddenIfFalse, true) && eq(componentData.status, false)) || componentData.editMode === true)}
          onMouseEnter={(event: KonvaEventObject<MouseEvent>): void => {
            if (eq(componentData.editMode, true)) {
              const container = event.target.getStage()!.container();
              container.style.cursor = "move";
            }
          }}
          onMouseLeave={(event: KonvaEventObject<MouseEvent>): void => {
            if (eq(componentData.editMode, true)) {
              const container = event.target.getStage()!.container();
              container.style.cursor = "default";
            }
          }}
          onDblClick={(event: KonvaEventObject<MouseEvent>) => {
            if (eq(componentData.editMode, true)) {
              handleClickDelete(event);
            }
          }}
          onDragEnd={handleDragEnd}
        />
        <Circle
          key={`digital_Flag_Circle_${componentData.name}`}
          x={x + xOffsetLed}
          y={y + yOffsetLed}
          radius={6}
          fill={eq(componentData.status, true) ? this.flagSeverityColor(componentData.severity) : 'rgba(0, 0, 0, 0)'}
          stroke='black'
          strokeWidth={1}
          visible={(!(eq(componentData.hiddenIfFalse, true) && eq(componentData.status, false)) || eq(componentData.editMode, true))}
        />
      </React.Fragment>
    );
  }

  private flagSeverityColor = (severity: string): string => {
    const severityColors = {
      'Major': "#cc1f1f",
      'Minor': "#df6127",
      'Warning': "#d39e00",
      "Info": "#007bff",
      "None": "#3bb84c"
    }
    const getSeverityColor = safeProp(severity);
    return getSeverityColor(severityColors).getOrElse('#ffffff');
  }
}