import React, { Component } from 'react';
import { useStrictMode, Text } from 'react-konva';
import { KonvaEventObject } from 'konva/types/Node';
import { eq, safeProp } from '../../../../CommonFunctions/pointfreeUtilities';

useStrictMode(true);

interface ISchematicAnalogValueProps {
  componentData: IAnalogValue;
  handleClickDelete: (event: KonvaEventObject<MouseEvent>) => void;
  handleDragEnd: (event: KonvaEventObject<MouseEvent>) => void;
}

interface IAnalogValue {
  x: number;
  y: number;
  name: string;
  value: string;
  module: string;
  datastore: string;
  category: string;
  fontSize: number;
  fontFamily: string;
  editMode: boolean;
  hideName: string;
}

export class SchematicAnalogValue extends Component<ISchematicAnalogValueProps> {

  render() {
    const { componentData } = this.props;
    const { handleClickDelete, handleDragEnd } = this.props;
    const x: number = componentData.x;
    const y: number = componentData.y;
    const hideName = safeProp('hideName', componentData).getOrElse(false);

    return (
      <React.Fragment>
        { eq(hideName, true) &&
          <Text
            x={x}
            y={y}
            text={componentData.value}
            analogModule={componentData.module}
            analogDatastore={componentData.datastore}
            analogCategory={componentData.category}
            analogName={componentData.name}
            componentType={'AnalogValue'}
            fontSize={componentData.fontSize}
            fontFamily={componentData.fontFamily}
            draggable={eq(componentData.editMode, true) ? true : false}
            onMouseEnter={(event: KonvaEventObject<MouseEvent>): void => {
              if (eq(componentData.editMode, true)) {
                const container = event.target.getStage()!.container();
                container.style.cursor = "move";
              }
            }}
            onMouseLeave={(event: KonvaEventObject<MouseEvent>) => {
              if (eq(componentData.editMode, true)) {
                const container = event.target.getStage()!.container();
                container.style.cursor = "default";
              }
            }}
            onDblClick={(event: KonvaEventObject<MouseEvent>) => {
              if (eq(componentData.editMode, true)) {
                handleClickDelete(event);
              }
            }}
            onDragEnd={handleDragEnd}
          />
        }
        { eq(hideName, false) &&
          <Text
            x={x}
            y={y}
            text={`${componentData.name}: ${componentData.value}`}
            analogModule={componentData.module}
            analogDatastore={componentData.datastore}
            analogCategory={componentData.category}
            analogName={componentData.name}
            componentType={'AnalogValue'}
            fontSize={componentData.fontSize}
            fontFamily={componentData.fontFamily}
            draggable={eq(componentData.editMode, true) ? true : false}
            onMouseEnter={(event: KonvaEventObject<MouseEvent>): void => {
              if (eq(componentData.editMode, true)) {
                const container = event.target.getStage()!.container();
                container.style.cursor = "move";
              }
            }}
            onMouseLeave={(event: KonvaEventObject<MouseEvent>) => {
              if (eq(componentData.editMode, true)) {
                const container = event.target.getStage()!.container();
                container.style.cursor = "default";
              }
            }}
            onDblClick={(event: KonvaEventObject<MouseEvent>) => {
              if (eq(componentData.editMode, true)) {
                handleClickDelete(event);
              }
            }}
            onDragEnd={handleDragEnd}
          />
        }
      </React.Fragment>
    );
  }
}