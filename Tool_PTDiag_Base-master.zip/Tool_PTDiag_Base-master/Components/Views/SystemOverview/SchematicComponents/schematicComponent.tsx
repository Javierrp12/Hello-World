import React, { Component } from 'react';
import { useStrictMode, Rect, Text, Group } from 'react-konva';
import { IInfo, IComponentstate } from '../ISystemoverview';
import { KonvaEventObject } from 'konva/types/Node';
import { ComponentSymbol } from '../Symbols/componentSymbol';
import { Modules } from '../../../../Datastore/ModelData/modulesTypes';
import { chain, safeProp, eq, map } from '../../../../CommonFunctions/pointfreeUtilities';
import { checkComponentCondition, checkConditionDbClick, checkComponentType } from '../../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

useStrictMode(true);

interface ISchematicProps {
  componentData: IComponentData;
  handleClickRedirect: (module: string) => void;
  handleClickDelete: (event: KonvaEventObject<MouseEvent>) => void;
  handleDragEnd: (event: KonvaEventObject<MouseEvent>) => void;
}

interface IComponentData {
  name: string;
  fontSize: number;
  fontFamily: string;
  x: number;
  y: number;
  type: string;
  isOnline: boolean;
  width: number;
  height: number;
  state: string;
  componentKey: string | undefined;
  symbol: string;
  speed: number;
  command: string;
  module: string;
  info: IInfo[];
  editMode: boolean;
}

export class SchematicComponent extends Component<ISchematicProps> {
  private componentStates: IComponentstate = {
    Init: { name: 'Init', color: 'rgba(174, 174, 166, 255)' },
    Selftest: { name: 'Selftest', color: 'rgba(39, 39, 231, 255)' },
    Run: { name: 'Run', color: 'rgba(38, 117,38, 225)' },
    Ready: { name: 'Ready', color: 'rgba(232, 234, 44, 225)' },
    Stop: { name: 'Stop', color: 'rgba(251, 147, 31, 225)' },
    TemporaryError: { name: 'TemporaryError', color: 'rgba(195,48,26, 225)' },
    Error: { name: 'Error', color: 'rgba(195,48,26, 225)' },
    Undefined: { name: 'Undefined', color: 'rgba(174, 174, 166, 255)' }
  };

  render() {
    const { componentData } = this.props;
    const { handleClickRedirect, handleClickDelete, handleDragEnd } = this.props;
    const HorizontalCenter = 20;
    const x: number = componentData.x;
    const y: number = componentData.y;
    return (
      <React.Fragment>
        <Rect
          key={`frame_${componentData.name}`}
          x={x}
          y={y}
          width={componentData.width}
          height={componentData.height}
          stroke={this.updateStrokeColor(componentData.state)}
          strokeWidth={eq(componentData.state, 'TemporaryError') ? 6 : 3}
          fill={this.updateColorState(componentData.isOnline, componentData.state, this.componentStates)}
          componentKey={componentData.componentKey}
          componentType={'Component'}
          draggable={eq(componentData.editMode, true)}
          onMouseEnter={(event: KonvaEventObject<MouseEvent>) => {
            if (eq(componentData.editMode, false) && (eq(componentData.type, 'Module') || eq(componentData.type, 'Contactors'))) {
              const container = event.target.getStage()!.container();
              container.style.cursor = 'pointer';
            }

            if (eq(componentData.editMode, true)) {
              const container = event.target.getStage()!.container();
              container.style.cursor = 'move';
            }
          }}
          onMouseLeave={(event: KonvaEventObject<MouseEvent>) => {
            const container = event.target.getStage()!.container();
            container.style.cursor = 'default';
          }}
          onDblClick={(event: KonvaEventObject<MouseEvent>) => {
            const checkEditMode = compose(map(checkComponentType(handleClickRedirect, componentData.module, Modules.MU)), checkConditionDbClick(componentData.editMode, componentData.type));
            checkEditMode(event).matchWith({
              Ok: () => {},
              Error: (value: any) => handleClickDelete(value.merge())
            });
          }}
          onDragEnd={handleDragEnd}
        />
        <Group key={`group_component_${componentData.name}`}>
          <Text x={x} y={y - HorizontalCenter} text={componentData.name} fontSize={componentData.fontSize} fontFamily={componentData.fontFamily} />
          {
            <ComponentSymbol
              symbol={componentData.symbol}
              name={componentData.name}
              x={x}
              y={y}
              fontFamily={componentData.fontFamily}
              width={componentData.width}
              height={componentData.height}
              state={componentData.state}
              speed={componentData.speed}
              command={componentData.command}
              info={componentData.info}
            />
          }
          {eq(componentData.isOnline, false) && (eq(componentData.type, 'Module') || eq(componentData.type, 'Aif')) && (
            <Text x={x + componentData.width / 4} y={y + componentData.height / 2} text={'Offline'} fontSize={componentData.fontSize} fontFamily={componentData.fontFamily} fill="#e62727" rotation={-45} />
          )}
        </Group>
      </React.Fragment>
    );
  }

  private updateStrokeColor = (state: string): string => (eq(state, 'TemporaryError') ? 'rgba(251, 147, 31, 225)' : 'black');

  private updateColorState = (isOnline: boolean, state: string, componentStates: IComponentstate): string => {
    const getColor = compose(chain(safeProp('color')), chain(safeProp(state)));
    const getStateColor = compose(getColor, checkComponentCondition(isOnline));
    return getStateColor(componentStates).getOrElse('#ffffff');
  };
}
