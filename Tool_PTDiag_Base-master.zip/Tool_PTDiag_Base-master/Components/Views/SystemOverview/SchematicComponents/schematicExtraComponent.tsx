import React, { Component } from 'react';
import { useStrictMode } from 'react-konva';
import { KonvaEventObject } from 'konva/types/Node';
import { ExtraText } from '../Symbols/extraText';
import { ExtraRectangle } from '../Symbols/extraRectangle';
import { ExtraDiode } from '../Symbols/extraDiode';
import { Extra3Phase } from '../Symbols/extra3Phase';
import { safeProp } from '../../../../CommonFunctions/pointfreeUtilities';

useStrictMode(true);

interface ISchematicExtraComponentProps {
  componentData: IExtraComponentProps;
  handleClickDelete: (event: KonvaEventObject<MouseEvent>) => void;
  handleDragEnd: (event: KonvaEventObject<MouseEvent>) => void;
  handleTransformEnd: (event: KonvaEventObject<MouseEvent>) => void;
}

interface IExtraComponentProps {
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
  type: string;
  componentKey: string | undefined;
  fontSize: number;
  fontFamily: string;
  editMode: boolean;
}

export class SchematicExtraComponent extends Component<ISchematicExtraComponentProps> {

  render() {
    const { componentData } = this.props;
    const { handleClickDelete, handleDragEnd, handleTransformEnd } = this.props;

    return (
      <React.Fragment>
        {this.drawExtraComponent(componentData, handleClickDelete, handleDragEnd, handleTransformEnd)}
      </React.Fragment>
    );
  }

  private drawExtraComponent = (data: IExtraComponentProps, handleClickDelete: (event: KonvaEventObject<MouseEvent>) => void, handleDragEnd: (event: KonvaEventObject<MouseEvent>) => void, handleTransformEnd: (event: KonvaEventObject<MouseEvent>) => void) => {
    const extraComponents = {
      'text': <ExtraText key={`ExtraComponent_Text_${data.name}`} data={{ name: data.name, x: data.x, y: data.y, fontSize: data.fontSize, fontFamily: data.fontFamily, componentKey: data.componentKey, editMode: data.editMode }} handleClickDelete={handleClickDelete} handleDragEnd={handleDragEnd} />,
      'rectangle': <ExtraRectangle key={`ExtraComponent_Rect_${data.name}`} data={{ name: data.name, x: data.x, y: data.y, width: data.width, height: data.height, componentKey: data.componentKey, editMode: data.editMode }} handleClickDelete={handleClickDelete} handleDragEnd={handleDragEnd} handleTransformEnd={handleTransformEnd} />,
      'diode': <ExtraDiode key={`ExtraDiode_${data.name}`} data={{ x: data.x, y: data.y, componentKey: data.componentKey, editMode: data.editMode }} handleClickDelete={handleClickDelete} handleDragEnd={handleDragEnd} />,
      '3Phase': <Extra3Phase key={`Extra3Phase_${data.name}`} data={{ x: data.x, y: data.y, componentKey: data.componentKey, editMode: data.editMode }} handleClickDelete={handleClickDelete} handleDragEnd={handleDragEnd} />
    }
    return safeProp(safeProp('type', data).getOrElse(''), extraComponents).getOrElse(null);
  }

}
