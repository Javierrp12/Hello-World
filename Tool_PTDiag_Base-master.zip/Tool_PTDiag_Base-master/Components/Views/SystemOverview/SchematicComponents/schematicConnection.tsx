import React, { Component } from 'react';
import { useStrictMode, Rect, Circle, Transformer } from 'react-konva';
import { eq, deq } from '../../../../CommonFunctions/pointfreeUtilities';
import { KonvaEventObject } from 'konva/types/Node';

useStrictMode(true);

interface ISchematicConnectionProps {
  componentData: IConnectionProps;
  handleClickDelete: (event: KonvaEventObject<MouseEvent>) => void;
  handleDragEnd: (event: KonvaEventObject<MouseEvent>) => void;
  handleTransformEnd: (event: KonvaEventObject<MouseEvent>) => void;
}

interface IConnectionProps {
  x: number;
  y: number;
  name: string;
  componentKey: string | undefined;
  type: string;
  width: number;
  height: number;
  orientation: string;
  editMode: boolean;
}

export class SchematicConnection extends Component<ISchematicConnectionProps> {
  private shapeRef: any;
  private trRef: any;

  constructor(props: ISchematicConnectionProps) {
    super(props);
    this.shapeRef = React.createRef();
    this.trRef = React.createRef();
  }

  render() {
    const { componentData } = this.props;
    const { handleClickDelete, handleDragEnd, handleTransformEnd } = this.props;
    const x: number = componentData.x;
    const y: number = componentData.y;
    return (
      <React.Fragment>
        <Rect
          ref={this.shapeRef}
          key={`Connection_Rect_${componentData.name}`}
          x={x}
          y={y}
          width={componentData.width}
          height={componentData.height}
          stroke={(eq(componentData.editMode, true)) ? 'red' : 'black'}
          strokeWidth={2}
          scaleX={1}
          scaleY={1}
          rotation={0}
          fill={'transparent'}
          componentKey={componentData.componentKey}
          componentType={'Connections'}
          draggable={eq(componentData.editMode, true) ? true : false}
          onDragEnd={handleDragEnd}
          onTransformEnd={handleTransformEnd}
          onMouseEnter={(event: KonvaEventObject<MouseEvent>): void => {
            if (eq(componentData.editMode, true)) {
              const container = event.target.getStage()!.container();
              container.style.cursor = "pointer";
            }
          }}
          onMouseLeave={(event: KonvaEventObject<MouseEvent>): void => {
            if (eq(componentData.editMode, true)) {
              const container = event.target.getStage()!.container();
              container.style.cursor = "default";
            }
          }}
          onDblClick={(event: KonvaEventObject<MouseEvent>): void => {
            if (eq(componentData.editMode, true)) {
              handleClickDelete(event);
            }
          }}
        />
        { (deq(componentData.type, "None")) &&
          <Circle
            key={`Connection_circle_${componentData.name}`}
            x={eq(componentData.type, 'Output') ? (eq(componentData.orientation, 'vertical') ? x : x + componentData.width) : x}
            y={eq(componentData.type, 'Output') ? (eq(componentData.orientation, 'vertical') ? y + componentData.height : y) : y}
            radius={4}
            fill={eq(componentData.type, 'Connection') ? 'black' : 'white'}
            stroke={'black'}
            strokeWidth={2}
          />
        }
        {  (eq(componentData.editMode, true)) &&
          <Transformer ref={this.trRef} />
        }
      </React.Fragment>
    );
  }

  componentDidUpdate() {
    if (eq(this.props.componentData.editMode, true)) {
      this.trRef.current.nodes([this.shapeRef.current]);
      this.trRef.current.getLayer().batchDraw();
    }
  }

}
