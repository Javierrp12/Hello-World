export const baseComponentsData = {
  module: {
    name: '',
    type: 'Module',
    module: '',
    symbol: '',
    state: 'Undefined',
    isOnline: true,
    height: 120,
    width: 120,
    xPosition: 20,
    yPosition: 20
  },
  converter: {
    name: '',
    type: 'Converter',
    module: 'MU',
    state: 'Undefined',
    symbol: 'None',
    height: 120,
    width: 240,
    xPosition: 20,
    yPosition: 20
  },
  aif: {
    name: '',
    type: 'Aif',
    state: 'Undefined',
    symbol: 'Aif',
    isOnline: true,
    height: 120,
    width: 120,
    xPosition: 20,
    yPosition: 20
  },
  fan: {
    name: '',
    type: 'Fan',
    state: 'Undefined',
    symbol: '',
    isOnline: true,
    speed: '0%',
    height: 80,
    width: 80,
    xPosition: 20,
    yPosition: 20
  },
  legend: {
    name: '',
    type: 'Legend',
    isOnline: false,
    symbol: 'Legend',
    state: 'Undefined',
    height: 160,
    width: 165,
    xPosition: 20,
    yPosition: 20
  },
  contactors: {
    name: '',
    type: 'Contactors',
    state: 'Undefined',
    isOnline: true,
    command: 'open',
    symbol: 'Contactor',
    height: 120,
    width: 70,
    xPosition: 20,
    yPosition: 20
  },
  fuse: {
    name: '',
    type: 'Fuse',
    symbol: 'Fuse',
    state: 'Undefined',
    isOnline: true,
    height: 35,
    width: 70,
    xPosition: 20,
    yPosition: 20
  },
  info: {
    name: '',
    type: 'Info',
    info: [{ name: '', trigered: false, state: 'Undefined' }],
    symbol: 'Info',
    isOnline: false,
    state: 'Undefined',
    height: 120,
    width: 400,
    xPosition: 20,
    yPosition: 20
  },
  text: {
    name: '',
    xPosition: 20,
    yPosition: 20,
    type: 'text'
  },
  rectangle: {
    name: '',
    xPosition: 20,
    yPosition: 20,
    height: 0,
    width: 0,
    type: 'rectangle'
  },
  '3Phase': {
    name: '',
    xPosition: 20,
    yPosition: 20,
    type: '3Phase'
  },
  diode: {
    name: '',
    xPosition: 20,
    yPosition: 20,
    type: 'diode'
  },
  connection: {
    name: '',
    xPosition: 10,
    yPosition: 10,
    height: 10,
    width: 1,
    orientation: 'vertical',
    type: 'None'
  },
  analogValue: {
    name: '',
    dataStore: '',
    category: '',
    module: '',
    xAPosition: 20,
    yAPosition: 20,
    value: '0'
  },
  digitalFlag: {
    name: '',
    dataStore: '',
    category: '',
    module: '',
    xDPosition: 20,
    yDPosition: 20,
    status: false,
    hiddenIfFalse: false,
    severity: 'Info'
  }
};
