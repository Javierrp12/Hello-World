import React, { Component } from 'react';
import { useStrictMode, Rect, Transformer } from 'react-konva';
import { KonvaEventObject } from 'konva/types/Node';

useStrictMode(true);

interface IExtraRectangleProps {
  data: IRectangleProps;
  handleClickDelete: (event: KonvaEventObject<MouseEvent>) => void;
  handleDragEnd: (event: KonvaEventObject<MouseEvent>) => void;
  handleTransformEnd: (event: KonvaEventObject<MouseEvent>) => void;
}

interface IRectangleProps {
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
  componentKey: string | undefined;
  editMode: boolean;
}

export class ExtraRectangle extends Component<IExtraRectangleProps> {
  private shapeRef: any;
  private trRef: any;

  constructor(props: IExtraRectangleProps) {
    super(props);
    this.shapeRef = React.createRef();
    this.trRef = React.createRef();
  }

  render() {
    const { data } = this.props;
    const { handleClickDelete, handleDragEnd, handleTransformEnd } = this.props;
    return (
      <React.Fragment>
        <Rect
          ref={this.shapeRef}
          x={data.x}
          y={data.y}
          rotation={0}
          width={data.width}
          height={data.height}
          stroke={'#494f54'}
          strokeWidth={3}
          scaleX={1}
          scaleY={1}
          fill={'transparent'}
          componentKey={data.componentKey}
          componentType={'Extra'}
          draggable={(data.editMode === true) ? true : false}
          onMouseEnter={(event: KonvaEventObject<MouseEvent>) => {
            if (data.editMode === true) {
              const container = event.target.getStage()!.container();
              container.style.cursor = "move";
            }
          }}
          onMouseLeave={(event: KonvaEventObject<MouseEvent>) => {
            if (data.editMode === true) {
              const container = event.target.getStage()!.container();
              container.style.cursor = "default";
            }
          }}
          onDragEnd={handleDragEnd}
          onDblClick={(event: KonvaEventObject<MouseEvent>) => {
            if (data.editMode === true) {
              handleClickDelete(event);
            }
          }}
          onTransformEnd={handleTransformEnd}
        />
        {(data.editMode === true) &&
          < Transformer ref={this.trRef} />
        }
      </React.Fragment>
    );
  }

  componentDidUpdate() {
    if (this.props.data.editMode === true) {
      this.trRef.current.nodes([this.shapeRef.current]);
      this.trRef.current.getLayer().batchDraw();
    }
  }
}
