import React, { Component } from 'react';
import { useStrictMode, Shape } from 'react-konva';

useStrictMode(true);

interface IDC_DCProps {
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
}

export class DC_DC extends Component<IDC_DCProps> {

  render() {
    const { name, x, y, width, height } = this.props;
    const vCenter = width * 0.5;
    const hCenter = height * 0.5;

    return (
      <React.Fragment>
        <Shape
          key={`DC_DC_Symbol_${name}`}
          sceneFunc={(context, shape) => {
            const HorizontalCenterOffset = 0;
            context.translate((x + (vCenter)), (y + (hCenter) + HorizontalCenterOffset));

            context.beginPath();
            context.moveTo(-40, -45);
            context.lineTo(-25, -45);
            context.moveTo(-40, -35);
            context.lineTo(-25, -35);

            /* Diagonal lines */
            context.moveTo(-56, 56);
            context.lineTo(56, -56);

            /* Horizontal lines */
            context.moveTo(40, 45);
            context.lineTo(25, 45);
            context.moveTo(40, 35);
            context.lineTo(25, 35);
            context.closePath();

            // (!) Konva specific method, it is very important
            context.fillStrokeShape(shape);
          }}
          lineCap='round'
          stroke="black"
          strokeWidth={3}
        />
      </React.Fragment>
    );
  }
}