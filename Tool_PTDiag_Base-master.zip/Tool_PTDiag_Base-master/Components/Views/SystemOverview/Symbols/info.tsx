import React, { Component } from 'react';
import { IInfo } from '../ISystemoverview';
import { useStrictMode, Circle, Text } from 'react-konva';
import { map, reduce } from '../../../../CommonFunctions/pointfreeUtilities';
import { createTextRectangleSymbol, safeNewArray } from '../../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');
const curry = require('folktale/core/lambda/curry');

useStrictMode(true);

interface IInfoProps {
  info: IInfo[];
  x: number;
  y: number;
  fontFamily: string;
}

export class Info extends Component<IInfoProps> {

  render() {
    const { info, x, y, fontFamily } = this.props;
    return (
      <React.Fragment>
        {this.createInfo(info, x, y, fontFamily)}
      </React.Fragment>
    );
  }

  private createInfo = (info: IInfo[], x: number, y: number, fontFamily: string) => {
    const createTextLegend = curry(5, (fontFamily: string, xPosition: number, yPosition: number, x: IInfo, index: number) => {
      let xPositionOffsetText = 20;
      let yPositionOffsetText = 5 + (index * 20);

      return (<Text
        key={`Info_Text_${x.name}`}
        x={xPosition + xPositionOffsetText}
        y={yPosition + yPositionOffsetText}
        text={x.name}
        fontSize={16}
        fontFamily={fontFamily}
        fill={(x.state !== 'Run') ? 'rgba(196, 196, 196, 196)' : 'rgba(0, 0, 0, 255)'}
      />);
    });

    const createRectangleLegend = curry(4, (xPosition: number, yPosition: number, x: IInfo, index: number) => {
      let xPositionOffsetLed = 10;
      let yPositionOffsetLed = 12 + (index * 20);

      return (<Circle
        key={`Info_Circle_${x.name}`}
        x={xPosition + xPositionOffsetLed}
        y={yPosition + yPositionOffsetLed}
        radius={5}
        fill={(x.trigered === true) ? 'rgba(0, 0, 255, 196)' : 'rgba(0, 0, 0, 0)'}
        stroke='black'
        strokeWidth={3}
      />
      );
    });
    const createInfoSymbol = compose(map(reduce(createTextRectangleSymbol(createTextLegend(fontFamily, x, y), createRectangleLegend(x, y)), [])), safeNewArray);
    return createInfoSymbol(info).getOrElse(null);
  }
}