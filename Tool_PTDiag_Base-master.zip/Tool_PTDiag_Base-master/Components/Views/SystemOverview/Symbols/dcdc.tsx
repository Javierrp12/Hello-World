import React, { Component } from 'react';
import { useStrictMode, Shape } from 'react-konva';

useStrictMode(true);

interface IDCDCProps {
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
}

export class DCDC extends Component<IDCDCProps> {

  render() {
    const { name, x, y, width, height } = this.props;
    const vCenter = width * 0.5;
    const hCenter = height * 0.5;

    return (
      <React.Fragment>
        <Shape
          key={`DCDC_Symbol_${name}`}
          sceneFunc={(context, shape) => {
            const HorizontalCenterOffset = 0;
            context.translate((x + (vCenter)), (y + (hCenter) + HorizontalCenterOffset));

            /* Diagonal lines */
            context.beginPath();
            context.moveTo(-56, 51);
            context.lineTo(51, -56);
            context.moveTo(-51, 56);
            context.lineTo(56, -51);

            /* Horizontal lines */
            context.moveTo(-40, -45);
            context.lineTo(-25, -45);
            context.moveTo(-40, -35);
            context.lineTo(-25, -35);

            context.moveTo(40, 45);
            context.lineTo(25, 45);
            context.moveTo(40, 35);
            context.lineTo(25, 35);
            context.closePath();

            // (!) Konva specific method, it is very important
            context.fillStrokeShape(shape);
          }}
          lineCap='round'
          stroke="black"
          strokeWidth={3}
        />
      </React.Fragment>
    );
  }
}