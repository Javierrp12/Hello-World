import React, { Component } from 'react';
import { useStrictMode, Rect, Shape } from 'react-konva';
import { KonvaEventObject } from 'konva/types/Node';

useStrictMode(true);

interface IExtraThreePhaseProps {
  data: IThreePhaseProps;
  handleClickDelete: (event: KonvaEventObject<MouseEvent>) => void;
  handleDragEnd: (event: KonvaEventObject<MouseEvent>) => void;
}

interface IThreePhaseProps {
  x: number;
  y: number;
  componentKey: string | undefined;
  editMode: boolean;
}

export class Extra3Phase extends Component<IExtraThreePhaseProps> {

  render() {
    const { data } = this.props;
    const { handleClickDelete, handleDragEnd } = this.props;
    const witdh: number = 55;
    const height: number = 1;
    const x: number = data.x;
    const y: number = data.y;

    return (
      <React.Fragment>
        <Rect
          x={x}
          y={y - height / 2}
          width={witdh}
          height={height}
          stroke={(data.editMode === true) ? 'black' : 'transparent'}
          strokeWidth={2}
          fill={'transparent'}
          componentKey={data.componentKey}
          componentType={'Extra'}
          draggable={(data.editMode === true) ? true : false}
          onMouseEnter={(event: KonvaEventObject<MouseEvent>) => {
            if (data.editMode === true) {
              const container = event.target.getStage()!.container();
              container.style.cursor = "move";
            }
          }}
          onMouseLeave={(event: KonvaEventObject<MouseEvent>) => {
            if (data.editMode === true) {
              const container = event.target.getStage()!.container();
              container.style.cursor = "default";
            }
          }}
          onDragEnd={handleDragEnd}
          onDblClick={(event: KonvaEventObject<MouseEvent>) => {
            if (data.editMode === true) {
              handleClickDelete(event);
            }
          }}
        />
        <Shape
          sceneFunc={(context, shape) => {
            context.beginPath();
            /* Three Phase lines */
            const offsetLines = 10;
            context.moveTo(x + (offsetLines * 2), y - offsetLines);
            context.lineTo(x + offsetLines, y + offsetLines);
            context.moveTo(x + (offsetLines * 3), y - offsetLines);
            context.lineTo(x + (offsetLines * 2), y + offsetLines);
            context.moveTo(x + (offsetLines * 4), y - offsetLines);
            context.lineTo(x + (offsetLines * 3), y + offsetLines);
            context.stroke();
            context.closePath();
            // (!) Konva specific method, it is very important
            context.fillStrokeShape(shape);
          }}
          stroke='black'
          strokeWidth={3}
        />
      </React.Fragment>
    );
  }
}