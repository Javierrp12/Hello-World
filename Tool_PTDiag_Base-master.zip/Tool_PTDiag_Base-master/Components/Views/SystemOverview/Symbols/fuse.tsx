import React, { Component } from 'react';
import { useStrictMode, Shape } from 'react-konva';

useStrictMode(true);

interface IFuseProps {
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
  state: string;
}

export class Fuse extends Component<IFuseProps> {
  render() {
    const { name, x, y, width, height, state } = this.props;
    const vCenter = width * 0.5;
    const hCenter = height * 0.5;

    return (
      <React.Fragment>
        <Shape
          key={`fuse_Symbol_${name}`}
          sceneFunc={(context, shape) => {
            const HorizontalCenterOffset = 0;
            context.translate(x + vCenter, y + hCenter + HorizontalCenterOffset);
            context.beginPath();

            if (state === 'Error') {
              context.moveTo(-35, 0);
              context.lineTo(-20, 0);

              context.moveTo(35, 0);
              context.lineTo(20, 0);
            } else {
              context.moveTo(-35, 0);
              context.lineTo(35, 0);
            }
            context.closePath();

            // (!) Konva specific method, it is very important
            context.fillStrokeShape(shape);
          }}
          lineCap="round"
          stroke="black"
          strokeWidth={3}
        />
      </React.Fragment>
    );
  }
}
