import React, { Component } from 'react';
import { useStrictMode, Shape } from 'react-konva';

useStrictMode(true);

interface IAIFProps {
  name: string;
  x: number;
  y: number;
  state: string;
  width: number;
  height: number;
}

export class AIF extends Component<IAIFProps> {

  render() {
    const { name, x, y, width, height, state } = this.props;
    const vCenter = width * 0.5;
    const hCenter = height * 0.5;
    return (
      <React.Fragment>
        <Shape
          key={`Aif_Symbol_${name}`}
          sceneFunc={(context, shape) => {
            const HorizontalCenterOffset = 0;
            context.translate((x + (vCenter)), (y + (hCenter) + HorizontalCenterOffset));

            context.beginPath();
            context.moveTo(-60, -25);
            context.lineTo(-50, -25);

            /* Inductance */
            context.arc(-40, -25, 4, Math.PI, 2 * Math.PI, false);
            context.arc(-30, -25, 4, Math.PI, 2 * Math.PI, false);
            context.arc(-20, -25, 4, Math.PI, 2 * Math.PI, false);
            context.arc(-10, -25, 4, Math.PI, 2 * Math.PI, false);
            context.lineTo(5, -25);

            /* Switch */
            if (state === "Run") {
              context.lineTo(40, -30);
            } else {
              context.lineTo(40, -40);
            }
            /* Resistor */
            context.moveTo(5, -25);
            context.lineTo(5, 0);
            context.lineTo(10, 0);
            context.lineTo(14, -5);
            context.lineTo(18, 5);
            context.lineTo(22, -5);
            context.lineTo(26, 5);
            context.lineTo(30, -5);
            context.lineTo(34, 0);
            context.lineTo(40, 0);
            context.lineTo(40, 0);
            context.lineTo(40, -25);

            /* Condensator */
            context.moveTo(52, -25);
            context.lineTo(52, 10);
            context.lineTo(44, 10);
            context.moveTo(53, 10);
            context.lineTo(60, 10);
            context.moveTo(54, 15);
            context.lineTo(44, 15);
            context.moveTo(54, 15);
            context.lineTo(60, 15);
            context.moveTo(52, 15);
            context.lineTo(52, 30);

            /* Circles */
            context.moveTo(5, -25);
            context.arc(5, -25, 3, 0, 2 * Math.PI, true);
            context.moveTo(40, -25);
            context.arc(40, -25, 3, 0, 2 * Math.PI, true);
            context.lineTo(60, -25);
            context.closePath();

            // (!) Konva specific method, it is very important
            context.fillStrokeShape(shape);
          }}
          stroke="black"
          strokeWidth={2}
        />
      </React.Fragment>
    );
  }
}