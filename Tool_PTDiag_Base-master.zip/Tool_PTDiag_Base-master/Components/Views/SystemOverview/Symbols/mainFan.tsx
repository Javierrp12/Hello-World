import React, { Component } from 'react';
import { useStrictMode, Text, Shape } from 'react-konva';

useStrictMode(true);

interface IMainFanProps {
  name: string;
  x: number;
  y: number;
  fontFamily: string;
  width: number;
  height: number;
  speed: number;
}

export class MainFan extends Component<IMainFanProps> {

  render() {
    const { name, x, y, fontFamily, width, height, speed } = this.props;
    const vCenter = width * 0.5;
    const hCenter = height * 0.5;
    const speedText = "Speed: " + speed;
    const offsetXPosition = width + 10;
    const offsetYPosition = 25;

    return (
      <React.Fragment>
        <Shape
          key={`MainFan_Symbol_${name}`}
          sceneFunc={(context, shape) => {
            const HorizontalCenterOffset = 0;
            context.translate((x + (vCenter)), (y + (hCenter) + HorizontalCenterOffset));
            context.scale(0.4, 0.4);
            // propellers marks
            for (let i = 0; i < 5; i++) {
              context.beginPath();
              context.rotate(Math.PI * 2 / 5);
              context.moveTo(20, 0);
              context.lineTo(80, 0);
              context.lineTo(80, 15);
              context.bezierCurveTo(80, 15, 80, 50, 15, 20);
              context.fillStrokeShape(shape);
              context.closePath();
            }

            // Inner circle marks
            context.beginPath();
            context.arc(0, 0, 20, 0, Math.PI * 2, true);
            context.fillStrokeShape(shape);
            context.closePath();
            // (!) Konva specific method, it is very important
            context.fillStrokeShape(shape);

          }}
          stroke='black'
          fill='white'
          strokeWidth={3}
        />
        <Text
          key={`MainFan_Text_${name}`}
          x={x + offsetXPosition}
          y={y + offsetYPosition}
          text={speedText}
          fontSize={16}
          fontFamily={fontFamily}
        />
      </React.Fragment>
    );
  }
}