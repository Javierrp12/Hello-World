import React, { Component } from 'react';
import { useStrictMode } from 'react-konva';
import { IInfo } from '../ISystemoverview';
import { DCAC } from './dcac';
import { DCDC } from './dcdc';
import { DC_DC } from './dc-dc';
import { AIF } from './aif';
import { MainFan } from './mainFan';
import { AuxiliaryFan } from './auxiliaryFan';
import { Legend } from './legend';
import { Contactor } from './contactor';
import { DCContactor } from './dcContactor';
import { Info } from './info';
import { Fuse } from './fuse';
import { safeProp } from '../../../../CommonFunctions/pointfreeUtilities';

useStrictMode(true);

interface IComponentSymbol {
  symbol: string;
  name: string;
  x: number;
  y: number;
  fontFamily: string;
  width: number;
  height: number;
  state: string;
  speed: number;
  info: IInfo[];
  command: string;
}

export class ComponentSymbol extends Component<IComponentSymbol> {
  render() {
    const { symbol, name, x, y, fontFamily, width, height, state, speed, command, info } = this.props;

    return <React.Fragment>{this.drawSymbol(symbol, name, x, y, fontFamily, width, height, state, speed, command, info)}</React.Fragment>;
  }

  private drawSymbol = (symbol: string, name: string, x: number, y: number, fontFamily: string, width: number, height: number, state: string, speed: number, command: string, info: IInfo[]) => {
    const symbols = {
      dcac: <DCAC name={name} x={x} y={y} fontFamily={fontFamily} width={width} height={height} />,
      dcdc: <DCDC name={name} x={x} y={y} width={width} height={height} />,
      'dc-dc': <DC_DC name={name} x={x} y={y} width={width} height={height} />,
      Aif: <AIF name={name} x={x} y={y} state={state} width={width} height={height} />,
      MainFan: <MainFan name={name} x={x} y={y} fontFamily={fontFamily} width={width} height={height} speed={speed} />,
      'Auxiliary Fan': <AuxiliaryFan name={name} x={x} y={y} fontFamily={fontFamily} width={width} height={height} speed={speed} />,
      Legend: <Legend x={x} y={y} fontFamily={fontFamily} />,
      Contactor: <Contactor name={name} x={x} y={y} width={width} height={height} command={command} />,
      DCContactor: <DCContactor name={name} x={x} y={y} width={width} height={height} command={command} />,
      Info: <Info info={info} x={x} y={y} fontFamily={fontFamily} />,
      Fuse: <Fuse name={name} x={x} y={y} width={width} height={height} state={state} />
    };
    return safeProp(symbol, symbols).getOrElse(null);
  };
}
