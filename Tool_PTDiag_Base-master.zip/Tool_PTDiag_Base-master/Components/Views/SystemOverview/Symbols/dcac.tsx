import React, { Component } from 'react';
import { useStrictMode, Text, Shape } from 'react-konva';

useStrictMode(true);

interface IDCACProps {
  name: string;
  x: number;
  y: number;
  fontFamily: string;
  width: number;
  height: number;
}

export class DCAC extends Component<IDCACProps> {

  render() {
    const { name, x, y, fontFamily, width, height } = this.props;
    const vCenter = width * 0.5;
    const hCenter = height * 0.5;
    const xOffset = 40;
    const yOffset = 40;

    return (
      <React.Fragment>
        <Text
          key={`DCAC_Text_${name}`}
          x={x + width - xOffset}
          y={y + height - yOffset}
          text={'3~'}
          fontSize={25}
          fontFamily={fontFamily}
        />
        <Shape
          key={`DCAC_Symbol_${name}`}
          sceneFunc={(context, shape) => {
            const HorizontalCenterOffset = 0;
            context.translate((x + (vCenter)), (y + (hCenter) + HorizontalCenterOffset));

            /* Diagonal lines */
            context.beginPath();
            context.moveTo(-56, 56);
            context.lineTo(56, -56);

            /* Horizontal lines */
            context.moveTo(-40, -45);
            context.lineTo(-25, -45);
            context.moveTo(-40, -35);
            context.lineTo(-25, -35);
            context.closePath();

            // (!) Konva specific method, it is very important
            context.fillStrokeShape(shape);
          }}
          lineCap='round'
          stroke="black"
          strokeWidth={3}
        />
      </React.Fragment>
    );
  }
}