import React, { Component } from 'react';
import { useStrictMode, Rect, Shape } from 'react-konva';
import { KonvaEventObject } from 'konva/types/Node';

useStrictMode(true);

interface IExtraDiodeProps {
  data: IDiodeProps;
  handleClickDelete: (event: KonvaEventObject<MouseEvent>) => void;
  handleDragEnd: (event: KonvaEventObject<MouseEvent>) => void;
}

interface IDiodeProps {
  x: number;
  y: number;
  componentKey: string | undefined;
  editMode: boolean;
}

export class ExtraDiode extends Component<IExtraDiodeProps> {

  render() {
    const { data } = this.props;
    const { handleClickDelete, handleDragEnd } = this.props;
    const width: number = 55;
    const height: number = 1;
    const x: number = data.x
    const y: number = data.y;

    return (
      <React.Fragment>
        <Rect
          x={x}
          y={y}
          width={width}
          height={height}
          stroke={(data.editMode === true) ? 'black' : 'transparent'}
          strokeWidth={2}
          fill={'transparent'}
          componentKey={data.componentKey}
          componentType={'Extra'}
          draggable={(data.editMode === true) ? true : false}
          onMouseEnter={(event: KonvaEventObject<MouseEvent>) => {
            if (data.editMode === true) {
              const container = event.target.getStage()!.container();
              container.style.cursor = "move";
            }
          }}
          onMouseLeave={(event: KonvaEventObject<MouseEvent>) => {
            if (data.editMode === true) {
              const container = event.target.getStage()!.container();
              container.style.cursor = "default";
            }
          }}
          onDragEnd={handleDragEnd}
          onDblClick={(event: KonvaEventObject<MouseEvent>) => {
            if (data.editMode === true) {
              handleClickDelete(event);
            }
          }}
        />
        <Shape
          sceneFunc={(context, shape) => {
            context.beginPath();
            context.moveTo(x + 15, y);
            context.lineTo(x + 15, y + 10);
            context.lineTo(x + 30, y);
            context.moveTo(x + 15, y);
            context.lineTo(x + 15, y - 10);
            context.lineTo(x + 30, y);

            context.moveTo(x + 30, y);
            context.lineTo(x + 30, y - 15);
            context.moveTo(x + 30, y);
            context.lineTo(x + 30, y + 15);
            context.fillStrokeShape(shape);
            context.closePath();

            // (!) Konva specific method, it is very important
            context.fillStrokeShape(shape);
          }}
          stroke='black'
          strokeWidth={3}
        />
      </React.Fragment>
    )
  }
}