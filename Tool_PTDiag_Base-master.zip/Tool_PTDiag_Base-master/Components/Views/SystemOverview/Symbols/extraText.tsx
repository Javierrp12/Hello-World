import React, { Component } from 'react';
import { useStrictMode, Text } from 'react-konva';
import { eq } from '../../../../CommonFunctions/pointfreeUtilities';
import { KonvaEventObject } from 'konva/types/Node';

useStrictMode(true);

interface IExtraTextProps {
  data: ITextProps;
  handleClickDelete: (event: KonvaEventObject<MouseEvent>) => void;
  handleDragEnd: (event: KonvaEventObject<MouseEvent>) => void;
}

interface ITextProps {
  x: number;
  y: number;
  name: string;
  fontSize: number;
  fontFamily: string;
  componentKey: string | undefined;
  editMode: boolean;
}

export class ExtraText extends Component<IExtraTextProps> {

  render() {
    const { data } = this.props;
    const { handleClickDelete, handleDragEnd } = this.props;

    return (
      <React.Fragment>
        <Text
          x={data.x}
          y={data.y}
          text={data.name}
          fontSize={data.fontSize}
          fontFamily={data.fontFamily}
          componentKey={data.componentKey}
          componentType={'Extra'}
          draggable={eq(data.editMode, true) ? true : false}
          onDragEnd={handleDragEnd}
          onMouseEnter={(event: KonvaEventObject<MouseEvent>) => {
            if (eq(data.editMode, true)) {
              const container = event.target.getStage()!.container();
              container.style.cursor = "move";
            }
          }}
          onMouseLeave={(event: KonvaEventObject<MouseEvent>) => {
            if (eq(data.editMode, true)) {
              const container = event.target.getStage()!.container();
              container.style.cursor = "default";
            }
          }}

          onDblClick={(event: KonvaEventObject<MouseEvent>) => {
            if (eq(data.editMode, true)) {
              handleClickDelete(event);
            }
          }}
        />
      </React.Fragment>
    );
  }
}