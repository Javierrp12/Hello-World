import React, { Component } from 'react';
import { useStrictMode, Shape } from 'react-konva';

useStrictMode(true);

interface IContactorProps {
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
  command: string;
}

export class DCContactor extends Component<IContactorProps> {
  render() {
    const { name, x, y, width, height, command } = this.props;
    const vCenter = width * 0.5;
    const hCenter = height * 0.5;

    return (
      <Shape
        key={`DCContactor_Symbol_${name}`}
        sceneFunc={(context, shape) => {
          const HorizontalCenterOffset = 0;
          context.translate(x + vCenter, y + hCenter + HorizontalCenterOffset);

          context.beginPath();
          /* Top */
          context.moveTo(-35, -25);
          context.lineTo(-25, -25);

          context.moveTo(35, -25);
          context.lineTo(25, -25);

          /* Circles */
          context.moveTo(-18, -25);
          context.arc(-20, -25, 3, 0, 2 * Math.PI, true);

          context.moveTo(25, -25);
          context.arc(20, -25, 3, 0, 2 * Math.PI, true);
          /* Switch */
          if (command === 'open') {
            context.moveTo(-15, -25);
            context.lineTo(15, -35);
          } else {
            context.moveTo(-15, -25);
            context.lineTo(15, -25);
          }

          /* Bottom */
          context.moveTo(-35, 45);
          context.lineTo(-25, 45);

          context.moveTo(35, 45);
          context.lineTo(25, 45);

          /* Circles */
          context.moveTo(-18, 45);
          context.arc(-20, 45, 3, 0, 2 * Math.PI, true);

          context.moveTo(25, 45);
          context.arc(20, 45, 3, 0, 2 * Math.PI, true);
          /* Switch */
          if (command === 'open') {
            context.moveTo(-15, 45);
            context.lineTo(15, 35);
          } else {
            context.moveTo(-15, 45);
            context.lineTo(15, 45);
          }

          context.closePath();
          // (!) Konva specific method, it is very important
          context.fillStrokeShape(shape);
        }}
        stroke="black"
        strokeWidth={3}
      />
    );
  }
}
