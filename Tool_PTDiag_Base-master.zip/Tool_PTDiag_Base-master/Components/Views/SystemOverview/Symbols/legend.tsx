import React, { Component } from 'react';
import { useStrictMode, Rect, Text } from 'react-konva';
import { map, reduce } from '../../../../CommonFunctions/pointfreeUtilities';
import { safeGetValuesObject, createTextRectangleSymbol } from '../../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');
const curry = require('folktale/core/lambda/curry');

useStrictMode(true);

interface ILegendStates {
  init: IStateProps;
  selftest: IStateProps;
  run: IStateProps;
  ready: IStateProps;
  stop: IStateProps;
  temporaryError: IStateProps;
  error: IStateProps;
  offline: IStateProps;
}

interface IStateProps {
  name: string;
  color: string;
  borderColor: string;
}

interface ILegendProps {
  x: number;
  y: number;
  fontFamily: string;
}

export class Legend extends Component<ILegendProps> {
  private componentStates: ILegendStates = {
    init: { name: "Init", color: "rgba(174, 174, 166, 255)", borderColor: "rgba(0, 0, 0, 255)" },
    selftest: { name: "Selftest", color: "rgba(39, 39, 231, 255)", borderColor: "rgba(0, 0, 0, 255)" },
    stop: { name: "Stop", color: "rgba(251, 147, 31, 225)", borderColor: "rgba(0, 0, 0, 255)" },
    ready: { name: "Ready", color: "rgba(232, 234, 44, 225)", borderColor: "rgba(0, 0, 0, 255)" },
    run: { name: "Run", color: "rgba(38, 117,38, 225)", borderColor: "rgba(0, 0, 0, 255)" },
    temporaryError: { name: "TemporaryError", color: "rgba(195,48,26, 225)", borderColor: "rgba(251, 147, 31, 225)" },
    error: { name: "Error", color: "rgba(195,48,26, 225)", borderColor: "rgba(0, 0, 0, 255)" },
    offline: { name: "Offline", color: "rgba(255,255,255, 225)", borderColor: "rgba(0, 0, 0, 255)" }
  };

  render() {
    const { x, y, fontFamily } = this.props;
    return (
      <React.Fragment>
        {this.createLegend(this.componentStates, x, y, fontFamily)}
      </React.Fragment>
    );
  }

  private createLegend = (componentStates: ILegendStates, x: number, y: number, fontFamily: string) => {
    const createTextLegend = curry(5, (fontFamily: string, xPosition: number, yPosition: number, x: IStateProps, index: number) => {
      let yPositionOffsetText = 2 + (index * 20);
      let xPositionOffsetText = 30;

      return (<Text
        key={`Legend_Text_${x.name}`}
        x={xPosition + xPositionOffsetText}
        y={yPosition + yPositionOffsetText}
        text={x.name}
        fontSize={18}
        fontFamily={fontFamily}
      />);
    });

    const createRectangleLegend = curry(4, (xPosition: number, yPosition: number, x: IStateProps, index: number) => {
      let yPositionOffsetLed = 5 + (index * 20);
      let xPositionOffsetLed = 10;

      return (<Rect
        key={`Legend_Symbol_${x.name}`}
        x={xPosition + xPositionOffsetLed}
        y={yPosition + yPositionOffsetLed}
        width={10}
        height={10}
        stroke={x.borderColor}
        strokeWidth={3}
        draggable={false}
        fill={x.color}
      />);
    });

    const createLegendSymbol = compose(map(reduce(createTextRectangleSymbol(createTextLegend(fontFamily, x, y), createRectangleLegend(x, y)), [])), safeGetValuesObject);
    return createLegendSymbol(componentStates).getOrElse(null);
  }
}