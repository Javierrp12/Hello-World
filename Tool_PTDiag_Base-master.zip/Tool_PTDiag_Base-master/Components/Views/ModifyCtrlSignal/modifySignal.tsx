import React from 'react';
import { ICTRLDigital, ICTRLAnalog } from '../../../Datastore/InitialDataInterfaces';
import { DigitalSignal } from './digitalSignal';
import { AnalogSignal } from './analogSignal';

interface IModifySignal {
  signalDataDigital: ICTRLDigital;
  signalDataAnalog: ICTRLAnalog;
  signalType: string;
  forceSignalCallback: (data: any) => void;
  cancelCallback: () => void;
  handleShowModifyMenu: () => void;
}

export class ModifySignal extends React.Component<IModifySignal> {

  render() {
    const { signalType, signalDataDigital, signalDataAnalog } = this.props;
    const { forceSignalCallback, cancelCallback, handleShowModifyMenu } = this.props;
    if (signalType === 'digital') {
      return <DigitalSignal signalData={signalDataDigital} forceSignalCallback={(data: any) => this.forceSignalCallback(data, handleShowModifyMenu, forceSignalCallback)} cancelCallback={() => this.cancelCallback(handleShowModifyMenu, cancelCallback)} />
    }

    if (signalType === 'analog') {
      return <AnalogSignal signalData={signalDataAnalog} forceSignalCallback={(data: any) => this.forceSignalCallback(data, handleShowModifyMenu, forceSignalCallback)} cancelCallback={() => this.cancelCallback(handleShowModifyMenu, cancelCallback)} />
    }

    return null;
  }

  private forceSignalCallback = (data: any, handleShowModifyMenu: () => void, forceSignalCallback: (data: any) => void) => {
    forceSignalCallback(data);
    handleShowModifyMenu();
  }

  private cancelCallback = (handleShowModifyMenu: () => void, cancelCallback: () => void) => {
    cancelCallback();
    handleShowModifyMenu();
  }

}