import React, { ChangeEvent } from 'react';
import { IAnalog, ICTRLAnalog } from '../../../Datastore/InitialDataInterfaces';
import { ModalWindow } from '../modalWindow';
import { safeProp, eq } from '../../../CommonFunctions/pointfreeUtilities';

interface IAnalogProps {
  signalData: IAnalog | ICTRLAnalog;
  forceSignalCallback: (data: modifyData) => void;
  cancelCallback: () => void;
}

interface IAnalogState {
  value: number;
}

interface modifyData {
  name: string;
  value: number;
}

export class AnalogSignal extends React.Component<IAnalogProps, IAnalogState> {
  inputValueRef: React.RefObject<HTMLInputElement>;
  constructor(props: IAnalogProps) {
    super(props);
    this.state = {
      value: safeProp('value', this.props.signalData).getOrElse(0)
    }
    this.inputValueRef = React.createRef();
  }

  render() {
    const { signalData } = this.props;
    const { forceSignalCallback, cancelCallback } = this.props;
    const { value } = this.state;

    return (
      <ModalWindow>
        <div className='modal-ptdiag'>
          <div className='modal-dialog modal-dialog-centered'>
            <div className='modal-content'>
              <div className='modal-header'>
                <div className='display-view-titel'>{safeProp('name', signalData).getOrElse('')}</div>
                <button className='close' onClick={cancelCallback}><span>x</span></button>
              </div>
              <div className='modal-body'>
                <div className="d-flex justify-content-center mt-1">
                  <form onSubmit={(data) => this.handleSubmit(data, safeProp('name', signalData).getOrElse(''), value, forceSignalCallback)}>
                    <div className="form-group">
                      <label htmlFor="valueFormControlInput">Value:</label>
                      <input type="number" className="form-control" id="valueFormControlInput" name='value' step="0.01" value={value} onChange={this.handleValueChanged} autoFocus={true} onFocus={this.handleFocus} onKeyUp={(event) => this.handlekeypress(event, cancelCallback)} ref={this.inputValueRef} />
                    </div>
                  </form>
                </div>
              </div>
              <div className='modal-footer'>
                <button className='btn btn-secondary m-2' onClick={cancelCallback}>Close</button>
                <button className='btn btn-ptdiag' onClick={() => forceSignalCallback({ name: safeProp('name', signalData).getOrElse(''), value: value })}>Set Signal</button>
              </div>
            </div>
          </div>
        </div>
      </ModalWindow>
    );
  }

  componentDidMount() {
    this.inputValueRef.current!.focus();
  }

  private handleValueChanged = (event: ChangeEvent<HTMLInputElement>) => {
    if (eq(isNaN(Number(event.target.value)), false)) {
      this.setState({ value: Number(event.target.value) });
    }
  }

  handleSubmit = (event: React.FormEvent<HTMLFormElement>, name: string, value: number, forceSignalCallback: (data: modifyData) => void) => {
    event.preventDefault();
    forceSignalCallback({ name, value });
  }

  handleFocus = (event: React.FocusEvent<HTMLInputElement>) => event.target.select();
  handlekeypress = (event: React.KeyboardEvent<HTMLInputElement>, cancelCallback: () => void) => {
    if (event.key === "Escape") {
      cancelCallback();
    }
  }

}