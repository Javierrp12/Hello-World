import React from 'react';
import { IDigital, ICTRLDigital } from '../../../Datastore/InitialDataInterfaces';
import { ModalWindow } from '../modalWindow';
import { safeProp, eq } from '../../../CommonFunctions/pointfreeUtilities';

interface IDigitalProps {
  signalData: IDigital | ICTRLDigital;
  forceSignalCallback: (data: modifyData) => void;
  cancelCallback: () => void;
}

interface IDigitalState {
  radioStatus: boolean
}

interface modifyData {
  name: string;
  value: boolean;
}

export class DigitalSignal extends React.Component<IDigitalProps, IDigitalState> {
  constructor(props: IDigitalProps) {
    super(props);
    this.state = {
      radioStatus: safeProp('status', this.props.signalData).getOrElse(false)
    }
  }

  render() {
    const { signalData } = this.props;
    const { forceSignalCallback, cancelCallback } = this.props;
    const { radioStatus } = this.state;

    return (
      <ModalWindow>
        <div className='modal-ptdiag'>
          <div className='modal-dialog modal-dialog-centered'>
            <div className='modal-content'>
              <div className='modal-header'>
                <div className='display-view-titel'>{safeProp('name', signalData).getOrElse('')}</div>
                <button className='close' onClick={cancelCallback}><span>x</span></button>
              </div>
              <div className='modal-body'>
                <div className="d-flex justify-content-center">
                  <div className="form-check form-check-inline">
                    <input className="form-check-input" type="radio" name="radioStatus" checked={eq(radioStatus, true)} onChange={() => this.handledClick(true)} id="inlineRadioTrue" value="option1" />
                    <label className="form-check-label" htmlFor="inlineRadioTrue">True</label>
                  </div>
                  <div className="form-check form-check-inline">
                    <input className="form-check-input" type="radio" name="radioStatus" checked={eq(radioStatus, false)} onChange={() => this.handledClick(false)} id="inlineRadioFalse" value="option2" />
                    <label className="form-check-label" htmlFor="inlineRadioFalse">False</label>
                  </div>
                </div>
              </div>
              <div className='modal-footer'>
                <button className='btn btn-secondary m-2' onClick={cancelCallback}>Close</button>
                <button className='btn btn-ptdiag' onClick={() => forceSignalCallback({ name: signalData.name, value: radioStatus })}>Set Signal</button>
              </div>
            </div>
          </div>
        </div>
      </ModalWindow >
    );
  }

  private handledClick = (state: boolean) => {
    this.setState({ radioStatus: state });
  }

}