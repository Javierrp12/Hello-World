import React from 'react';
import { OscilloscopeButtons } from './oscilloscopeButtons';
import { InitialScope } from './Scopes/initialScope';
import { IChannelsData } from '../../../Datastore/InitialDataInterfaces';
import { prepareToExportData } from '../../../CommonFunctions/commonFunctions';
import { DigitalScope } from './Scopes/digitalScope';
import { AnalogScope } from './Scopes/analogScope';
import { concat, eq } from '../../../CommonFunctions/pointfreeUtilities';
import {
  serializeClockDateTime, formatDateTimeClock, getDateTime, dateTimeFormat,
  prependZero, titleText, getOscilloscopeChannelsData, getOscilloscopeChannelDatasets
} from '../../../CommonFunctions/functionsSupport';
import './oscilloscope.css';

const compose = require('folktale/core/lambda/compose');

interface IOscilloscopeProps {
  showingAnalog: boolean;
  showingDigital: boolean;
  oscilloscopeData: any;
  analogChannel: IChannelsData;
  digitalChannel: IChannelsData;
  dateTime: string;
  oscilloscopeStatus: boolean;
  t: (word: string) => string;
  updateSignalType: (scope: string) => void;
  startStopOscilloscope: () => void;
}

export class Oscilloscope extends React.Component<IOscilloscopeProps> {

  render() {
    const { t, startStopOscilloscope, updateSignalType } = this.props;
    const { oscilloscopeStatus, showingAnalog, showingDigital, dateTime, analogChannel, digitalChannel, oscilloscopeData } = this.props;

    return (
      <React.Fragment>
        <div className='display-view-title' data-cy='view-title'>{t('Oscilloscope')}</div>
        <div className='container-fluid'>
          <div className='row'>
            <OscilloscopeButtons
              updateSignalType={updateSignalType}
              startStopOscilloscope={startStopOscilloscope}
              oscilloscopeStatus={oscilloscopeStatus}
              handleExportFile={(exportLink) => this.handleExportFile(exportLink, dateTime, analogChannel, digitalChannel, oscilloscopeData)}
              translation={t}
            />
          </div>
          <div className='row'>
            <div className='col'>
              {((eq(showingAnalog, false)) && (eq(showingDigital, false))) &&
                <React.Fragment>
                  <InitialScope />
                </React.Fragment>
              }
              {eq(showingAnalog, true) &&
                <React.Fragment>
                  <div className='display-view-subtitel'>{t('Analog Scope')}</div>
                  <div className='display-view-subsubtitel text-right'>
                    <div className='mb-2'>{t('Time Scale')}: 1s/div</div>
                  </div>
                  <AnalogScope data={this.getScopeData('analog', analogChannel, dateTime, oscilloscopeData)} />
                </React.Fragment>
              }
              {eq(showingDigital, true) &&
                <React.Fragment>
                  <div className='display-view-subtitel'>{t('Digital Scope')}</div>
                  <div className='display-view-subsubtitel text-right'>
                    <div className='mb-2'>{t('Time Scale')}: 1s/div</div>
                  </div>
                  <DigitalScope data={this.getScopeData('digital', digitalChannel, dateTime, oscilloscopeData)} />
                </React.Fragment>
              }
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }

  private handleExportFile = (exportLink: React.RefObject<HTMLAnchorElement>, dateTime: string, analogChannel: IChannelsData, digitalChannel: IChannelsData, oscilloscopeData: any): void => {
    /* Date Time */
    const getCurrentDate = compose(getDateTime, dateTimeFormat);
    const getOscilloscopeDateTime = compose(serializeClockDateTime, getCurrentDate);
    const getCurrentDateTime = compose(formatDateTimeClock('Date;DD.MM.YYYY\nTime;hh:mm:ss\n'), compose(compose(prependZero('hours'), compose(prependZero('minutes'), prependZero('seconds'))), getOscilloscopeDateTime));
    /* Oscilloscope Data */
    const getOscilloscopeDataString = concat(titleText(getOscilloscopeChannelsData("analog", analogChannel, dateTime, oscilloscopeData), '', '\nAnalog Section'),
      titleText(getOscilloscopeChannelsData("digital", digitalChannel, dateTime, oscilloscopeData), '', '\nDigital Section'));
    const expectString = concat(getCurrentDateTime(dateTime), getOscilloscopeDataString);
    prepareToExportData({ name: 'OscilloscopeData.csv', type: 'text/csv;charset=utf-8', expectedString: expectString }, exportLink);
  }

  private getScopeData = (type: string, channels: IChannelsData, dateTime: string, oscilloscopeData: any) => {
    return ({ datasets: getOscilloscopeChannelDatasets(type, channels, dateTime, oscilloscopeData) });
  }

}
