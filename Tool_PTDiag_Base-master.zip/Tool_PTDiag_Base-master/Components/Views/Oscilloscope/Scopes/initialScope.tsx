import React, { Component } from 'react';
import { Chart } from 'chart.js';

export class InitialScope extends Component {
  chartRef: React.RefObject<HTMLCanvasElement>;
  scope: any;
  constructor(props: {}) {
    super(props);
    this.chartRef = React.createRef();
  }

  render() {
    return (
      <canvas ref={this.chartRef} />
    );
  }
  componentDidMount() {
    const context = this.chartRef.current!.getContext('2d');
    if (context) {
      this.scope = new Chart(context, {
        type: 'line',
        options: {
          scales: {
            xAxes: [{
              gridLines: {
                display: true,
              },
              ticks: {
                fontSize: 15,
              },
              afterTickToLabelConversion: function (q) {
                for (var tick in q.ticks) {
                  q.ticks[tick] = '';
                }
              }
            }],
            yAxes: [{
              gridLines: {
                drawBorder: false,
              },
              ticks: {
                beginAtZero: true,
                fontSize: 15,
                maxTicksLimit: 10,
              },
              afterTickToLabelConversion: function (q) {
                for (var tick in q.ticks) {
                  q.ticks[tick] = '';
                }
              }
            }]
          },
        },
        data: {
          labels: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30],
          datasets: [{
            label: 'Scope',
            data: [],
            fill: 'none',
            backgroundColor: '#4169e1',
            pointRadius: 2,
            borderColor: '#4169e1',
            borderWidth: 1,
            lineTension: 0
          }]
        }
      });
    }
  }

}