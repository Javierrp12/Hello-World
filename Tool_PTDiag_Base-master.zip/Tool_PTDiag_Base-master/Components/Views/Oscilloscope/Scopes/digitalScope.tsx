import React from 'react';
import { Chart } from 'chart.js';

interface IDigitalScopeProps {
  data: any
}

export class DigitalScope extends React.Component<IDigitalScopeProps> {
  chartRef: React.RefObject<HTMLCanvasElement>;
  scope: any;
  constructor(props: IDigitalScopeProps) {
    super(props);
    this.chartRef = React.createRef();
  }

  render() {
    return (
      <canvas ref={this.chartRef} />
    );
  }

  componentDidUpdate() {
    this.scope.data = this.props.data;
    this.scope.update();
  }

  componentDidMount() {
    const context = this.chartRef.current?.getContext('2d');
    if (context) {
      this.scope = new Chart(context, {
        type: 'line',
        options: {
          animation: {
            duration: 0,
          },
          responsiveAnimationDuration: 0,
          hover: {
            animationDuration: 5
          },
          scales: {
            xAxes: [{
              type: 'time',
              time: {
                unit: 'second',
                displayFormats: {
                  second: 'HH:mm:ss'
                }
              },
              ticks: {
                fontSize: 15,
                maxTicksLimit: 30,
                suggestedMax: 30,
                suggestedMin: 0
              },
              afterTickToLabelConversion: function (q) {
                for (var tick in q.ticks) {
                  q.ticks[tick] = '';
                }
              }
            }],
            yAxes: [{
              ticks: {
                maxTicksLimit: 9,
                stepSize: 1,
                beginAtZero: true,
                fontSize: 15,
                suggestedMax: 8,
                suggestedMin: 0
              },
              afterTickToLabelConversion: function (q) {
                for (var tick in q.ticks) {
                  if (tick === '0') {
                    q.ticks[tick] = '';
                  } else {
                    q.ticks[tick] = `Ch ${tick}`;
                  }
                }
              }
            }]
          },
        },
        data: this.props.data
      });
    }
  }
}