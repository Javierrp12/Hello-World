import React from 'react';
import { Chart } from 'chart.js';

interface IAnalogScopeProps {
  data: any
}

export class AnalogScope extends React.Component<IAnalogScopeProps> {
  chartRef: React.RefObject<HTMLCanvasElement>;
  scope: any;
  constructor(props: IAnalogScopeProps) {
    super(props);
    this.chartRef = React.createRef();
  }

  render() {
    return (
      <canvas ref={this.chartRef} />
    );
  }

  componentDidUpdate() {
    this.scope.data = this.props.data;
    this.scope.update();
  }

  componentDidMount() {
    const context = this.chartRef.current?.getContext('2d');
    if (context) {
      this.scope = new Chart(context, {
        type: 'line',
        options: {
          animation: {
            duration: 0,
          },
          responsiveAnimationDuration: 0,
          hover: {
            animationDuration: 5
          },
          scales: {
            xAxes: [{
              type: 'time',
              time: {
                unit: 'second',
                displayFormats: {
                  second: 'HH:mm:ss'
                }
              },
              ticks: {
                fontSize: 15,
                maxTicksLimit: 30,
                suggestedMax: 30,
                suggestedMin: 0,
              },
              afterTickToLabelConversion: function (q) {
                for (var tick in q.ticks) {
                  q.ticks[tick] = '';
                }
              }
            }],
            yAxes: [{
              ticks: {
                beginAtZero: true,
                fontSize: 15,
              },
            }]
          },
        },
        data: this.props.data
      });
    }
  }
}