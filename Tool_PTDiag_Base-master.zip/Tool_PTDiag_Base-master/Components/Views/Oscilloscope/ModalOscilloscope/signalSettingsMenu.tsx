import React from 'react';
import { ModalWindow } from '../../modalWindow';

interface ISignalSettingsMenuProps {
  translation: (word: string) => string;
  cancelCallback: () => void;
  signalSelection: (scope: string) => void;
}

export class SignalSettingsMenu extends React.Component<ISignalSettingsMenuProps> {

  render() {
    const { translation, cancelCallback, signalSelection } = this.props;

    return (
      <ModalWindow>
        <div className='modal-ptdiag'>
          <div className='modal-dialog modal-dialog-centered'>
            <div className='modal-content'>
              <div className='modal-header'>
                <div className='display-view-titel' data-cy='modal-title'>{translation('Signal Settings')}</div>
                <button className='close' onClick={cancelCallback}><span>x</span></button>
              </div>
              <div className='modal-body' data-cy='modal-content'>
                <div className='d-flex align-items-center flex-column'>
                  <button className='btn btn-ptdiag my-2 col-6' onClick={() => this.handleClickSelection('Analog', signalSelection, cancelCallback)}>{translation('Analog Selection')}</button>
                  <button className='btn btn-ptdiag my-2 col-6' onClick={() => this.handleClickSelection('Digital', signalSelection, cancelCallback)}>{translation('Digital Selection')}</button>
                </div>
              </div>
              <div className='modal-footer' data-cy='modal-buttons'>
                <button className='btn btn-secondary m-2' onClick={cancelCallback}>{translation('Close')}</button>
              </div>
            </div>
          </div>
        </div>
      </ModalWindow>
    );
  }

  private handleClickSelection = (scope: string, signalSelection: (scope: string) => void, cancelCallback: () => void): void => {
    cancelCallback();
    signalSelection(scope);
  }

}