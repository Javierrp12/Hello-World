import React, { ChangeEvent } from 'react';
import { ModalWindow } from '../../modalWindow';
import { IChannelsData } from '../../../../Datastore/InitialDataInterfaces';
import { IScopeData } from '../../../../Datastore/StateData/stateActionCreator';
import { IClearChannel } from '../../../../Datastore/ModelData/modelActionCreator';
import { IChannels } from '../../../../Datastore/InitialDataInterfaces';
import { toLowerCase, safeHead, safeProp, eq, filter } from '../../../../CommonFunctions/pointfreeUtilities';
import { getModuleSignals, safeGetValuesObject, checkComponentCondition, findeSelectedSignal, safeObjectSearch } from '../../../../CommonFunctions/functionsSupport'

const compose = require('folktale/core/lambda/compose');

interface ISignalSelectionModalProps {
  userlevel: string;
  signalType: string;
  channels: string[];
  modules: string[];
  modulesData: any;
  channel: string;
  module: string;
  signal: string;
  channelStatus: boolean;
  channelsData: IChannelsData;
  t: (word: string) => string;
  cancelCallback: () => void;
  clearChannel: (data: IClearChannel) => void;
  addChannel: (type: string, channelData: IChannels) => void;
  updateShowingScope: (data: IScopeData) => void;
}

interface ISignalSelectionModalState {
  channel: string;
  module: string;
  signal: string;
  channelStatus: boolean;
}

export class SignalSelectionModal extends React.Component<ISignalSelectionModalProps, ISignalSelectionModalState> {
  constructor(props: ISignalSelectionModalProps) {
    super(props);
    this.state = {
      channel: this.props.channel,
      module: this.props.module,
      signal: this.props.signal,
      channelStatus: this.props.channelStatus
    }
  }

  render() {
    const { channelsData, modulesData, signalType, channels, modules, userlevel } = this.props;
    const { t, cancelCallback, clearChannel, updateShowingScope, addChannel } = this.props;
    const { channel, module, signal, channelStatus } = this.state;

    return (
      <ModalWindow>
        <div className='modal-ptdiag'>
          <div className='modal-dialog modal-dialog-centered'>
            <div className='modal-content'>
              <div className='modal-header'>
                <div className='display-view-titel' data-cy='modal-title'>{t(`${signalType} Selection`)}</div>
                <button className='close' onClick={cancelCallback}><span>x</span></button>
              </div>
              <div className='modal-body'>
                <div className='container-fluid' data-cy='modal-content'>
                  <div className='row'>
                    <div className="col-6">
                      <div className="form-group">
                        <label htmlFor="formControlChannel">{t('Channel')}</label>
                        <select className="form-control" id="formControlChannel" name='channel' value={channel} onChange={(event) => this.handleChannelChanged(event, channelsData, modules, module, modulesData, signalType, userlevel)}>
                          {channels.map(channel => <option key={channel} value={channel}>{channel}</option>)}
                        </select>
                      </div>
                    </div>
                    <div className="col-6">
                      <div className="form-group">
                        <label htmlFor="formControlModule">{t('Module')}</label>
                        <select className="form-control" id="formControlModule" name='module' value={module} onChange={(event) => this.handleModuleChanged(event, modulesData, signalType, userlevel)}>
                          {modules.map(module => <option key={module} value={module}>{module}</option>)}
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className='row'>
                    <div className="col-6">
                      <div className="form-group">
                        <label htmlFor="formControlSignal">{t('Signal')}</label>
                        <select className="form-control" id="formControlSignal" name='signal' value={signal} onChange={this.handleSignalChanged}>
                          {
                            getModuleSignals(modulesData, module, toLowerCase(signalType), userlevel).map((signal: any) => <option key={`${signal.category}_${signal.name}`} value={`${signal.category}_${signal.name}`}>{signal.name}</option>)
                          }
                        </select>
                      </div>
                    </div>
                    <div className="col-6">
                      <label>{t('Channel Status')}</label>
                      <div className="col-12">
                        <input type="checkbox" id="channelStatus" className="switch-custom" checked={channelStatus} onChange={() => this.handleStatusChanged(channelStatus)} />
                        <label className="label" htmlFor="channelStatus"></label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className='modal-footer' data-cy='modal-buttons'>
                <button className='btn btn-secondary m-2' onClick={cancelCallback}>{t('Close')}</button>
                <button className='btn btn-ptdiag m-2' onClick={() => this.handleOK(this.state, channelsData, signalType, modulesData, userlevel, clearChannel, updateShowingScope, addChannel, cancelCallback)}>OK</button>
              </div>
            </div>
          </div>
        </div>
      </ModalWindow>
    );
  }

  private handleChannelChanged = (event: ChangeEvent<HTMLSelectElement>, channelsData: IChannelsData, modules: string[], module: string, modulesData: any, signalType: string, userlevel: string): void => {
    event.persist();
    this.setState({ channel: event.target.value }, () => {
      const getChannel = safeProp(event.target.value);
      getChannel(channelsData).matchWith({
        Just: (value: any) => {
          const channelData = value.getOrElse();
          this.setState({ module: safeProp('module', channelData).getOrElse(''), signal: `${safeProp('category', channelData).getOrElse('')}_${safeProp('signal', channelData).getOrElse('')}`, channelStatus: true });
        },
        Nothing: () => {
          const signal = safeHead(getModuleSignals(modulesData, module, toLowerCase(signalType), userlevel)).getOrElse({});
          this.setState({ module: safeHead(modules).getOrElse(''), channelStatus: false, signal: `${safeProp('category', signal).getOrElse('')}_${safeProp('name', signal).getOrElse('')}` });
        }
      });
    });
  }

  private handleModuleChanged = (event: ChangeEvent<HTMLSelectElement>, modulesData: any, signalType: string, userlevel: string): void => {
    event.persist();
    this.setState({ module: event.target.value }, () => {
      const signal = safeHead(getModuleSignals(modulesData, event.target.value, toLowerCase(signalType), userlevel)).getOrElse({});
      this.setState({ signal: `${safeProp('category', signal).getOrElse('')}_${safeProp('name', signal).getOrElse('')}` });
    });
  }

  private handleSignalChanged = (event: ChangeEvent<HTMLSelectElement>): void => {
    this.setState({ signal: event.target.value });
  }

  private handleStatusChanged = (channelStatus: boolean) => {
    this.setState({ channelStatus: !channelStatus });
  }


  handleOK = (state: ISignalSelectionModalState, channelsData: IChannelsData, signalType: string, modulesData: any, userlevel: string, clearChannel: (data: IClearChannel) => void, updateShowingScope: (data: IScopeData) => void, addChannel: (type: string, channelData: IChannels) => void, cancelCallback: () => void) => {
    const scaleFactor = {
      analog: 1,
      digital: 1.25
    };
    const offset = {
      analog: 0,
      digital: {
        Ch1: 7,
        Ch2: 6,
        Ch3: 5,
        Ch4: 4,
        Ch5: 3,
        Ch6: 2,
        Ch7: 1,
        Ch8: 0
      }
    }

    const getSignalData = checkComponentCondition(safeProp('channelStatus', state).getOrElse(false));
    getSignalData({}).matchWith({
      Ok: () => {
        const findSignal = compose(safeHead, filter(findeSelectedSignal(safeProp('signal', state).getOrElse(''))))
        const signal = findSignal(getModuleSignals(modulesData, safeProp('module', state).getOrElse(''), toLowerCase(signalType), userlevel)).getOrElse({});
        const channels = safeGetValuesObject(channelsData).getOrElse([]);
        if (eq(channels.length, 0)) {
          updateShowingScope({ scope: `showing${this.props.signalType}`, value: true });
        }
        addChannel(signalType,
          {
            channel: safeProp('channel', state).getOrElse(''),
            module: safeProp('module', state).getOrElse(''),
            datastore: safeProp('datastore', signal).getOrElse(''),
            category: safeProp('category', signal).getOrElse(''),
            signal: safeProp('name', signal).getOrElse(''),
            unit: safeProp('unit', signal).getOrElse(''),
            offset: safeObjectSearch(`${toLowerCase(signalType)}.${safeProp('channel', state).getOrElse('')}`, offset).getOrElse(0),
            scaleFactor: safeProp(toLowerCase(signalType), scaleFactor).getOrElse(1)
          })
      },
      Error: () => {
        const getChannelData = safeProp(safeProp('channel', state).getOrElse(''));
        getChannelData(channelsData).matchWith({
          Just: () => {
            const channels = safeGetValuesObject(channelsData).getOrElse([]);
            if (eq(channels.length, 1)) {
              updateShowingScope({ scope: `showing${this.props.signalType}`, value: false });
            }
            clearChannel({ type: signalType, channel: state.channel });
          },
          Nothing: () => { }
        });
      }
    });
    cancelCallback();
  }

}
