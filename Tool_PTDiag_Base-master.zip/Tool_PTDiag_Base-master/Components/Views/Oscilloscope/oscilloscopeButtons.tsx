import React, { createRef } from 'react';
import { SignalSelectionModal } from './ModalOscilloscope/signalSelectionModal';
import { SignalSettingsMenu } from './ModalOscilloscope/signalSettingsMenu';
import { SignalSelectionConnector } from '../../../ConnectingComponents/Oscilloscope/signalSelectionConnector';
import { eq } from '../../../CommonFunctions/pointfreeUtilities';

const ConnectorSignalSelection = SignalSelectionConnector(SignalSelectionModal);

interface IOscilloscopeButtonsProps {
  oscilloscopeStatus: boolean;
  translation: (word: string) => string;
  updateSignalType: (scope: string) => void;
  startStopOscilloscope: () => void;
  handleExportFile: (link: React.RefObject<HTMLAnchorElement>) => void;
}

interface IOscilloscopeButtonsState {
  showSignalSettings: boolean,
  showSignalSelection: boolean
}

export class OscilloscopeButtons extends React.Component<IOscilloscopeButtonsProps, IOscilloscopeButtonsState> {
  exportLink: React.RefObject<HTMLAnchorElement>;
  constructor(props: IOscilloscopeButtonsProps) {
    super(props);
    this.state = {
      showSignalSettings: false,
      showSignalSelection: false
    }
    this.exportLink = createRef<HTMLAnchorElement>();
  }

  render() {
    const { oscilloscopeStatus } = this.props;
    const { translation, updateSignalType, handleExportFile, startStopOscilloscope } = this.props;
    const { showSignalSettings, showSignalSelection } = this.state;
    return (
      <React.Fragment>
        {showSignalSettings === true &&
          <SignalSettingsMenu translation={translation} cancelCallback={() => this.showSignalSettings(showSignalSettings)} signalSelection={(scope: string) => this.updateSignalSelection(scope, showSignalSettings, showSignalSelection, updateSignalType)} />
        }
        {showSignalSelection === true &&
          <ConnectorSignalSelection cancelCallback={() => this.showSignalSelection(showSignalSelection)} />
        }
        < div className='col text-center' data-cy='oscilloscope-buttons'>
          <button className={`btn btn-ptdiag m-2 col-2`} onClick={startStopOscilloscope}>
            {eq(oscilloscopeStatus, true) &&
              <i className="fas fa-pause fa-lg"></i>
            }
            {eq(oscilloscopeStatus, false) &&
              <i className="fas fa-play fa-lg"></i>
            }
          </button>
          <button className='btn btn-ptdiag m-2 col-2' onClick={() => this.showSignalSettings(showSignalSettings)}>{translation('Signal Settings')}</button>
          <button className='btn btn-ptdiag m-2 col-2' onClick={() => handleExportFile(this.exportLink)}>{translation('Export Data')}</button>
          <a className='visually-hidden' href='/#' ref={this.exportLink}>Export Oscilloscope Data</a>
        </div >
      </React.Fragment>
    );
  }

  private showSignalSettings = (showSignalSettings: boolean): void => {
    this.setState({ showSignalSettings: !showSignalSettings })
  }

  private showSignalSelection = (showSignalSelection: boolean): void => {
    this.setState({ showSignalSelection: !showSignalSelection })
  }

  private updateSignalSelection = (scope: string, showSignalSettings: boolean, showSignalSelection: boolean, updateSignalType: (scope: string) => void): void => {
    updateSignalType(scope);
    this.setState({ showSignalSettings: !showSignalSettings }, () => this.showSignalSelection(showSignalSelection));
  }

}
