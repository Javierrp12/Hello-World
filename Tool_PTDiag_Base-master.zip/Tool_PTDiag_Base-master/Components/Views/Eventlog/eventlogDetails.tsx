import React from 'react';
import { IAnalog, IDigital, IEventLogItem } from '../../../Datastore/InitialDataInterfaces';
import { AnalogSignals } from './analogSignals';
import { DigitalSignals } from './digitalSignals';
import { safeGetKeysObject } from '../../../CommonFunctions/functionsSupport';

interface IEventlogDetailsProps {
  eventlogItem: IEventLogItem;
  analogData: IAnalog[];
  digitalData: IDigital[];
  digitalModuleSignals: IDigital[];
  detailsCancelCallback: () => void;
  t: (word: string) => string;
}

export class EventlogDetails extends React.Component<IEventlogDetailsProps> {

  render() {
    const { eventlogItem, digitalData, digitalModuleSignals, analogData } = this.props;
    const { t, detailsCancelCallback } = this.props;

    if (safeGetKeysObject(eventlogItem).getOrElse([]).length === 0) {
      detailsCancelCallback();
    }

    return (
      <div className='container-fluid'>
        <div className='row'>
          <div className='col'>
            <div className='display-view-title' data-cy='view-title'>{eventlogItem.flag}</div>
            <div className='container-fluid'>
              <div className='row'>
                <div className='col-12 col-xl-8'>
                  <DigitalSignals
                    digitalData={digitalData}
                    digitalModuleSignals={digitalModuleSignals}
                    translation={t}
                  />
                </div>
                <div className='col'>
                  <AnalogSignals
                    analogData={analogData}
                    translation={t}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className='row mt-4'>
          <div className='col'>
            <button className='btn btn-secondary' onClick={detailsCancelCallback} data-cy='details-back-button'>{t('Back')}</button>
          </div>
        </div>
      </div>
    );
  }
}