import React from 'react';
import { IEventLogItem } from '../../../Datastore/InitialDataInterfaces';
import { IDetailsCallback, ISignalDescriptionCallback } from '../../../ConnectingComponents/Eventlog/eventLogConnector';
import { digital } from '../../../Datastore/StateData/helpSystemListTypes';

interface IEventLogProps {
  eventLogEntries: IEventLogItem[];
  detailsCallback: (index: IDetailsCallback) => void;
  signalDescriptionCallback: (signalDescriptionData: ISignalDescriptionCallback) => void;
  translation: (word: string) => string;
}

export class EventLogList extends React.Component<IEventLogProps> {

  render() {
    const { eventLogEntries } = this.props;
    const { translation, detailsCallback, signalDescriptionCallback } = this.props;

    if (eventLogEntries.length === 0) {
      return <tr><td className='text-center font-weight-bold' colSpan={5}>{translation('No Entries Found')}</td></tr>;
    }

    return (
      eventLogEntries.map((item: IEventLogItem) => (
        <tr key={`${item.timestamp}_${item.sequenceNumber}_${item.flag}`}>
          <td className={`${item.severity}`}></td>
          <td>{item.module}</td>
          <td>{item.sequenceNumber}</td>
          <td>{item.timestamp}</td>
          <td>{item.flag}</td>
          <td>
            <button className='btn btn-outline-secondary btn-sm mr-2'
              onClick={() => detailsCallback({ index: item.index, module: item.module! })}>
              {translation('Details')}
            </button>
            <button className='btn btn-outline-secondary btn-sm'
              onClick={() => signalDescriptionCallback({ list: digital, signal: item.flag, module: item.module! })}>
              {translation('Signal Description')}</button>
          </td>
        </tr>
      ))
    );
  }
}