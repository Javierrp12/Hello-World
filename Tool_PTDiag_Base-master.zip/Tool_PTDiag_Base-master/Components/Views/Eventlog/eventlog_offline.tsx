import React, { createRef } from 'react';
import { IMatch } from '../../../RoutingComponents/routingDisplayView';
import { IEventLogItem, IEventLog } from '../../../Datastore/InitialDataInterfaces';
import { IDetailsCallback, ISignalDescriptionCallback } from '../../../ConnectingComponents/Eventlog/eventLogConnector';
import { Modules } from '../../../Datastore/ModelData/modulesTypes';
import { ModulesTabConnector } from '../../../ConnectingComponents/TabModules/modulesTabConnector';
import { ModulesTab } from '../../ModulesTab/modulesTab';
import { EventlogDetailsConnector } from '../../../ConnectingComponents/Eventlog/eventlogDetailsConnector';
import { EventLogList } from './eventlogList';
import { EventlogDetails } from './eventlogDetails';
import { Legend } from './Legend/legend';
import { ViewColumn } from '../viewColumnSort';
import { map, toLowerCase, sortBy, safeProp, reduce } from '../../../CommonFunctions/pointfreeUtilities';
import {
  getIconColumn, getColumnDirection, safeGetKeysObject, filterModule,
  getModulesArray, byColumn, reverseArray, checkDirection
} from '../../../CommonFunctions/functionsSupport';
import './eventlog.css';

const compose = require('folktale/core/lambda/compose');

interface IEventLogProps {
  activeModule: keyof typeof Modules;
  userlevel: string;
  eventLogEntries: IEventLog;
  showAllModules: boolean;
  match: IMatch;
  t: (word: string) => string;
  signalDescriptionCallback: (signalDescriptionData: ISignalDescriptionCallback) => void;
  detailsCallback: (index: IDetailsCallback) => void;
  getEventlog: () => void;
  showAllModulesCallback: () => void;
}

interface IEventLogState {
  currentColumn: string;
  direction: string;
}

const ConnectorModulesTab = ModulesTabConnector(ModulesTab);
const ConnectorEventlogDetails = EventlogDetailsConnector(EventlogDetails);

export class EventLog extends React.Component<IEventLogProps, IEventLogState> {
  private exportLink: React.RefObject<HTMLAnchorElement>;
  constructor(props: IEventLogProps) {
    super(props);
    this.state = {
      currentColumn: 'timestamp',
      direction: 'up'
    }
    this.exportLink = createRef<HTMLAnchorElement>();
  }

  render() {
    const { eventLogEntries, showAllModules, activeModule, match } = this.props;
    const { t, signalDescriptionCallback, detailsCallback, showAllModulesCallback } = this.props;
    const { currentColumn, direction } = this.state;
    const paramsDetails = match.params.mode;

    if ((paramsDetails !== undefined) && (paramsDetails === "details")) {
      return <ConnectorEventlogDetails />;
    }

    return (
      <React.Fragment>
        <div className='display-view-title' data-cy="view-title">{t('EventLog')}</div>
        <div className='text-right'><ConnectorModulesTab /></div>
        <div className='m-2'>
          <div className="form-group form-check">
            <input type="checkbox" className="form-check-input" id="hide-inactive-signals" checked={showAllModules} onChange={showAllModulesCallback} data-cy='show-all-modules-checkbox' />
            <label className="form-check-label" htmlFor="showAllmodulesCheck">{t('Show all modules')}</label>
          </div>
          <a className='visually-hidden' href='/#' ref={this.exportLink} download>Export EventLog Data</a>
          <table className='table table-hover table-fixHead display-view-table'>
            <thead>
              <tr>
                <th scope='col'>{t('Severity')}</th>
                <ViewColumn translation={t} column={'Module'} handleClickSortCallback={(column) => this.handleClickSort(column, currentColumn, direction)} checkForSymbolCallback={(column) => getIconColumn(direction, 'fas fa-sort', currentColumn, toLowerCase(column))} />
                <ViewColumn translation={t} column={'Sequence Number'} handleClickSortCallback={(column) => this.handleClickSort(column, currentColumn, direction)} checkForSymbolCallback={(column) => getIconColumn(direction, 'fas fa-sort', currentColumn, toLowerCase(column))} />
                <ViewColumn translation={t} column={'TimeStamp'} unit='(UTC)' handleClickSortCallback={(column) => this.handleClickSort(column, currentColumn, direction)} checkForSymbolCallback={(column) => getIconColumn(direction, 'fas fa-sort', currentColumn, toLowerCase(column))} />
                <ViewColumn translation={t} column={'Event'} handleClickSortCallback={(column) => this.handleClickSort(column, currentColumn, direction)} checkForSymbolCallback={(column) => getIconColumn(direction, 'fas fa-sort', currentColumn, toLowerCase(column))} />
                <th scope='col'></th>
              </tr>
            </thead>
            <tbody data-cy='eventlog-table'>
              <EventLogList
                eventLogEntries={this.sortEventogs(eventLogEntries, currentColumn, direction, showAllModules, activeModule)}
                signalDescriptionCallback={signalDescriptionCallback}
                detailsCallback={detailsCallback}
                translation={t}
              />
            </tbody>
          </table>
          <Legend translation={t} />
        </div>
      </React.Fragment>
    );
  }

  componentDidMount() {
    this.props.getEventlog();
  }

  private handleClickSort = (column: string, currentColumn: string, direction: string): void => {
    const setDirection = compose(checkDirection(direction), getColumnDirection(toLowerCase(column)));
    this.setState({ currentColumn: toLowerCase(column), direction: setDirection(currentColumn) });
  }

  private sortEventogs = (eventlogLogEntries: IEventLog, currentColumn: string, direction: string, showAllModules: boolean, activeModule: keyof typeof Modules): IEventLogItem[] => {
    const eventLogColumns = {
      'event': 'flag',
      'sequence number': 'sequenceNumber',
      'module': 'module',
      'timestamp': 'timestamp'
    };
    const filterModules = compose(map(filterModule(showAllModules, activeModule)), safeGetKeysObject);
    const createNewArray = compose(map(reduce(getModulesArray(eventlogLogEntries), [])), filterModules);
    const createNewSortedArray = compose(map(sortBy(byColumn(safeProp(currentColumn, eventLogColumns).getOrElse(''), 'dateTime'))), createNewArray);
    const generateEventLogEntriesArray = compose(map(reverseArray(direction)), createNewSortedArray);
    return generateEventLogEntriesArray(eventlogLogEntries).getOrElse([]);
  }

}
