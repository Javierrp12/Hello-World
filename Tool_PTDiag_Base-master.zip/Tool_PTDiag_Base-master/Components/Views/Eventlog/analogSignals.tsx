import React from 'react';
import { IAnalog } from '../../../Datastore/InitialDataInterfaces';
import { map, chain } from '../../../CommonFunctions/pointfreeUtilities';
import { safeNewArray } from '../../../CommonFunctions/functionsSupport';

interface IAnalogSignals {
  analogData: IAnalog[];
  translation: (word: string) => string;
}

export class AnalogSignals extends React.Component<IAnalogSignals> {

  render() {
    const { analogData } = this.props;
    const { translation } = this.props;

    return (
      <React.Fragment>
        <div className="d-flex justify-content-between mt-4">
          <div className='display-view-subtitle'>{translation('Analog Signals')}</div>
        </div>
        <table className='table table-hover table-fixHead display-view-table mt-2'>
          <thead>
            <tr className='font-weight-bold ptdiag-color-text'>
              <th scope='col'>{translation('Signal')}</th>
              <th scope='col'>{translation('Value')}</th>
              <th scope='col'>{translation('Unit')}</th>
            </tr>
          </thead>
          <tbody>
            {this.analogList(analogData, translation)}
          </tbody>
        </table>
      </React.Fragment>
    );
  }

  private analogList = (analogData: IAnalog[], translation: (word: string) => string) => {
    const generateAnalogEntry = (x: IAnalog) => <tr key={x.name}><td>{x.name}</td><td>{x.value}</td><td>{x.unit}</td></tr>;
    const getEvents = safeNewArray;
    return getEvents(analogData).matchWith({
      Just: (value: any) => chain(map(generateAnalogEntry), value),
      Nothing: () => <tr><td colSpan={5} className='text-center'>{translation('No Entries Found')}</td></tr>
    });
  }

}
