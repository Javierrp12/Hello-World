import React from 'react';
import { IDigital } from '../../../Datastore/InitialDataInterfaces';
import { Legend } from '../ModuleSignals/Legend/legend';
import { filter, reduce, map, chain } from '../../../CommonFunctions/pointfreeUtilities';
import { safeNewArray, addSeverityProperty, eq2 } from '../../../CommonFunctions/functionsSupport';
import '../ModuleSignals/moduleSignals.css';

const compose = require('folktale/core/lambda/compose');

interface IDigitalSignals {
  digitalData: IDigital[];
  digitalModuleSignals: IDigital[];
  translation: (word: string) => string;
}

export class DigitalSignals extends React.Component<IDigitalSignals> {

  render() {
    const { digitalData, digitalModuleSignals } = this.props;
    const { translation } = this.props;

    return (
      <React.Fragment>
        <div className="d-flex justify-content-between mt-4">
          <div className='display-view-subtitle'>{translation('Digital Signals')}</div>
        </div>
        <table className='table table-hover table-fixHead display-view-table mt-2'>
          <thead>
            <tr className='font-weight-bold ptdiag-color-text'>
              <th scope='col' className='text-center'>{translation('Signals')}</th>
            </tr>
          </thead>
        </table>
        <div className='container-fluid'>
          <div className='row'>
            {this.digitalList(digitalData, digitalModuleSignals, translation)}
          </div>
        </div>
        <Legend translation={translation} />
      </React.Fragment>
    );
  }

  private digitalList = (digitalData: IDigital[], digitalModulesSignals: IDigital[], translation: (word: string) => string) => {
    const generateDigitalEntry = (x: IDigital, index: number) =>
      <div key={`${x.name}_${index}`} className='col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 p-1'>
        <button className={`btn btn-outline-primary digital-signal-snapshot-hover rounded-pill col  bg-${x.severity} text-truncate`}>{x.name}</button>
      </div>;
    const getEvents = compose(map(filter(eq2(true, 'value'))), safeNewArray);
    const getDigitalEvent = compose(map(reduce(addSeverityProperty(digitalModulesSignals), [])), getEvents);
    return getDigitalEvent(digitalData).matchWith({
      Just: (value: any) => chain(map(generateDigitalEntry), value),
      Nothing: () => <div className='col text-center'>{translation('No Entries Found')}</div>
    });
  }

}
