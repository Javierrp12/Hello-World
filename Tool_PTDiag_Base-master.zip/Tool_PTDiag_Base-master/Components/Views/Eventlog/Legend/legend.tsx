import React, { Component } from 'react';

interface ILegendProps {
  translation: (word: string) => string;
}

export class Legend extends Component<ILegendProps> {

  render() {
    const { translation } = this.props;
    return (
      <React.Fragment>
        <div data-cy='eventlog-legend'>
          <div>{translation('Legend')}</div>
          <div className='pl-5 pr-5 col-6 col-lg-4 col-xl-3 icon-major-legend'><span>{translation('Error Major')}</span></div>
          <div className='pl-5 pr-5 col-6 col-lg-4 col-xl-3 icon-minor-legend'><span>{translation('Error Minor')}</span></div>
          <div className='pl-5 pr-5 col-6 col-lg-4 col-xl-3 icon-warning-legend'><span>{translation('Warning')}</span></div>
          <div className='pl-5 pr-5 col-6 col-lg-4 col-xl-3 icon-info-legend'><span>{translation('Info')}</span></div>
        </div>
      </React.Fragment>
    )
  }
}