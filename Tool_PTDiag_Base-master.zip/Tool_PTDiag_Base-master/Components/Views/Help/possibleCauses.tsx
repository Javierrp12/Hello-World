import React, { Component } from 'react';
import { IPossibleCausesEntry, ICorrectiveActionsEntry } from '../../../Datastore/InitialDataInterfaces';
import { CorrectiveActions } from './correctiveActions';
import { chain, safeProp, map, reduce } from '../../../CommonFunctions/pointfreeUtilities';
import { addEntryToArray, safeNewArray } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface IPossibleCausesProps {
  selectedlanguage: string;
  possibleCauses: string[];
  possibleCausesData: IPossibleCausesEntry[];
  correctiveActionsData: ICorrectiveActionsEntry[];
  translation: (word: string) => string;
}

export class PossibleCauses extends Component<IPossibleCausesProps> {

  render() {
    const { selectedlanguage, possibleCauses, possibleCausesData, correctiveActionsData } = this.props;
    const { translation } = this.props;

    return (
      <React.Fragment>
        <div className='d-flex justify-content-between col-12 border-top border-bottom border-secondary'>
          <div className='font-weight-bold p-0'>{translation('Possible causes')}</div>
        </div>
        {this.getPossibleCauseEntry(selectedlanguage, possibleCauses, possibleCausesData, correctiveActionsData, translation)}
      </React.Fragment>
    );
  }

  private getPossibleCauseEntry = (selectedlanguage: string, possibleCauses: string[], possibleCausesData: IPossibleCausesEntry[], correctiveActionsData: ICorrectiveActionsEntry[], translation: (word: string) => string) => {
    const getPossibleCausesEntry = (x: any, index: number) => {
      const getDescription = compose(chain(safeProp('description')), compose(chain(safeProp(selectedlanguage)), safeProp('language')));
      return (
        <React.Fragment key={x.name}>
          <div className='col-12 border-bottom border-dark p-0 pb-2'>
            <div className='d-flex justify-content-between col-12 p-0'>
              <div className='col-12 p-0'>
                <div className='m-0 p-1 pl-0'>{`#${index + 1}: ${getDescription(x).getOrElse('')}`}</div>
                <CorrectiveActions selectedlanguage={selectedlanguage} correctiveActions={safeProp('correctiveActions', x).getOrElse([])} correctiveActionsData={correctiveActionsData} translation={translation} />
              </div>
            </div>
          </div>
        </React.Fragment>
      );
    }
    const getPossibleCausesArray = compose(map(reduce(addEntryToArray('name', possibleCausesData), [])), safeNewArray);
    const getPossibleCauses = compose(map(map(getPossibleCausesEntry)), getPossibleCausesArray);
    return getPossibleCauses(possibleCauses).matchWith({
      Just: (value: any) => value.getOrElse(),
      Nothing: () => <div className='col text-center'>{translation('No Entries Found')}</div>
    });
  }

}
