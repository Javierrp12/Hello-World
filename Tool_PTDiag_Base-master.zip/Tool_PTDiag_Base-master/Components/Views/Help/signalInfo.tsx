import React, { Component } from 'react';
import {
  IHelpSystemDataEntry, IPossibleCausesEntry, ICorrectiveActionsEntry
} from '../../../Datastore/InitialDataInterfaces';
import { chain, safeProp } from '../../../CommonFunctions/pointfreeUtilities';
import { PossibleCauses } from './possibleCauses';
import { languageSelection } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface ISignalInfoProps {
  activeSignal: IHelpSystemDataEntry;
  currentLanguage: string;
  activeList: string;
  possibleCauses: IPossibleCausesEntry[];
  correctiveActions: ICorrectiveActionsEntry[];
  t: (word: string) => string;
}

export class SignalInfo extends Component<ISignalInfoProps> {

  render() {
    const { activeSignal, currentLanguage, possibleCauses, correctiveActions } = this.props;
    const { t } = this.props;

    return (
      <div className='col border'>
        <div className='font-weight-bold ptdiag-color-text m-2' data-cy='signal-description-title'>{t('Description')}</div>
        <div className='container-fluid border-top overflow-auto' data-cy='signal-description'>
          <div className='row'>
            {this.displaySignalInfo(activeSignal, currentLanguage, possibleCauses, correctiveActions, t)}
          </div>
        </div>
      </div>
    );
  }

  private displaySignalInfo = (activeSignal: IHelpSystemDataEntry, currentLanguage: string, possibleCauses: IPossibleCausesEntry[], correctiveActions: ICorrectiveActionsEntry[], t: (word: string) => string) => {
    const checkSignalLanguage = compose(chain(safeProp(languageSelection(currentLanguage))), safeProp('language'));

    return checkSignalLanguage(activeSignal).matchWith({
      Just: (value: any) => {
        const data = value.getOrElse();
        return (
          <React.Fragment>
            <div className='font-weight-bold col-12 p-0'>{safeProp('title', data).getOrElse('')}</div>
            <div className='m-0 pb-2 p-0'>{safeProp('description', data).getOrElse('')}</div>
            {this.props.activeList !== 'analog' && 
            (<PossibleCauses
              selectedlanguage={currentLanguage}
              possibleCauses={safeProp('possibleCauses', activeSignal).getOrElse([])}
              possibleCausesData={possibleCauses}
              correctiveActionsData={correctiveActions}
              translation={t}
            />)
            }
          </React.Fragment>
        );
      },
      Nothing: () => <div className='col text-center'>{t('No Entries Found')}</div>
    });
  }
}
