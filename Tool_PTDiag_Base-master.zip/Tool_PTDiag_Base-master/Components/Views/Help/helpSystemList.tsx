import React from 'react';
import i18n from 'i18next';
import { IHelpSystemDataEntry, IPossibleCausesEntry, ICorrectiveActionsEntry } from '../../../Datastore/InitialDataInterfaces';
import { HelpListCategories } from '../../../Datastore/StateData/helpSystemListTypes';
import { SignalInfo } from './signalInfo';
import { map, filter, safeProp, chain, safeHead } from '../../../CommonFunctions/pointfreeUtilities'
import { safeNewArray, filterSignal } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface IHelpSystemProps {
  signalsData: IHelpSystemDataEntry[];
  possibleCauses: IPossibleCausesEntry[];
  correctiveActions: ICorrectiveActionsEntry[];
  activeList: string;
  activeSignal: string;
  i18n: typeof i18n;
  t: (word: string) => string;
  changeListCallback: (listData: string) => void;
  changeSignalCallback: (signalName: string) => void;
}

export class HelpSystemList extends React.Component<IHelpSystemProps> {

  render() {
    const { i18n, signalsData, activeList, activeSignal } = this.props;
    const { t, changeListCallback } = this.props;
    const currentLanguage = safeProp('language', i18n).getOrElse('en');

    if (signalsData.length === 0) {
      return <div>{t('No Entries Found')}</div>
    }

    return (
      <React.Fragment>
        <div className='m-2 font-weight-bold ptdiag-color-text text-right' data-cy='troubleshooting-text'>{t('Troubleshooting')}</div>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-3 border col-md-4'>
              <div className='font-weight-bold ptdiag-color-text m-2' data-cy='signal-text'>{t('Signal List')}</div>
              <div className='d-flex' data-cy='help-signal-buttons'>
                <button className={`btn btn-outline-ptdiag col ${(activeList === HelpListCategories.digital) ? 'active' : ''}`} onClick={() => changeListCallback(HelpListCategories.digital)}>{t('Digital')}</button>
                <button className={`btn btn-outline-ptdiag col ${(activeList === HelpListCategories.analog) ? 'active' : ''}`} onClick={() => changeListCallback(HelpListCategories.analog)}>{t('Analog')}</button>
              </div>
              <form>
                <div className="form-group mt-2">
                  <select className="form-control listSignalHelpSystem" size={15} value={activeSignal} onChange={(event) => this.props.changeSignalCallback(event.target.value!)} data-cy='signal-selector'>
                    {signalsData.map((item: IHelpSystemDataEntry) => (
                      <option key={`${item.module}_${item.name}`}>{`${item.module}_${item.name}`}</option>
                    ))}
                  </select>
                </div>
              </form>
            </div>
            <SignalInfo
              t={t}
              activeList={activeList}
              currentLanguage={currentLanguage}
              activeSignal={this.findActiveSignal(signalsData, activeSignal)}
              possibleCauses={this.props.possibleCauses}
              correctiveActions={this.props.correctiveActions}
            />
          </div>
        </div>
      </React.Fragment>
    );
  }

  private findActiveSignal = (signalsData: IHelpSystemDataEntry[], activeSignal: string): IHelpSystemDataEntry => {
    const getActiveSignal = compose(map(filter(filterSignal(activeSignal))), safeNewArray);
    const getFirstSignal = compose(chain(safeHead), getActiveSignal);
    return getFirstSignal(signalsData).getOrElse({});
  }

}
