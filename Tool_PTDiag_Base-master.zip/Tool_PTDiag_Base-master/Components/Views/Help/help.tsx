import React, { Component } from 'react';
import i18next from "i18next";
import { HelpSystemConnector } from '../../../ConnectingComponents/Help/helpSystemConnector';
import { HelpSystemList } from './helpSystemList';
import './help.css';

const ConnectorHelpSytem = HelpSystemConnector(HelpSystemList);

export class Help extends Component {

  render() {
    return (
      <React.Fragment>
        <div className='display-view-title' data-cy='view-title'>{i18next.t('Help Menu')}</div>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-2'>
              <button className='btn btn-block btn-ptdiag my-2'>{i18next.t('User Manual')}</button>
              <button className='btn btn-block btn-ptdiag my-2'>{i18next.t('Project Schematic')}</button>
            </div>
            <div className='col'>
              <ConnectorHelpSytem />
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}