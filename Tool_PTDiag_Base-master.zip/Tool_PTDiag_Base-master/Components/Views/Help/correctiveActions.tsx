import React, { Component } from 'react';
import { ICorrectiveActionsEntry } from '../../../Datastore/InitialDataInterfaces';
import { chain, safeProp, map, reduce } from '../../../CommonFunctions/pointfreeUtilities';
import { addEntryToArray, safeNewArray } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface ICorrectiveActionsProps {
  selectedlanguage: string;
  correctiveActions: string[];
  correctiveActionsData: ICorrectiveActionsEntry[];
  translation: (word: string) => string;
}

interface ICorrectiveActionsState {
  show: boolean;
}

export class CorrectiveActions extends Component<ICorrectiveActionsProps, ICorrectiveActionsState> {

  constructor(props: ICorrectiveActionsProps) {
    super(props);
    this.state = {
      show: false
    }
  }

  render() {
    const { selectedlanguage, correctiveActions, correctiveActionsData } = this.props;
    const { translation } = this.props;
    const { show } = this.state;

    return (
      <React.Fragment>
        <div className='d-flex justify-content-between bg-ptdiag-help col-12 text-white'>
          <div>{translation('Corrective actions')}</div>
          {show === false &&
            <button className='btn btn-light btn-sm' onClick={() => this.handleClickShow(show)}>
              <i className='fas fa-chevron-down'></i>
            </button>
          }
          {show === true &&
            <button className='btn btn-light btn-sm' onClick={() => this.handleClickShow(show)}>
              <i className='fas fa-chevron-up'></i>
            </button>
          }
        </div>
        {show === true &&
          this.displayCorrectiveActions(selectedlanguage, correctiveActions, correctiveActionsData, translation)
        }
      </React.Fragment>
    );
  }

  private handleClickShow = (show: boolean) => {
    this.setState({ show: !show })
  }

  private displayCorrectiveActions = (selectedlanguage: string, corectiveActions: string[], correctiveActionsData: ICorrectiveActionsEntry[], translation: (word: string) => string) => {
    const getPossibleCausesEntry = (x: any, index: number) => {
      const getDescription = compose(chain(safeProp('description')), compose(chain(safeProp(selectedlanguage)), safeProp('language')));
      const getStepEntry = (step: string, index: number) => <div key={step} className='col-12 m-0 p-1 pl-2 '>{`${index + 1}.-`} {step}</div>;
      const getSteps = compose(map(map(getStepEntry)), compose(chain(safeProp('steps')), compose(chain(safeProp(selectedlanguage)), safeProp('language'))));
      return (
        <React.Fragment key={x.name}>
          <div className='col-12 m-0 p-1 pl-2'>
            <span className='font-weight-bold'>{`${translation('Corrective action')} ${index + 1}: `}</span>
            {getDescription(x).getOrElse('')}
          </div>
          {getSteps(x).getOrElse([])}
        </React.Fragment>
      );
    }

    const getCorretiveActionsArray = compose(map(reduce(addEntryToArray('name', correctiveActionsData), [])), safeNewArray);
    const getCorretiveActions = compose(map(map(getPossibleCausesEntry)), getCorretiveActionsArray);
    return getCorretiveActions(corectiveActions).matchWith({
      Just: (value: any) => value.getOrElse(),
      Nothing: () => <div className='col text-center'>{translation('No Entries Found')}</div>
    });
  }

}
