import React, { Component } from 'react';
import { ICounter } from '../../../Datastore/InitialDataInterfaces';
import { ICounterUpdateData } from '../../../ConnectingComponents/SystemCounters/systemCountersConnector';
import { CounterList } from './counterList';

interface SystemCountersProps {
  countersData: ICounter[];
  accessLevel: string;
  userlevel: string;
  t: (word: string) => string;
  updateCounterCallback: (data: ICounterUpdateData) => void;
}

export class SystemCounters extends Component<SystemCountersProps> {

  render() {
    const { countersData, accessLevel, userlevel } = this.props;
    const { t, updateCounterCallback } = this.props;
    return (
      <React.Fragment>
        <div className='display-view-title' data-cy='view-title'>{t('System Counters')}</div>
        <div className='m-2'>
          <table className='table table-hover table-fixHead display-view-table mt-2'>
            <thead>
              <tr>
                <th scope='col'>{t('Counter')}</th>
                <th scope='col'>{t('Value')}</th>
                <th scope='col'></th>
                <th scope='col'>{t('Unit')}</th>
              </tr>
            </thead>
            <tbody data-cy='systemcounters-table'>
                <CounterList countersData={countersData} accessLevel={accessLevel} userlevel={userlevel} translation={t} updateCounterCallback={updateCounterCallback} />
            </tbody>
          </table>
        </div>
      </React.Fragment>
    )
  }
}