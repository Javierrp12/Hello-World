import React, { Component, ChangeEvent } from 'react';
import { ICounter } from '../../../Datastore/InitialDataInterfaces';
import { ICounterUpdateData } from '../../../ConnectingComponents/SystemCounters/systemCountersConnector';
import { safeProp, eq } from '../../../CommonFunctions/pointfreeUtilities';
import { checkValue, filterPerUserLevel } from '../../../CommonFunctions/functionsSupport';

interface ICounterEntryProps {
  counterData: ICounter;
  accessLevel: string;
  userlevel: string;
  translation: (word: string) => string;
  updateCounterCallback: (data: ICounterUpdateData) => void;
}

interface ICounterEntryState {
  value: string;
  validValue: string;
}

export class CounterEntry extends Component<ICounterEntryProps, ICounterEntryState> {
  constructor(props: ICounterEntryProps) {
    super(props);
    this.state = {
      value: '',
      validValue: 'disabled'
    }
  }

  render() {
    const { translation, updateCounterCallback } = this.props;
    const { counterData, userlevel, accessLevel } = this.props;
    const { value, validValue } = this.state;
    const counterDisabled = filterPerUserLevel(userlevel, accessLevel);

    return (
      <React.Fragment>
        <tr>
          <td className='boldItem'>{counterData.name}</td>
          <td>
            <form onSubmit={this.handleSubmit}>
              <div className='form-group'>
                <input className={`form-control-sm ${eq(validValue, 'disabled') ? 'invalidEntry' : ''}`} disabled={!counterDisabled} type="text" placeholder={counterData.value.toString()} value={value} onChange={this.handleValueChanged} />
              </div>
            </form>
          </td>
          <td>
            {counterDisabled &&
              <React.Fragment>
                <button className={`btn btn-outline-dark btn-sm mr-2 ${validValue} ${validValue}_button`} onClick={() => this.handleClick(validValue, counterData, value, updateCounterCallback)}>{translation('Apply')} </button>
              </React.Fragment>
            }
          </td>
          <td>{counterData.unit}</td>
        </tr>
      </React.Fragment>
    );
  }

  private handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
  }

  private handleValueChanged = (event: ChangeEvent<HTMLInputElement>) => {
    this.setState({ value: event.currentTarget.value, validValue: checkValue(event.currentTarget.value).getOrElse('') });
  }

  private handleClick = (validValue: string, entryData: ICounter, value: string, changeParameterCallback: (data: ICounterUpdateData) => void) => {
    if (eq(validValue, '')) {
      changeParameterCallback({ counter: safeProp('name', entryData).getOrElse(''), value });
      this.setState({ value: '', validValue: 'disabled' });
    }
  }
}

