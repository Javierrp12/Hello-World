import React, { Component } from 'react';
import { ICounter } from '../../../Datastore/InitialDataInterfaces';
import { ICounterUpdateData } from '../../../ConnectingComponents/SystemCounters/systemCountersConnector';
import { CounterEntry } from './counterEntry';

interface ICountersListProps {
  countersData: ICounter[];
  accessLevel: string;
  userlevel: string;
  translation: (word: string) => string;
  updateCounterCallback: (data: ICounterUpdateData) => void;
}

export class CounterList extends Component<ICountersListProps> {

  render() {
    const { translation, updateCounterCallback } = this.props;
    const { countersData, userlevel, accessLevel } = this.props;

    if (countersData.length === 0) {
      return <tr><td className='text-center font-weight-bold' colSpan={4}>{translation('No Entries Found')}</td></tr>;
    }

    return (
      <React.Fragment>
        {countersData.map((counter, index) =>
          <CounterEntry
            key={`${index}_${counter.name}`}
            counterData={counter}
            accessLevel ={accessLevel}
            userlevel={userlevel}
            translation={translation}
            updateCounterCallback={updateCounterCallback} />)}
      </React.Fragment>
    );
  }
}
