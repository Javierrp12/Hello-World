import React from 'react';
import { ModalWindow } from '../modalWindow';
import { PTService } from '../../../Datastore/StateData/userLevelTypes';
import { filterPerUserLevel } from '../../../CommonFunctions/functionsSupport';

interface IModalMenuProps {
  userlevel: string;
  signalName: string;
  translation: (word: string) => string;
  handleShowMenuClick: () => void;
  signalDescriptionCallback: () => void;
  handleShowModifyClick: () => void;
}

export class ModalMenu extends React.Component<IModalMenuProps> {

  render() {
    const { userlevel, signalName } = this.props;
    const { translation, handleShowMenuClick, signalDescriptionCallback, handleShowModifyClick } = this.props;

    return (
      <ModalWindow>
        <div className='modal-ptdiag'>
          <div className='modal-dialog modal-dialog-centered'>
            <div className='modal-content'>
              <div className='modal-header'>
                <div className='modal-title h5' data-cy='signal-menu-title'>{`${translation('Signal Menu')} - `}<span className='display-view-subsubtitel text-truncate'>{signalName}</span></div>
                <button className='close' onClick={handleShowMenuClick}><span>x</span></button>
              </div>
              <div className='modal-body'>
                <div className='d-flex align-items-center flex-column bd-highlight mb-3'>
                  <button className='btn btn-ptdiag my-2 col-6' onClick={signalDescriptionCallback} data-cy='signal-menu-description'>{translation('Signal Description')}</button>
                  {filterPerUserLevel(userlevel, PTService) &&
                    <button className='btn btn-ptdiag my-2 col-6' onClick={handleShowModifyClick} data-cy='signal-menu-modify'>{translation('Modify')}</button>
                  }
                </div>
              </div>
              <div className='modal-footer'>
                <button className='btn btn-secondary' onClick={handleShowMenuClick} data-cy='signal-menu-close'>{translation('Close')}</button>
              </div>
            </div>
          </div>
        </div>
      </ModalWindow>
    );
  }
}