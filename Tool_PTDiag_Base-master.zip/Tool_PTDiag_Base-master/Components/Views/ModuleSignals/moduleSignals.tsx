import React from 'react';
import { IAnalog, IDigital } from '../../../Datastore/InitialDataInterfaces';
import { PTService } from '../../../Datastore/StateData/userLevelTypes';
import { ModulesTabConnector } from '../../../ConnectingComponents/TabModules/modulesTabConnector';
import { ModulesTab } from '../../ModulesTab/modulesTab';
import { DigitalSignals } from '../ModuleSignals/digitalSignals';
import { AnalogSignals } from '../ModuleSignals/analogSignals';
import { ModalMenu } from './modalMenu';
import { ModifySignalConnector } from '../../../ConnectingComponents/ModifySignals/modifySignalConnector';
import { ModifySignal } from '../ModifySignal/modifySignal';
import { filterPerUserLevel } from '../../../CommonFunctions/functionsSupport';
import './moduleSignals.css';

export interface IDataModify {
  name: string;
  type: string;
  datastore: string;
  category: string;
}

interface IModuleSignalsProps {
  analogData: IAnalog[];
  digitalData: IDigital[];
  showOnlyActiveSignals: boolean;
  forceInfo: any;
  userlevel: string;
  selectedItem: string;
  showInactiveSignalsCallback: () => {};
  signalDescriptionCallback: () => void;
  modifyCallback: (modifyData: IDataModify) => void;
  updateForceInfo: () => void;
  t: (word: string) => string;
}

interface IModuleSignalsState {
  showModalMenu: boolean;
  showModalModify: boolean;
}

const ConnectorModulesTab = ModulesTabConnector(ModulesTab);
const ConnectorModifySignal = ModifySignalConnector(ModifySignal);

export class ModuleSignals extends React.Component<IModuleSignalsProps, IModuleSignalsState> {
  constructor(props: IModuleSignalsProps) {
    super(props);
    this.state = {
      showModalMenu: false,
      showModalModify: false
    }
  }

  render() {
    const { analogData, digitalData, showOnlyActiveSignals, forceInfo, userlevel, selectedItem } = this.props;
    const { t, showInactiveSignalsCallback, signalDescriptionCallback, modifyCallback } = this.props;
    const { showModalMenu, showModalModify } = this.state;

    return (
      <React.Fragment>
        {showModalMenu === true &&
          <ModalMenu
            userlevel={userlevel}
            signalName={selectedItem}
            translation={t}
            handleShowMenuClick={() => this.handleCloseMenuClick(showModalMenu)}
            handleShowModifyClick={() => this.handleModifyClick(showModalMenu, showModalModify)}
            signalDescriptionCallback={signalDescriptionCallback}
          />
        }
        {showModalModify === true &&
          <ConnectorModifySignal handleShowModifyMenu={() => this.handleShowModifyMenu(showModalModify)} />
        }
        <div className='display-view-title' data-cy='view-title'>{t('Module Signals')}</div>
        <div className='text-right'><ConnectorModulesTab /></div>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-12 col-xl-8'>
              <DigitalSignals
                digitalData={digitalData}
                showOnlyActiveSignals={showOnlyActiveSignals}
                showInactiveSignalsCallback={showInactiveSignalsCallback}
                handleShowMenuClick={(data) => this.handleShowMenuClick(data, showModalMenu, modifyCallback)}
                forceInfo={forceInfo}
                translation={t}
              />
            </div>
            <div className='col-xl-4'>
              <AnalogSignals
                analogData={analogData}
                forceInfo={forceInfo}
                handleShowMenuClick={(data) => this.handleShowMenuClick(data, showModalMenu, modifyCallback)}
                translation={t}
              />
            </div>
          </div>
        </div>
        {filterPerUserLevel(userlevel, PTService) &&
          <div className='container-fluid'>
            <div className='row'>
              <div className='d-flex flex-column p-3 col-3 col-sm-6 col-md-4 col-lg-3 col-xl-2'>
                <div>{t('Flags')}:</div>
                <div className='forcedFlag rounded-pill'>{t('Digital Signal Forced')}</div>
                <div className='pl-5 icon-analog-legend'><span>{t('Analog Signal Forced')}</span></div>
              </div>
            </div>
          </div>
        }
      </React.Fragment>
    );
  }

  componentDidMount() {
    this.props.updateForceInfo();
  }

  private handleShowMenuClick = (data: IDataModify, showModalMenu: boolean, modifyCallback: (modifyData: IDataModify) => void): void => {
    if (showModalMenu === false) {
      modifyCallback(data);
    }
    this.setState({ showModalMenu: !showModalMenu });
  }

  private handleCloseMenuClick = (showModalMenu: Boolean): void => {
    this.setState({ showModalMenu: !showModalMenu });
  }

  private handleModifyClick = (showModalMenu: Boolean, showModalModify: boolean): void => {
    this.setState({ showModalMenu: !showModalMenu }, () => this.handleShowModifyMenu(showModalModify));
  }

  private handleShowModifyMenu = (showModalModify: boolean): void => {
    this.setState({ showModalModify: !showModalModify })
  }

}
