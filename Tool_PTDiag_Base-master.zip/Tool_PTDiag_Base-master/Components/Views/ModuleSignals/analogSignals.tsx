import React, { ChangeEvent } from 'react';
import { IAnalog } from '../../../Datastore/InitialDataInterfaces';
import { IDataModify } from '../ModuleSignals/moduleSignals';
import { map, filter, chain } from '../../../CommonFunctions/pointfreeUtilities';
import { safeNewArray, filterSearchStringSignal, getForceFlag } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface IAnalogSignalsProps {
  analogData: IAnalog[];
  forceInfo: any;
  translation: (word: string) => string;
  handleShowMenuClick: (data: IDataModify) => void;
}

interface IAnalogSignalsState {
  search: string;
}

export class AnalogSignals extends React.Component<IAnalogSignalsProps, IAnalogSignalsState> {
  constructor(props: IAnalogSignalsProps) {
    super(props);
    this.state = {
      search: ''
    }
  }

  render() {
    const { analogData, forceInfo } = this.props;
    const { translation, handleShowMenuClick } = this.props;
    const { search } = this.state;

    return (
      <React.Fragment>
        <div className="d-flex justify-content-between mt-4">
          <div className='display-view-subtitle' data-cy='view-subtitle-analog'>{translation('Analog Signals')}</div>
          <div className="form-group">
            <input type="search" className="form-control" placeholder={`${translation('Search')}...`} id="search-input" aria-describedby="search" name='search' value={search} onChange={(event) => this.handleSearchChanged(event)} data-cy='analog-search' />
          </div>
        </div>
        <table className='table table-hover table-fixHead display-view-table mt-2'>
          <thead>
            <tr>
              <th scope='col'></th>
              <th scope='col'>{translation('Signal')}</th>
              <th scope='col'>{translation('Value')}</th>
              <th scope='col'>{translation('Unit')}</th>
            </tr>
          </thead>
          <tbody data-cy='analog-signals-table'>
            {this.analogList(analogData, forceInfo, search, translation, handleShowMenuClick)}
          </tbody>
        </table>
      </React.Fragment>
    );
  }

  private handleSearchChanged = (event: ChangeEvent<HTMLInputElement>) => {
    this.setState({ search: event.target.value })
  }

  private analogList = (analogData: IAnalog[], forceInfo: any, search: string, translation: (word: string) => string, handleShowMenuClick: (data: IDataModify) => void) => {
    const generateAnalogEntry = (x: IAnalog) => {
      const qFormatFactor = 2.5;
      return (
        <tr key={x.name}>
          <td className={getForceFlag('forcedValue', x, forceInfo)}></td>
          <td>
            <button
              className='btn btn-outline-light text-dark border-0'
              onClick={() => handleShowMenuClick({ name: x.name, type: 'analog', datastore: x.datastore, category: x.category })}>
              {x.name}
            </button>
          </td>
          <td>{x.value.toFixed(Math.floor(x.qFormat / qFormatFactor))}</td>
          <td>{x.unit}</td>
        </tr>
      )
    }
    const getAnalogValues = compose(map(filter(filterSearchStringSignal(search, 'name'))), safeNewArray);
    return getAnalogValues(analogData).matchWith({
      Just: (value: any) => chain(map(generateAnalogEntry), value),
      Nothing: () =>
        <tr>
          <td colSpan={5} className='text-center'>{translation('No Entries Found')}</td>
        </tr>
    });
  }

}