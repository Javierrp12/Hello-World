import React, { Component } from 'react';

interface ILegendProps {
  translation: (word: string) => string;
}

export class Legend extends Component<ILegendProps> {

  render() {
    const { translation } = this.props;
    return (
      <div className='container-fluid'>
        <div className='row'>
          <div className='d-flex flex-column p-3 col' data-cy='digital-legend'>
            <div>{translation('Severity')}:</div>
            <div className='col'><span className='square bg-Major ml-0 mr-1' /><span>{translation('Error Major')}</span></div>
            <div className='col'><span className='square bg-Minor ml-0 mr-1' /><span>{translation('Error Minor')}</span></div>
            <div className='col'><span className='square bg-Warning ml-0 mr-1' /><span>{translation('Warning')}</span></div>
            <div className='col'><span className='square bg-Info ml-0 mr-1' /><span>{translation('Info')}</span></div>
            <div className='col'><span className='square bg-None ml-0 mr-1' /><span>{translation('None')}</span></div>
          </div>
        </div>
      </div>
    );
  }
}