import React, { ChangeEvent } from 'react';
import { IDigital } from '../../../Datastore/InitialDataInterfaces';
import { IDataModify } from '../ModuleSignals/moduleSignals';
import { Legend } from './Legend/legend';
import { map, filter, chain } from '../../../CommonFunctions/pointfreeUtilities';
import { safeNewArray, filterSearchStringSignal, getForceFlag, filterActiveSignalIfActive } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface IDigitalSignalsProps {
  digitalData: IDigital[];
  forceInfo: any;
  showOnlyActiveSignals: boolean;
  translation: (word: string) => string;
  showInactiveSignalsCallback: () => {};
  handleShowMenuClick: (data: IDataModify) => void;
}

interface IDigitalSignalsState {
  search: string;
}

export class DigitalSignals extends React.Component<IDigitalSignalsProps, IDigitalSignalsState> {
  constructor(props: IDigitalSignalsProps) {
    super(props);
    this.state = {
      search: ''
    }
  }

  render() {
    const { digitalData, forceInfo, showOnlyActiveSignals } = this.props;
    const { translation, showInactiveSignalsCallback, handleShowMenuClick } = this.props;
    const { search } = this.state;

    return (
      <React.Fragment>
        <div className="form-group form-check">
          <input type="checkbox" className="form-check-input" id="hide-inactive-signals" checked={showOnlyActiveSignals} onChange={showInactiveSignalsCallback} data-cy='inactive-signals-checkbox' />
          <label className="form-check-label" htmlFor="hide-inactive-signals">{translation('Hide Inactive Digital Signals')}</label>
        </div>
        <div className="d-flex justify-content-between">
          <div className='display-view-subtitle' data-cy='view-subtitle-digital'>{translation('Digital Signals')}</div>
          <div className="form-group">
            <input type="search" className="form-control" placeholder={`${translation('Search')}...`} id="search-input" aria-describedby="search" name='search' value={search} onChange={(event) => this.handleSearchChanged(event)} data-cy='digital-search' />
          </div>
        </div>
        <table className='table table-hover table-fixHead display-view-table mt-2'>
          <thead>
            <tr>
              <th scope='col' className='text-center'>{translation('Signals')}</th>
            </tr>
          </thead>
        </table>
        <div className='container-fluid'>
          <div className='row' data-cy='digital-signals-table'>
            {this.digitalList(digitalData, forceInfo, showOnlyActiveSignals, search, translation, handleShowMenuClick)}
          </div>
        </div>
        <Legend translation={translation} />
      </React.Fragment >
    );
  }

  private handleSearchChanged = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ search: event.target.value })
  }

  private digitalList = (digitalData: IDigital[], forceInfo: any, showOnlyActiveSignals: boolean, search: string, translation: (word: string) => string, handleShowMenuClick: (data: IDataModify) => void) => {
    const generateDigitalEntry = (x: IDigital, index: number) => {
      return (
        <div key={`${x.name}_${index}`} className='col-12 col-sm-12 col-md-6 col-lg-4 col-xl-3 p-1'>
          <button
            className={`btn btn-outline-primary digital-signal-hover rounded-pill text-truncate col ${(x.status === true) ? `bg-${x.severity}` : ''} ${getForceFlag('forcedFlag', x, forceInfo)}`}
            onClick={() => handleShowMenuClick({ name: x.name, type: 'digital', datastore: x.datastore, category: x.category })}>
            {x.name}
          </button>
        </div>
      )
    }
    const filterSignals = compose(map(filter(filterSearchStringSignal(search, 'name'))), map(filter(filterActiveSignalIfActive(showOnlyActiveSignals, 'status'))));
    const getDigitalFlags = compose(filterSignals, safeNewArray);
    return getDigitalFlags(digitalData).matchWith({
      Just: (value: any) => chain(map(generateDigitalEntry), value),
      Nothing: () =>
        <div className='col text-center'>{translation('No Entries Found')}</div>
    });
  }

}