import React from 'react';
import { ModalWindow } from '../modalWindow';
import { maybeA } from '../../../CommonFunctions/functionsSupport';

interface IAboutModalProps {
  ptdiagVersion: string;
  year: string;
  translation: (word: string) => string;
  handleShowAbout: () => void;
}

export class AboutModal extends React.Component<IAboutModalProps> {
  render() {
    const { year, ptdiagVersion } = this.props;
    const { translation } = this.props;
    const { handleShowAbout } = this.props;

    return (
      <ModalWindow>
        <div className='modal-ptdiag'>
          <div className='modal-dialog modal-dialog-centered'>
            <div className='modal-content'>
              <div className='modal-header'>
                <div className='display-view-title' data-cy='modal-title'>{translation('About PTDiag')}</div>
                <button className='close' onClick={handleShowAbout}><span>x</span></button>
              </div>
              <div className='modal-body' data-cy='modal-content'>
                <div className='display-view-subtitle text-center'>
                  <div>PTDiag Version {maybeA(ptdiagVersion).getOrElse('N/A')}</div>
                  <div>Copyright © {maybeA(year).getOrElse('N/A')} PowerTech Converter GmbH</div>
                  <div>All rights reserved.</div>
                </div>
              </div>
              <div className='modal-footer' data-cy='modal-buttons'>
                <button className='btn btn-secondary m-2' onClick={handleShowAbout}>{translation('Close')}</button>
              </div>
            </div>
          </div>
        </div>
      </ModalWindow >
    );
  }
}