import React from 'react';
import { IRUS } from '../../../Datastore/InitialDataInterfaces';
import { map, safeProp, head } from '../../../CommonFunctions/pointfreeUtilities';
import { getKeyObject } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');
const curry = require('folktale/core/lambda/curry');

interface IDeviceInformationRUProps {
  ruInfo: IRUS[];
  translation: (word: string) => string;
}

export class DeviceInformationRU extends React.Component<IDeviceInformationRUProps> {

  render() {
    const { ruInfo } = this.props;
    const { translation } = this.props;

    return (
      ruInfo.map(item => {
        const getVersion = curry(1, (x: any) => {
          return (
            <React.Fragment key={head(getKeyObject(x))}>
              <div className='col-6 border text-truncate'>{head(getKeyObject(x))}</div>
              <div className='col-6 border text-truncate'>{x[head(getKeyObject(x))]}</div>
            </React.Fragment>
          );
        });
        const getSWVersion = compose(map(map(getVersion)), safeProp('SWversions'));

        return (
          <div key={safeProp('name', item).getOrElse('N/A')} className='col-6'>
            <div className='ptdiag-color-text text-uppercase font-weight-bold m-2'>{safeProp('name', item).getOrElse('N/A')}</div>
            <div className='container-fluid'>
              <div className='row'>
                <div className='col-6 ptdiag-color-text font-weight-bold border'>{translation('')}</div>
                <div className='col-6 ptdiag-color-text font-weight-bold border'>{translation('SW Version')}</div>
                {getSWVersion(item).getOrElse(null)}
              </div>
            </div>
          </div>
        );
      })
    );
  }
}
