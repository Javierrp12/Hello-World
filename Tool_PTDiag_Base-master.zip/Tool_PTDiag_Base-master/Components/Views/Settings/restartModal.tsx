import React, { ChangeEvent } from 'react';
import { ModalWindow } from '../modalWindow';
import { IOption } from '../../../ConnectingComponents/Settings/restartModalConnector';
import { getFirstValueOption } from '../../../CommonFunctions/functionsSupport';

interface IRestartModalProps {
  options: IOption[];
  userlevel: string;
  t: (word: string) => string;
  restartCallback: (option: string) => void;
  handledShowRestart: () => void;
}

interface IRestartModalState {
  option: string;
}

export class RestartModal extends React.Component<IRestartModalProps, IRestartModalState> {
  constructor(props: IRestartModalProps) {
    super(props);
    this.state = {
      option: getFirstValueOption(this.props.options).getOrElse('')
    }
  }

  render() {
    const { t, handledShowRestart, restartCallback } = this.props;
    const { options } = this.props;
    const { option } = this.state;

    return (
      <ModalWindow>
        <div className='modal-ptdiag'>
          <div className='modal-dialog modal-dialog-centered'>
            <div className='modal-content'>
              <div className='modal-header'>
                <div className='display-view-title' data-cy='modal-title'>{t('Restart')}</div>
                <button className='close' onClick={handledShowRestart}><span>x</span></button>
              </div>
              <div className='modal-body' data-cy='modal-content'>
                <div className="form-group">
                  <label htmlFor='formControlRestartOptions'>{t('Restart Options')}</label>
                  <select className='form-control' id='formControlRestartOptions' value={option} onChange={this.handleChange}>
                    {options.map((option: IOption) => <option key={option.option} value={option.value}>{option.option}</option>)}
                  </select>
                </div>
              </div>
              <div className='modal-footer' data-cy='modal-buttons'>
                <button className='btn btn-secondary m-2' onClick={handledShowRestart}>{t('Close')}</button>
                <button className='btn btn-ptdiag' onClick={() => this.handledRestart(option, restartCallback, handledShowRestart)}>{t('Restart')}</button>
              </div>
            </div>
          </div>
        </div>
      </ModalWindow >
    );
  }

  private handledRestart = (option: string, restartCallback: (option: string) => void, handledShowRestart: () => void): void => {
    restartCallback(option);
    handledShowRestart();
  }

  private handleChange = (event: ChangeEvent<HTMLSelectElement>): void => {
    this.setState({ option: event.currentTarget.value });
  }

}