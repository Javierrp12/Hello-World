import React, { ChangeEvent } from 'react';
import { ModalWindow } from '../modalWindow';
import { IDateTime } from '../../../Datastore/StateData/stateActionCreator';
import { prependZero } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface ISetDateTimeProps {
  t: (word: string) => string;
  handleShowDateTime: () => void;
  setDateTimeCallback: (datetime: IDateTime) => void;
}

interface ISetDateTimeState {
  date: string;
  time: string;
}

export class SetDateTime extends React.Component<ISetDateTimeProps, ISetDateTimeState> {
  constructor(props: ISetDateTimeProps) {
    super(props);
    this.state = {
      date: '',
      time: ''
    }
  }

  render() {
    const { t, handleShowDateTime, setDateTimeCallback } = this.props;

    const serializeClockTime = (date: Date) => ({ hours: date.getUTCHours(), minutes: date.getUTCMinutes() });
    const formatClock = (format: string) => (time: any) => format.replace('hh', time.hours).replace('mm', time.minutes);
    const getCurrentDate = compose(formatClock('hh:mm'), compose(compose(prependZero('hours'), prependZero('minutes')), serializeClockTime));

    return (
      <ModalWindow>
        <div className='modal-ptdiag'>
          <div className='modal-dialog modal-dialog-centered'>
            <div className='modal-content'>
              <div className='modal-header'>
                <div className='display-view-title' data-cy='modal-title'>{t('Date Time')}</div>
                <button className='close' onClick={handleShowDateTime}><span>x</span></button>
              </div>
              <div className='modal-body' data-cy='modal-content'>
                <form onSubmit={(event) => this.handleSubmit(event, this.state, handleShowDateTime, setDateTimeCallback)}>
                  <div className="form-group">
                    <label htmlFor="dateFormControlInput">{t('Date')}</label>
                    <input type="date" className="form-control" id="dateFormControlInput" name='date' onChange={this.handleDateValueChanged} required />
                  </div>
                  <div className="form-group">
                    <label htmlFor="timeFormControlInput">{t('Time')} (UTC)</label>
                    <input type="time" className="form-control" id="timeFormControlInput" name='time' list="utcoptiontime" onChange={this.handleTimeValueChanged} required />
                    <datalist id='utcoptiontime'>
                      <option value={getCurrentDate(new Date())} />
                    </datalist>
                  </div>
                  <div className='text-center'>
                    <button type='submit' className='btn btn-ptdiag'>{t('Set Date/Time')}</button>
                  </div>
                </form>
              </div>
              <div className='modal-footer' data-cy='modal-buttons'>
                <button className='btn btn-secondary m-2' onClick={handleShowDateTime}>{t('Close')}</button>
              </div>
            </div>
          </div>
        </div>
      </ModalWindow>
    );
  }

  handleSubmit = (event: React.FormEvent<HTMLFormElement>, state: ISetDateTimeState, handleShowDateTime: () => void, setDateTimeCallback: (datetime: IDateTime) => void): void => {
    event.preventDefault();
    setDateTimeCallback({ date: state.date, time: `${state.time}:00` });
    handleShowDateTime();
  }

  private handleDateValueChanged = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ date: event.target.value });
  }

  private handleTimeValueChanged = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ time: event.target.value });
  }

}
