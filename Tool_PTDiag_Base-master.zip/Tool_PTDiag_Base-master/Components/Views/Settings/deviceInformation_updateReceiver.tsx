import React from 'react';
import { ISytemInfo, IAppInfo } from '../../../Datastore/InitialDataInterfaces';
import { MU } from '../../../Datastore/ModelData/modulesTypes';
import { eq } from '../../../CommonFunctions/pointfreeUtilities';
import { checkAppData, checkSystemData, maybeA, printWindow, safeObjectSearch } from '../../../CommonFunctions/functionsSupport';

interface IDeviceInformationProps {
  appInfo: IAppInfo;
  systemInfo: ISytemInfo;
  ptdiagVersion: string;
  translation: (word: string) => string;
}

export class DeviceInformation extends React.Component<IDeviceInformationProps> {

  render() {
    const { appInfo, systemInfo, ptdiagVersion } = this.props;
    const { translation } = this.props;

    if ((eq(checkAppData(appInfo), false)) || (eq(checkSystemData(systemInfo), false))) {
      return (
        <React.Fragment>
          <div className='display-view-subtitle border-bottom'>{translation('Device Information')}</div>
          <div className='display-view-subtitle'>{`No Information available. Please click on "${translation('Refresh Device Information')}"`}</div>
        </React.Fragment>
      );
    }

    return (
      <React.Fragment>
        <div className='d-flex justify-content-start border-bottom'>
          <div className='display-view-subtitle mr-2' data-cy='settings-device-info'>{translation('Device Information')}</div>
          <button className='btn btn-sm btn-outline-secondary' onClick={() => maybeA(window).map(printWindow)}><i className="fas fa-print fa-lg"></i></button>
        </div>
        <div className='container-fluid m-2' data-cy='settings-units-data'>
          <div className='row'>
            <div className='col' data-cy='settings-project-info'>
              <div className='h5 ptdiag-color-text'>{translation('Project')}: {safeObjectSearch('project.name', appInfo).getOrElse('N/A')}</div>
              <div className='h5 ptdiag-color-text'>{translation('Firmware Package')}: {safeObjectSearch('project.packageName', appInfo).getOrElse('N/A')}</div>
            </div>
          </div>
          <div className='row'>
            <div className='col'>
              <div className='ptdiag-color-text text-uppercase font-weight-bold m-2'>{MU}</div>
              <div className='container-fluid'>
                <div className='row'>
                  <div className='col-6 ptdiag-color-text font-weight-bold border'></div>
                  <div className='col-6 ptdiag-color-text font-weight-bold border'>{translation('SW Version')}</div>
                  <div className='col-6 border'>{translation('Bootloader')}</div>
                  <div className='col-6 border'>{safeObjectSearch('update_receiver', systemInfo).getOrElse('N/A')}</div>
                  <div className='col-6 border'>{translation('OS')}</div>
                  <div className='col-6 border'>{safeObjectSearch('os_version', systemInfo).getOrElse('N/A')}</div>
                  <div className='col-6 border'>{translation('App')}</div>
                  <div className='col-6 border'>{safeObjectSearch('project.version', appInfo).getOrElse('N/A')}</div>
                </div>
              </div>
              <div className='ptdiag-color-text text-uppercase font-weight-bold m-2'>PTDiag</div>
              <div className='container-fluid'>
                <div className='row'>
                  <div className='col-6 ptdiag-color-text font-weight-bold border'></div>
                  <div className='col-6 ptdiag-color-text font-weight-bold border'>{translation('SW Version')}</div>
                  <div className='col-6 border'>{translation('Version')}</div>
                  <div className='col-6 border'>{maybeA(ptdiagVersion).getOrElse('N/A')}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}