import React from 'react';
import { ISytemInfo, IAppInfo } from '../../../Datastore/InitialDataInterfaces';
import { DeviceInformation } from './deviceInformation';
import { AboutModal } from './aboutModal';
import { eq } from '../../../CommonFunctions/pointfreeUtilities';


interface ISettingsProps {
  systemInfo: ISytemInfo;
  appInfo: IAppInfo;
  userlevel: string;
  ptdiagVersion: string;
  year: string;
  t: (word: string) => string;
}

interface ISettingsState {
  showModalAbout: boolean;
}

export class Settings extends React.Component<ISettingsProps, ISettingsState> {
  constructor(props: ISettingsProps) {
    super(props);
    this.state = {
      showModalAbout: false
    }
  }

  render() {
    const { t } = this.props;
    const { appInfo, systemInfo, ptdiagVersion, year } = this.props;
    const { showModalAbout } = this.state;

    return (
      <React.Fragment>
        {eq(showModalAbout, true) &&
          <AboutModal
            handleShowAbout={() => this.handleShowAbout(showModalAbout)}
            ptdiagVersion={ptdiagVersion}
            year={year}
            translation={t}
          />
        }
        <div className='display-view-title' data-cy='view-title'>{t('Settings')}</div>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-2' data-cy='settings-menu-buttons'>
              <button className='btn btn-block btn-ptdiag my-2' onClick={() => this.handleShowAbout(showModalAbout)}>{t('About PTDiag')}</button>
            </div>
            <div className='col'>
              <DeviceInformation
                systemInfo={systemInfo}
                appInfo={appInfo}
                ptdiagVersion={ptdiagVersion}
                translation={t}
              />
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }

  private handleShowAbout = (showModalAbout: boolean) => {
    this.setState({ showModalAbout: !showModalAbout })
  }

}
