import React from 'react';
import { ISytemInfo, IAppInfo } from '../../../Datastore/InitialDataInterfaces';
import { DeviceInformation } from './deviceInformation';
import { RestartModalConnector } from '../../../ConnectingComponents/Settings/restartModalConnector';
import { SetDateTimeModalConnector } from '../../../ConnectingComponents/Settings/setDateTimeModalConnector';
import { filterPerUserLevel } from '../../../CommonFunctions/functionsSupport';
import { Service } from '../../../Datastore/StateData/userLevelTypes';
import { RestartModal } from './restartModal';
import { SetDateTime } from './setDateTime';
import { AboutModal } from './aboutModal';
import { eq } from '../../../CommonFunctions/pointfreeUtilities';

const ConnectorRestartModal = RestartModalConnector(RestartModal);
const ConnectorSetDateTimeModal = SetDateTimeModalConnector(SetDateTime);

interface ISettingsProps {
  systemInfo: ISytemInfo;
  appInfo: IAppInfo;
  userlevel: string;
  ptdiagVersion: string;
  year: string;
  t: (word: string) => string;
  getDeviceInformation: () => void;
}

interface ISettingsState {
  showModalRestart: boolean;
  showModalDateTime: boolean;
  showModalAbout: boolean;
}

export class Settings extends React.Component<ISettingsProps, ISettingsState> {
  constructor(props: ISettingsProps) {
    super(props);
    this.state = {
      showModalRestart: false,
      showModalDateTime: false,
      showModalAbout: false,
    }
  }

  render() {
    const { t, getDeviceInformation } = this.props;
    const { appInfo, systemInfo, ptdiagVersion, year, userlevel } = this.props;
    const { showModalRestart, showModalDateTime, showModalAbout } = this.state;

    return (
      <React.Fragment>
        {eq(showModalRestart, true) &&
          <ConnectorRestartModal handledShowRestart={() => this.handleShowRestart(showModalRestart)} />
        }
        {eq(showModalDateTime, true) &&
          <ConnectorSetDateTimeModal handleShowDateTime={() => this.handleShowDateTime(showModalDateTime)} />
        }
        {eq(showModalAbout, true) &&
          <AboutModal
            handleShowAbout={() => this.handleShowAbout(showModalAbout)}
            ptdiagVersion={ptdiagVersion}
            year={year}
            translation={t}
          />
        }
        <div className='display-view-title' data-cy='view-title'>{t('Settings')}</div>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-2' data-cy='settings-menu-buttons'>
              <button className='btn btn-block btn-ptdiag my-2' onClick={getDeviceInformation}>{t('Refresh Device Information')}</button>
              <button className='btn btn-block btn-ptdiag my-2' onClick={() => this.handleShowAbout(showModalAbout)}>{t('About PTDiag')}</button>
              {filterPerUserLevel(userlevel, Service) &&
                <React.Fragment>
                  <button className='btn btn-block btn-ptdiag my-2' onClick={() => this.handleShowDateTime(showModalDateTime)}>{t('Set Date/Time')}</button>
                  <button className='btn btn-block btn-ptdiag my-2' onClick={() => this.handleShowRestart(showModalRestart)}>{t('Restart')}</button>
                </React.Fragment>
              }
            </div>
            <div className='col'>
              <DeviceInformation
                systemInfo={systemInfo}
                appInfo={appInfo}
                ptdiagVersion={ptdiagVersion}
                translation={t}
              />
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }

  private handleShowRestart = (showModalRestart: boolean) => {
    this.setState({ showModalRestart: !showModalRestart })
  }

  private handleShowDateTime = (showModalDateTime: boolean) => {
    this.setState({ showModalDateTime: !showModalDateTime })
  }

  private handleShowAbout = (showModalAbout: boolean) => {
    this.setState({ showModalAbout: !showModalAbout })
  }

}
