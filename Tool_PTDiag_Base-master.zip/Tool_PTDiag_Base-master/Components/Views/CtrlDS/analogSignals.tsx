import React, { ChangeEvent } from 'react';
import { ICTRLAnalog } from '../../../Datastore/InitialDataInterfaces';
import { map, filter, chain } from '../../../CommonFunctions/pointfreeUtilities';
import { safeNewArray, filterSearchStringSignal, getAnalogValue } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface IModifyCallback {
  type: string;
  name: string;
}

interface IAnalogSignalsProps {
  analogData: ICTRLAnalog[];
  ctrlInfo: any;
  modifyCallback: (data: IModifyCallback) => void;
  translation: (word: string) => string;
}

interface IAnalogSignalsState {
  search: string;
}

export class AnalogSignals extends React.Component<IAnalogSignalsProps, IAnalogSignalsState> {
  constructor(props: IAnalogSignalsProps) {
    super(props);
    this.state = {
      search: ''
    }
  }

  render() {
    const { analogData, ctrlInfo } = this.props;
    const { translation, modifyCallback } = this.props;
    const { search } = this.state;
    return (
      <React.Fragment>
        <div className="d-flex justify-content-between">
          <div className='display-view-subtitel'>{translation('Analog Signals')}</div>
          <div className="form-group">
            <input type="search" className="form-control" placeholder={`${translation('Search')}...`} id="search-input" aria-describedby="search" name='search' value={search} onChange={this.handleSearchChanged} />
          </div>
        </div>
        <table className='table table-hover table-fixHead display-view-table mt-2'>
          <thead>
            <tr>
              <th scope='col'></th>
              <th scope='col'>{translation('Signal')}</th>
              <th scope='col'>{translation('Value')}</th>
              <th scope='col'>{translation('Unit')}</th>
            </tr>
          </thead>
          <tbody>
            {this.analogList(analogData, ctrlInfo, search, translation, modifyCallback)}
          </tbody>
        </table>
      </React.Fragment>
    );
  }

  private handleSearchChanged = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ search: event.target.value })
  }

  private analogList = (analogData: ICTRLAnalog[], ctrlInfo: any, search: string, translation: (word: string) => string, modifyCallback: (data: IModifyCallback) => void) => {
    const generateAnalogEntry = (x: ICTRLAnalog) =>
      <tr key={x.name}>
        <td></td>
        <td>
          <button className='btn btn-outline-light text-dark border-0' onClick={() => modifyCallback({ type: 'analog', name: x.name })}>
            {x.name}
          </button>
        </td>
        <td>{getAnalogValue(x, ctrlInfo)}</td>
        <td>{x.unit}</td>
      </tr>
      ;
    const getAnalogValues = compose(map(filter(filterSearchStringSignal(search, 'name'))), safeNewArray);
    return getAnalogValues(analogData).matchWith({
      Just: (value: any) => chain(map(generateAnalogEntry), value),
      Nothing: () =>
        <tr>
          <td colSpan={5} className='text-center'>{translation('No Entries Found')}</td>
        </tr>
    });

  }

}
