import React from 'react';
import { ICTRLAnalog, ICTRLDigital, IInfoCategory } from '../../../Datastore/InitialDataInterfaces';
import { IDataModify } from '../../../ConnectingComponents/CtrlDS/ctrldsConnector';
import { ModulesTabConnector } from '../../../ConnectingComponents/TabModules/modulesTabConnector';
import { ModulesTab } from '../../ModulesTab/modulesTab';
import { DigitalSignals } from './digitalSignals';
import { AnalogSignals } from './analogSignals';
import { ModifySignalConnector } from '../../../ConnectingComponents/ModifyCtrlSignal/modifySignalCtrlConnector';
import { ModifySignal } from '../ModifyCtrlSignal/modifySignal';

interface ICTRLDSProps {
  categories: string[];
  category: string;
  digitalData: ICTRLDigital[];
  analogData: ICTRLAnalog[];
  ctrlInfo: IInfoCategory;
  t: (word: string) => string;
  updateCtrlInfo: () => void;
  categoryChangeCallback: (category: ICategoryChange) => void;
  modifyCallback: (data: IDataModify) => void;
}

interface IData {
  type: string;
  name: string;
}

interface ICTRLDSState {
  showModalModify: boolean;
}

interface ICategoryChange {
  category: string;
}

const ConnectorModulesTab = ModulesTabConnector(ModulesTab);
const ConnectorModifySignal = ModifySignalConnector(ModifySignal);

export class CTRLDS extends React.Component<ICTRLDSProps, ICTRLDSState> {
  constructor(props: ICTRLDSProps) {
    super(props);
    this.state = {
      showModalModify: false
    }
  }

  render() {
    const { categories, category, digitalData, analogData, ctrlInfo } = this.props;
    const { t, categoryChangeCallback, modifyCallback } = this.props;
    const { showModalModify } = this.state;

    return (
      <React.Fragment>
        {showModalModify === true &&
          <ConnectorModifySignal handleShowModifyMenu={() => this.handleShowModifyMenu(showModalModify)} />
        }
        <div className='display-view-title' data-cy='view-title'>{t('CtrlDS Signals')}</div>
        <div className='text-right'><ConnectorModulesTab /></div>
        <div className="form-inline">
          <div className="form-group mx-sm-3 mb-2">
            <label htmlFor="categoriesFormControlSelect" className='mr-2'>{t('Categories')}</label>
            <select className="form-control" id="categoriesFormControlSelect" value={category} onChange={(event) => categoryChangeCallback({ category: event.target.value })}>
              {categories.map(category => (<option key={category}>{category}</option>))}
            </select>
          </div>
        </div>
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-12 col-xl-8'>
              <DigitalSignals
                digitalData={digitalData}
                ctrlInfo={ctrlInfo}
                modifyCallback={(data) => this.modifyCallback(data, showModalModify, modifyCallback)}
                translation={t}
              />
            </div>
            <div className='col'>
              <AnalogSignals
                analogData={analogData}
                ctrlInfo={ctrlInfo}
                modifyCallback={(data) => this.modifyCallback(data, showModalModify, modifyCallback)}
                translation={t}
              />
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }

  componentDidMount() {
    this.props.updateCtrlInfo();
  }

  private modifyCallback = (data: IData, showModalModify: boolean, modifyCallback: (data: IDataModify) => void): void => {
    modifyCallback(data);
    this.handleShowModifyMenu(showModalModify);
  }

  private handleShowModifyMenu = (showModalModify: boolean): void => {
    this.setState({ showModalModify: !showModalModify })
  }

}
