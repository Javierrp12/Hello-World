import React, { ChangeEvent } from 'react';
import { ICTRLDigital } from '../../../Datastore/InitialDataInterfaces';
import { chain, map, filter } from '../../../CommonFunctions/pointfreeUtilities';
import { filterSearchStringSignal, safeNewArray, getDigitalStatus } from '../../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface IModifyCallback {
  type: string;
  name: string;
}

interface IDigitalSignalsProps {
  digitalData: ICTRLDigital[];
  ctrlInfo: any;
  modifyCallback: (data: IModifyCallback) => void;
  translation: (word: string) => string;
}

interface IDigitalSignalsState {
  search: string;
}

export class DigitalSignals extends React.Component<IDigitalSignalsProps, IDigitalSignalsState> {
  constructor(props: IDigitalSignalsProps) {
    super(props);
    this.state = {
      search: ''
    }
  }

  render() {
    const { digitalData, ctrlInfo } = this.props;
    const { translation, modifyCallback } = this.props;
    const { search } = this.state;

    return (
      <React.Fragment>
        <div className="d-flex justify-content-between">
          <div className='display-view-subtitel'>{translation('Digital Signals')}</div>
          <div className="form-group">
            <input type="search" className="form-control" placeholder={`${translation('Search')}...`} id="search-input" aria-describedby="search" name='search' value={search} onChange={this.handleSearchChanged} />
          </div>
        </div>
        <table className='table table-hover table-fixHead display-view-table mt-2'>
          <thead>
            <tr>
              <th scope='col' className='text-center'>{translation('Signals')}</th>
            </tr>
          </thead>
        </table>
        <div className='container-fluid'>
          <div className='row'>
            {this.digitalList(digitalData, ctrlInfo, search, translation, modifyCallback)}
          </div>
        </div>
      </React.Fragment >
    );
  }

  private handleSearchChanged = (event: ChangeEvent<HTMLInputElement>): void => {
    this.setState({ search: event.target.value })
  }

  private digitalList = (digitalData: ICTRLDigital[], ctrlInfo: any, search: string, translation: (word: string) => string, modifyCallback: (data: IModifyCallback) => void) => {
    const generateDigitalEntry = (x: ICTRLDigital, index: number) => {
      return (
        <div key={`${x.name}_${index}`} className='col-12 col-sm-12 col-md-6 col-lg-4 col-xl-4 p-1'>
          <button className={`btn btn-outline-primary digital-signal-hover rounded-pill text-truncate col bg-${getDigitalStatus('severity', x, ctrlInfo)}`} onClick={() => modifyCallback({ type: 'digital', name: x.name })}>
            {x.name}
          </button>
        </div>
      )
    }

    const filterSignals = map(filter(filterSearchStringSignal(search, 'name')));
    const getDigitalFlags = compose(filterSignals, safeNewArray);
    return getDigitalFlags(digitalData).matchWith({
      Just: (value: any) => chain(map(generateDigitalEntry), value),
      Nothing: () =>
        <div className='col text-center'>{translation('No Entries Found')}</div>
    });
  }

}