import React from 'react';
import { IDigital } from '../../../Datastore/InitialDataInterfaces';
import { ModalWindow } from '../modalWindow';
import { IForceSignalData } from './modifySignal';
import { safeProp, eq } from '../../../CommonFunctions/pointfreeUtilities';

interface IDigitalProps {
  signalData: IDigital;
  forceSignal: boolean;
  translation: (word: string) => string;
  forceSignalCallback: (forceSignalData: IForceSignalData) => void;
  cancelCallback: () => void;
}

interface IDigitalState {
  radioStatus: boolean
}

export class DigitalSignal extends React.Component<IDigitalProps, IDigitalState> {
  constructor(props: IDigitalProps) {
    super(props);
    this.state = {
      radioStatus: safeProp('status', this.props.signalData).getOrElse(false)
    }
  }

  render() {
    const { signalData, forceSignal } = this.props
    const { translation, forceSignalCallback, cancelCallback } = this.props;
    const { radioStatus } = this.state;

    return (
      <ModalWindow>
        <div className='modal-ptdiag'>
          <div className='modal-dialog modal-dialog-centered'>
            <div className='modal-content'>
              <div className='modal-header'>
                <div className='display-view-subtitel text-truncate'>{safeProp('name', signalData).getOrElse('')}</div>
                <button className='close' onClick={cancelCallback}><span>x</span></button>
              </div>
              <div className='modal-body'>
                <div className="d-flex justify-content-center">
                  <div className="form-check form-check-inline">
                    <input className="form-check-input" type="radio" name="radioStatus" checked={eq(radioStatus, true)} onChange={() => this.handledClick(true)} id="inlineRadioTrue" value="True" />
                    <label className="form-check-label" htmlFor="inlineRadioTrue">{translation('True')}</label>
                  </div>
                  <div className="form-check form-check-inline">
                    <input className="form-check-input" type="radio" name="radioStatus" checked={eq(radioStatus, false)} onChange={() => this.handledClick(false)} id="inlineRadioFalse" value="False" />
                    <label className="form-check-label" htmlFor="inlineRadioFalse">{translation('False')}</label>
                  </div>
                </div>
              </div>
              <div className='modal-footer'>
                <button className='btn btn-secondary m-2' onClick={cancelCallback}>{translation('Close')}</button>
                {forceSignal === true &&
                  <button className='btn btn-ptdiag' onClick={() => forceSignalCallback({ name: safeProp('name', signalData).getOrElse(''), value: radioStatus, command: 'clear' })}>{translation('Reset')}</button>
                }
                <button className='btn btn-ptdiag' onClick={() => forceSignalCallback({ name: safeProp('name', signalData).getOrElse(''), value: radioStatus, command: 'set' })}>{translation('Set Signal')}</button>
              </div>
            </div>
          </div>
        </div>
      </ModalWindow >
    );
  }

  private handledClick = (state: boolean): void => {
    this.setState({ radioStatus: state });
  }

}
