import React from 'react';
import { IDigital, IAnalog } from '../../../Datastore/InitialDataInterfaces';
import { DigitalSignal } from './digitalSignal';
import { AnalogSignal } from './analogSignal';

export interface IForceSignalData {
  name: string;
  value?: boolean | number;
  command: string;
}

interface IModifySignal {
  signalDataDigital: IDigital;
  signalDataAnalog: IAnalog;
  signalType: string;
  forceSignal: boolean;
  forceSignalCallback: (forceSignalData: IForceSignalData) => void;
  cancelCallback: () => void;
  handleShowModifyMenu: () => void;
  t: (word: string) => string;
}

export class ModifySignal extends React.Component<IModifySignal> {

  render() {
    const { t, cancelCallback, forceSignalCallback, handleShowModifyMenu } = this.props;
    const { signalType, forceSignal, signalDataDigital, signalDataAnalog } = this.props;

    if (signalType === 'digital') {
      return <DigitalSignal
        signalData={signalDataDigital}
        forceSignal={forceSignal}
        forceSignalCallback={(data) => this.forceSignalCallback(data, forceSignalCallback, handleShowModifyMenu)}
        cancelCallback={() => this.cancelCallback(cancelCallback, handleShowModifyMenu)}
        translation={t}
      />
    }

    if (signalType === 'analog') {
      return <AnalogSignal
        signalData={signalDataAnalog}
        forceSignal={forceSignal}
        forceSignalCallback={(data) => this.forceSignalCallback(data, forceSignalCallback, handleShowModifyMenu)}
        cancelCallback={() => this.cancelCallback(cancelCallback, handleShowModifyMenu)}
        translation={t}
      />
    }

    return null;
  }

  private forceSignalCallback = (data: any, forceSignalCallback: (forceSignalData: IForceSignalData) => void, handleShowModifyMenu: () => void): void => {
    forceSignalCallback(data);
    handleShowModifyMenu();
  }

  private cancelCallback = (cancelCallback: () => void, handleShowModifyMenu: () => void): void => {
    cancelCallback();
    handleShowModifyMenu();
  }

}