import React, { ChangeEvent } from 'react';
import { IAnalog } from '../../../Datastore/InitialDataInterfaces';
import { ModalWindow } from '../modalWindow';
import { IForceSignalData } from './modifySignal';
import { safeProp } from '../../../CommonFunctions/pointfreeUtilities';

interface IAnalogProps {
  signalData: IAnalog;
  forceSignal: boolean;
  translation: (word: string) => string;
  forceSignalCallback: (forceSignalData: IForceSignalData) => void;
  cancelCallback: () => void;
}

interface IDigitalState {
  value: string;
}

export class AnalogSignal extends React.Component<IAnalogProps, IDigitalState> {
  inputValueRef: React.RefObject<HTMLInputElement>;
  constructor(props: IAnalogProps) {
    super(props);
    this.state = {
      value: safeProp('value', this.props.signalData).getOrElse('0').toFixed(Math.floor(safeProp('qFormat', this.props.signalData).getOrElse(2.5) / 2.5))
    }
    this.inputValueRef = React.createRef();
  }

  render() {
    const { signalData, forceSignal } = this.props;
    const { translation, cancelCallback, forceSignalCallback } = this.props;
    const { value } = this.state;

    const stepCalculation = (qFormat: number) => {
      const qFormatFactor = 2.5;
      return (`${1 / Math.pow(10, Math.floor(qFormat / qFormatFactor))}`);
    }

    return (
      <ModalWindow>
        <div className='modal-ptdiag'>
          <div className='modal-dialog modal-dialog-centered'>
            <div className='modal-content'>
              <div className='modal-header'>
                <div className='display-view-subtitel'>{safeProp('name', signalData).getOrElse({})}</div>
                <button className='close' onClick={cancelCallback}><span>x</span></button>
              </div>
              <div className='modal-body'>
                <div className="d-flex justify-content-center mt-1">
                  <form onSubmit={(event) => this.handleSubmit(event, signalData, value, forceSignalCallback)}>
                    <div className="form-group">
                      <label htmlFor="valueFormControlInput">{translation('Value')}</label>
                      <input type="number" className="form-control" id="valueFormControlInput" name='value' step={stepCalculation(safeProp('qFormat', signalData).getOrElse(2.5))} value={value} onChange={this.handleValueChanged} autoFocus={true} onKeyUp={(event) => this.handlekeypress(event, cancelCallback)} ref={this.inputValueRef} onFocus={this.handleFocus} />
                    </div>
                  </form>
                </div>
              </div>
              <div className='modal-footer'>
                <button className='btn btn-secondary m-2' onClick={cancelCallback}>{translation('Close')}</button>
                {forceSignal === true &&
                  <button className='btn btn-ptdiag' onClick={() => forceSignalCallback({ name: safeProp('name', signalData).getOrElse(''), command: 'clear' })}>{translation('Reset')}</button>
                }
                <button className='btn btn-ptdiag' onClick={() => forceSignalCallback({ name: safeProp('name', signalData).getOrElse(''), value: Number(value), command: 'set' })}>{translation('Set Signal')}</button>
              </div>
            </div>
          </div>
        </div>
      </ModalWindow>
    );
  }

  componentDidMount() {
    this.inputValueRef.current!.focus();
  }

  private handleValueChanged = (event: ChangeEvent<HTMLInputElement>): void => {
    if (isNaN(Number(event.target.value)) === false) {
      this.setState({ value: event.target.value });
    }
  }

  private handleSubmit = (event: React.FormEvent<HTMLFormElement>, signalData: IAnalog, value: string, forceSignalCallback: (forceSignalData: IForceSignalData) => void): void => {
    event.preventDefault();
    forceSignalCallback({ name: safeProp('name', signalData).getOrElse(''), value: Number(value), command: 'set' });
  }

  private handleFocus = (event: React.FocusEvent<HTMLInputElement>): void => event.target.select();
  private handlekeypress = (event: React.KeyboardEvent<HTMLInputElement>, cancelCallback: () => void): void => {
    if (event.key === "Escape") {
      cancelCallback();
    }
  }

}
