import React, { Component } from 'react';

interface IViewColumnProps {
  column: string;
  unit?: string;
  handleClickSortCallback: (title: string) => void;
  checkForSymbolCallback: (column: string) => string;
  translation: (word: string) => string;
}

export class ViewColumn extends Component<IViewColumnProps> {

  static defaultProps = {
    column: '',
    unit: '',
    handleClickSortCallback: () => { },
    checkForSymbolCallback: () => { },
    t: () => { }
  }

  render() {
    const { translation, column, unit, handleClickSortCallback, checkForSymbolCallback } = this.props;
    return (
      <React.Fragment>
        <th scope='col'>
          {translation(column)} {unit}
          <button className='btn btn-sm' onClick={() => handleClickSortCallback(column)} > <i className={checkForSymbolCallback(column)}></i>
          </button>
        </th>
      </React.Fragment>
    );
  }
}