import { Modules } from '../Datastore/ModelData/modulesTypes';
import { Middleware } from "redux";
import {
    CREATE_MODULE_DATA,
    UPDATE_SYSTEM_CONFIG_DATA,
    UPDATE_UNITS_DATA,
    UPDATE_ANALOG_VALUES,
    UPDATE_DIGITAL_FLAGS,
    GET_ONLINE_DATA,
    GET_EVENTLOG_DATA,
    UPDATE_COMPONENT_DATA,
    UPDATE_OSCILLOSCOPE_VALUES,
    UPDATE_COUNTERS_DATA
} from '../Datastore/ModelData/modelActionTypes';
import {
    UPDATE_MODULES_STATE,
    UPDATE_SNAPSHOT_DATA,
    UPDATE_INFO,
    UPDATE_PARAMETER_INFO,
} from '../Datastore/StateData/stateActionTypes';
import { ViewTypes } from '../Datastore/ModelData/viewTypes';
import { updateErrorStatus } from '../Datastore/ErrorData/errorActionCreator';
import { map, reduce, chain, safeProp, safeHead, filter } from '../CommonFunctions/pointfreeUtilities';
import { maybeA, safeGetValuesObject, safeNewArray, updateUnitConfig, updateSystemConfig, safeObjectSearch, eq3, addProperty, updateOnlineData } from '../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');
const identity = require('folktale/core/lambda/identity');

declare global {
    interface Window {
        moduleMU: any;
        moduleIVPS: any;
        moduleINV: any;
        moduleLVPS: any;
        snapshotModuleMU: any;
        snapshotModuleIVPS: any;
        snapshotModuleINV: any;
        snapshotModuleLVPS: any;
        systemConfig: any;
        ptDiagData: any;
    }
}

export const createRestMiddleware: Middleware = ({ dispatch, getState }) => {
    const getMUModuleData = compose(chain(safeProp('moduleMU')), maybeA);
    const getIVPSModuleData = compose(chain(safeProp('moduleIVPS')), maybeA);
    const getINVModuleData = compose(chain(safeProp('moduleINV')), maybeA);
    const getLVPSModuleData = compose(chain(safeProp('moduleLVPS')), maybeA);

    const modulesFiles = {
        [Modules.MU]: getMUModuleData(window).getOrElse(undefined),
        [Modules.IVPS]: getIVPSModuleData(window).getOrElse(undefined),
        [Modules.INV]: getINVModuleData(window).getOrElse(undefined),
        [Modules.LVPS]: getLVPSModuleData(window).getOrElse(undefined)
    }

    const getSnapshotMUModuleData = compose(chain(safeProp('snapshotModuleMU')), maybeA);
    const getSnapshotIVPSModuleData = compose(chain(safeProp('snapshotModuleIVPS')), maybeA);
    const getSnapshotINVModuleData = compose(chain(safeProp('snapshotModuleINV')), maybeA);
    const getSnapshotLVPSModuleData = compose(chain(safeProp('snapshotModuleLVPS')), maybeA);

    const snapshotModulesFiles = {
        [Modules.MU]: getSnapshotMUModuleData(window).getOrElse(undefined),
        [Modules.IVPS]: getSnapshotIVPSModuleData(window).getOrElse(undefined),
        [Modules.INV]: getSnapshotINVModuleData(window).getOrElse(undefined),
        [Modules.LVPS]: getSnapshotLVPSModuleData(window).getOrElse(undefined),
    }

    return (next: Function) => (action: any) => {
        const getModules = safeGetValuesObject;
        const modules = getModules(Modules).getOrElse([]);

        switch (action.type) {
            case UPDATE_UNITS_DATA:
                const errorMessage_unitData = compose(chain(identity), chain(safeHead));
                const updateModuleUnitConfig = compose(errorMessage_unitData, compose(map(reduce(updateUnitConfig(window, modulesFiles, 'ptDiagData.unitsData.modules'), [])), safeNewArray));
                const updateSnapshotModuleUnitConfig = compose(errorMessage_unitData, compose(map(reduce(updateUnitConfig(window, snapshotModulesFiles, 'ptDiagData.unitsData.modules'), [])), safeNewArray));

                updateModuleUnitConfig(modules).matchWith({
                    Nothing: () => { },
                    Error: (error: any) => {
                        dispatch(updateErrorStatus({ isOnline: true, error: error.merge() }));
                    }
                });

                updateSnapshotModuleUnitConfig(modules).matchWith({
                    Nothing: () => { },
                    Error: (error: any) => {
                        dispatch(updateErrorStatus({ isOnline: true, error: error.merge() }));
                    }
                });
                break;

            case UPDATE_SYSTEM_CONFIG_DATA:
                const errorMessage_systemconfig = compose(chain(identity), chain(safeHead));
                const updateModuleSystemConfig = compose(errorMessage_systemconfig, compose(map(reduce(updateSystemConfig(window, modulesFiles), [])), safeNewArray));
                updateModuleSystemConfig(modules).matchWith({
                    Nothing: () => {
                        const updateData = (module: string) => {
                            const digitalCtrl = safeProp('CtrlDS', modulesFiles[module].getCtrlDSFlagsData()).getOrElse({});
                            const analogCtrl = safeProp('CtrlDS', modulesFiles[module].getCtrlDSValuesData()).getOrElse({});
                            next({ type: CREATE_MODULE_DATA, dataType: ViewTypes.CtrlDS, payload: { module: module, data: { digital: digitalCtrl, analog: analogCtrl } } });
                            const digital = modulesFiles[module].getEnvFlagsData();
                            const analog = modulesFiles[module].getEnvValuesData();
                            next({ type: CREATE_MODULE_DATA, dataType: ViewTypes.ModuleSignals, payload: { module: module, data: { digital: digital, analog: analog } } });
                            const addVisibleBy = map(reduce(addProperty('visibleBy', safeProp('Param', modulesFiles[module].getParamData()).getOrElse({})), []));
                            const getCategories = compose(chain(safeProp('categories')), safeHead);
                            const getParameters = compose(chain(filter(eq3('Param', 'name'))), chain(safeProp('dataStores')));
                            const filterPerModule = compose(chain(safeHead), map(filter(eq3(module, 'name'))));
                            const getParametersData = compose(compose(addVisibleBy, compose(getCategories, compose(getParameters, filterPerModule))), safeObjectSearch('systemConfig.modules'));
                            next({ type: CREATE_MODULE_DATA, dataType: ViewTypes.Parameters, payload: { module: module, data: getParametersData(window).getOrElse({}) } });
                            const parametersUnits = safeProp('Unit', modulesFiles[module].getUnitData()).getOrElse();
                            next({ type: CREATE_MODULE_DATA, dataType: ViewTypes.Units, payload: { module: module, data: parametersUnits } });
                        }
                        const updateProjectData = compose(map(map(updateData)), safeNewArray);
                        updateProjectData(modules);
                    },
                    Error: (error: any) => {
                        dispatch(updateErrorStatus({ isOnline: true, error: error.merge() }));
                    }
                });
                break;

            case GET_ONLINE_DATA:
                const errorMessage_onlineData = compose(chain(identity), chain(safeHead));
                const updateModuleOnlineData = compose(errorMessage_onlineData, compose(map(reduce(updateOnlineData(window, modulesFiles, 'ptDiagData.onlineData'), [])), safeNewArray));
                updateModuleOnlineData(modules).matchWith({
                    Nothing: () => {
                        const getComponentsData = compose(chain(safeObjectSearch('ptDiagData.onlineData.components')), maybeA);
                        const getConververData = compose(chain(safeObjectSearch('ptDiagData.onlineData.converter')), maybeA);
                        const getCountersData = compose(chain(safeObjectSearch('ptDiagData.onlineData.counters')), maybeA);
                        next({ type: UPDATE_COMPONENT_DATA, dataType: ViewTypes.SystemOverview, payload: { ...getComponentsData(window).getOrElse({}), converter: getConververData(window).getOrElse({}) } });
                        next({type: UPDATE_COUNTERS_DATA, dataType: ViewTypes.SystemCounters, payload: getCountersData(window).getOrElse([])});
                        const updateData = (module: string) => {
                            const filterPerModule = compose(chain(safeHead), map(filter(eq3(module, 'name'))));
                            const getModulesData = compose(compose(filterPerModule, chain(safeObjectSearch('ptDiagData.onlineData.components.modules'))), maybeA);
                            next({ type: UPDATE_MODULES_STATE, payload: { module: module, state: safeProp('state', getModulesData(window).getOrElse({})).getOrElse('Undefined') } });
                            const digital = modulesFiles[module].getEnvFlagsData();
                            const analog = modulesFiles[module].getEnvValuesData();
                            next({ type: UPDATE_ANALOG_VALUES, dataType: ViewTypes.SystemOverview, payload: { module: module, data: analog } });
                            next({ type: UPDATE_DIGITAL_FLAGS, dataType: ViewTypes.SystemOverview, payload: { module: module, data: digital } });
                            next({ type: CREATE_MODULE_DATA, dataType: ViewTypes.ModuleSignals, payload: { module: module, data: { digital: digital, analog: analog } } });
                            next({ type: UPDATE_OSCILLOSCOPE_VALUES, dataType: ViewTypes.Oscilloscope, payload: { module: module, data: { digital: digital, analog: analog } } });
                        };
                        const updateProjectData = compose(map(map(updateData)), safeNewArray);
                        updateProjectData(modules);
                    },
                    Error: (error: any) => {
                        dispatch(updateErrorStatus({ isOnline: true, error: error.merge() }));
                    }
                });
                break;

            case GET_EVENTLOG_DATA:
                const updateEventsData = (module: string) => {
                    const addIndex = (event: any, index: number) => ({ ...event, index });
                    const addIndexToEvent = compose(map(map(addIndex)), chain(safeProp('events')));
                    const filterPerModule = compose(addIndexToEvent, compose(chain(safeHead), map(filter(eq3(module, 'module')))));
                    const getModuleEventLog = compose(compose(filterPerModule, chain(safeObjectSearch('ptDiagData.eventlog.modules'))), maybeA);
                    next({ type: CREATE_MODULE_DATA, dataType: ViewTypes.EventLog, payload: { module: module, data: getModuleEventLog(window).getOrElse([]) } });
                };
                const updateEventlogData = compose(map(map(updateEventsData)), safeNewArray);
                updateEventlogData(modules);
                break;

            case UPDATE_SNAPSHOT_DATA:
                snapshotModulesFiles[action.payload.module].updateData(action.payload.snapshot);
                const digital = snapshotModulesFiles[action.payload.module].getEnvFlagsData();
                const analog = snapshotModulesFiles[action.payload.module].getEnvValuesData();
                next({ type: UPDATE_SNAPSHOT_DATA, payload: { digital: digital, analog: analog } });
                break;

            case UPDATE_PARAMETER_INFO:
                const updateInfoData = (module: string) => {
                    const filterPerModule = compose(chain(safeHead), map(filter(eq3(module, 'module'))));
                    const getModuleParameterInfo = compose(compose(chain(safeProp('categories')), compose(filterPerModule, chain(safeObjectSearch('ptDiagData.parametersData.modules')))), maybeA);
                    next({ type: UPDATE_INFO, dataType: ViewTypes.Parameters, payload: { module: module, data: getModuleParameterInfo(window).getOrElse([]) } });
                };
                const updateParameterInfoData = compose(map(map(updateInfoData)), safeNewArray);
                updateParameterInfoData(modules);
                break;

            default:
                next(action);
                break;
        }
    }
}