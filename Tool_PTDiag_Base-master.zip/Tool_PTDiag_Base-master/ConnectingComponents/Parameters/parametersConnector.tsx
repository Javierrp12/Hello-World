import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { withTranslation } from 'react-i18next';
import { ViewTypes } from '../../Datastore/ModelData/viewTypes';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';
import { IParameterData } from '../../Datastore/StateData/stateActionCreator';
import {
  updateCategory, updateParameterInfo, restoreToFactorySettings,
  saveParameters, IChangeCategory, changeTemporalyFile, changeParameterTemporarily, resetParameterTemporarily
} from '../../Datastore/StateData/stateActionCreator';
import { updateErrorStatus, IErrorInfo } from '../../Datastore/ErrorData/errorActionCreator';
import { IParameterDataFile } from '../../Datastore/StateData/stateActionCreator';
import { map, sortBy, filter, safeProp, safeHead, chain, toLowerCase } from '../../CommonFunctions/pointfreeUtilities';
import { safeGetKeysObject, filterCategoriesPerUserLevel, checkCategory, safeGetValuesObject, safeObjectSearch, eq3 } from '../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

export interface IParametersDataModify {
  parameter: string;
  value?: string;
}

export const ParametersConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    const activeModule = storeData.stateData.activeModule;
    const userlevel = storeData.stateData.userlevel;
    const currentCategory = storeData.stateData.parameters.currentCategory[activeModule];
    const getCategories = compose(compose(map(sortBy(toLowerCase)), map(filter(filterCategoriesPerUserLevel(storeData.modelData.parameters[activeModule], userlevel)))), safeGetKeysObject);
    const categories = getCategories(storeData.modelData.parameters[activeModule]).getOrElse([]);
    const getValidCategory = compose(chain(checkCategory(currentCategory, userlevel)), safeProp(currentCategory));
    const category = getValidCategory(storeData.modelData.parameters[activeModule]).getOrElse(safeHead(categories).getOrElse(''));
    const getParametersData = compose(chain(safeGetValuesObject), safeObjectSearch(`${activeModule}.${category}`));
    const modulesParametersData = storeData.modelData.parameters;
    const modulesParametersInfo = storeData.stateData.parameters.info;
    const getParameterInfo = compose(chain(safeProp('parameters')), compose(chain(safeHead), compose(map(filter(eq3(category, 'name'))), safeObjectSearch(`info.${activeModule}`))));

    return {
      activeModule: activeModule,
      parametersData: getParametersData(storeData.modelData.parameters).getOrElse([]),
      categories: categories,
      category: category,
      parameterInfoData: getParameterInfo(storeData.stateData.parameters).getOrElse([]),
      appInfo: storeData.modelData.appInfo,
      systemInfo: storeData.modelData.systemInfo,
      modulesParametersData: modulesParametersData,
      modulesParametersInfo: modulesParametersInfo,
      userlevel: userlevel
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      updateParameterInfo: () => dispatch(updateParameterInfo()),
      saveAllModulesParameters: (module: string) => dispatch(saveParameters(module)),
      saveParameters: (module: string) => dispatch(saveParameters(module)),
      factorySettingsCallback: (module: string) => dispatch(restoreToFactorySettings(module)),
      categoryChangeCallback: (category: IChangeCategory) => dispatch(updateCategory(ViewTypes.Parameters, category)),
      updateErrorStatusCallback: (data: IErrorInfo) => dispatch(updateErrorStatus(data)),
      changeTemporalyFileCallback: (data: IParameterDataFile[]) => dispatch(changeTemporalyFile(data)),
      resetParameterCallback: (data: IParameterData) => (dispatch(resetParameterTemporarily(ViewTypes.Parameters, data))),
      changeParameterCallback: (data: IParameterData) => (dispatch(changeParameterTemporarily(ViewTypes.Parameters, data))),
    }
  }

  const mergeProps = (dataProps: any, functionProps: any, ownProps: any) => {
    let routedDispatchers = {
      updateParameterInfo: () => { functionProps.updateParameterInfo() },
      saveAllModulesParameters: () => { functionProps.saveAllModulesParameters('all') },
      saveParameters: () => { functionProps.saveParameters(dataProps.activeModule) },
      factorySettingsCallback: () => { functionProps.factorySettingsCallback(dataProps.activeModule) },
      categoryChangeCallback: (data: any) => {
        functionProps.categoryChangeCallback({ ...data, module: dataProps.activeModule });
      },
      updateErrorStatusCallback: (data: IErrorInfo) => { functionProps.updateErrorStatusCallback(data) },
      changeTemporalyFileCallback: (data: IParameterDataFile[]) => { functionProps.changeTemporalyFileCallback(data) },
      resetParameterCallback: (data: IParametersDataModify) => {
        functionProps.resetParameterCallback({ ...data, module: dataProps.activeModule, category: dataProps.category });
      },
      changeParameterCallback: (data: IParametersDataModify) => {
        functionProps.changeParameterCallback({ ...data, module: dataProps.activeModule, category: dataProps.category });
      }
    }
    return Object.assign({}, dataProps, routedDispatchers, ownProps);
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);

  return withRouter(connect(mapStateToProps,
    mapDispatchToProps, mergeProps)(TranslatedComponent));
}