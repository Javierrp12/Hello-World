import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { withTranslation } from 'react-i18next';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';
import { ViewTypes } from '../../Datastore/ModelData/viewTypes';
import { updateModuleActive } from '../../Datastore/StateData/stateActionCreator';
import {
  updateAnalogValuePosition, updateDigitalFlagPosition, updateComponentPosition,
  updateComponentSize, deleteComponent, deleteAnalogValue, deleteDigitalValue, updateEditMode,
  IDeleteDigitalData, IDeleteAnalogData, IDeleteComponentData, IAnalogData,
  IDigitalData, IComponentData, IComponentSize
} from '../../Datastore/ModelData/modelActionCreator';
import { Modules } from '../../Datastore/ModelData/modulesTypes';

export interface IDataModify {
  name: string;
  type: string;
}

export const SystemOverviewConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    return {
      schematicComponents: storeData.modelData.systemoverview.schematicComponents,
      schematicExtraComponents: storeData.modelData.systemoverview.schematicExtraComponents,
      schematicConnections: storeData.modelData.systemoverview.schematicConnections,
      schematicAnalogValues: storeData.modelData.systemoverview.schematicAnalogValues,
      schematicDigitalFlags: storeData.modelData.systemoverview.schematicDigitalFlags,
      editMode: storeData.modelData.systemoverview.editMode,
      userlevel: storeData.stateData.userlevel
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      updateModuleActive: (module: keyof typeof Modules) => dispatch(updateModuleActive(module)),
      updateEditModeCallback: () => dispatch(updateEditMode()),
      updateAnalogValuePositionCallback: (data: IAnalogData) => dispatch(updateAnalogValuePosition(data)),
      updateDigitalFlagPositionCallback: (data: IDigitalData) => dispatch(updateDigitalFlagPosition(data)),
      updateComponentPositionCallback: (data: IComponentData) => dispatch(updateComponentPosition(data)),
      updateComponentSizeCallback: (data: IComponentSize) => dispatch(updateComponentSize(data)),
      deleteComponentCallback: (data: IDeleteComponentData) => dispatch(deleteComponent(data)),
      deleteAnalogValueCallback: (data: IDeleteAnalogData) => dispatch(deleteAnalogValue(data)),
      deleteDigitalFlagCallback: (data: IDeleteDigitalData) => dispatch(deleteDigitalValue(data)),
    }
  }

  const mergeProps = (dataProps: any, functionProps: any, ownProps: any) => {
    let routedDispatchers = {
      updateModuleActive: (module: keyof typeof Modules) => {
        functionProps.updateModuleActive(module);
        ownProps.history.push(`/${ViewTypes.ModuleSignals}`);
      },
      updateEditModeCallback: () => functionProps.updateEditModeCallback(),
      updateAnalogValuePositionCallback: (data: IAnalogData) => functionProps.updateAnalogValuePositionCallback(data),
      updateDigitalFlagPositionCallback: (data: IDigitalData) => functionProps.updateDigitalFlagPositionCallback(data),
      updateComponentPositionCallback: (data: IComponentData) => functionProps.updateComponentPositionCallback(data),
      updateComponentSizeCallback: (data: IComponentData) => functionProps.updateComponentSizeCallback(data),
      deleteComponentCallback: (data: IDeleteComponentData) => functionProps.deleteComponentCallback(data),
      deleteAnalogValueCallback: (data: IDeleteAnalogData) => functionProps.deleteAnalogValueCallback(data),
      deleteDigitalFlagCallback: (data: IDeleteDigitalData) => functionProps.deleteDigitalFlagCallback(data),
    }
    return Object.assign({}, dataProps, routedDispatchers, ownProps);
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);

  return withRouter(connect(mapStateToProps,
    mapDispatchToProps, mergeProps)(TranslatedComponent));
}