import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { withTranslation } from 'react-i18next';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';
import { addComponentToSchematic } from '../../Datastore/ModelData/modelActionCreator';
import { safeHead, safeProp } from '../../CommonFunctions/pointfreeUtilities';
import { safeGetKeysObject, getFirstModule, getModuleSignals } from '../../CommonFunctions/functionsSupport';

export const AddComponentModalConnector = (presentationComponent: any) => {
  const mapStateToProps = (storeData: IInitialData) => {
    const userlevel = storeData.stateData.userlevel;
    const modulesData = storeData.modelData.modulesignals;
    const modules = safeGetKeysObject(modulesData).getOrElse([]);
    const module = getFirstModule(modulesData).getOrElse('');
    const signalAnalogData = safeHead(getModuleSignals(modulesData, module, 'analog', userlevel)).getOrElse({});
    const signalDigitalData = safeHead(getModuleSignals(modulesData, module, 'digital', userlevel)).getOrElse({});
    const signalAnalog = `${safeProp('category', signalAnalogData).getOrElse('')}_${safeProp('name', signalAnalogData).getOrElse('')}`;
    const signalDigital = `${safeProp('category', signalDigitalData).getOrElse('')}_${safeProp('name', signalDigitalData).getOrElse('')}`;

    return {
      options: [
        { option: 'Module', value: 'module' },
        { option: 'Converter', value: 'converter' },
        { option: 'Active Input Filter', value: 'aif' },
        { option: 'Fan', value: 'fan' },
        { option: 'Legend', value: 'legend' },
        { option: 'Contactor', value: 'contactors' },
        { option: 'Fuse', value: 'fuse' },
        { option: 'Info', value: 'info' },
        { option: 'Text', value: 'text' },
        { option: 'Rectangle', value: 'rectangle' },
        { option: '3 Phase', value: '3Phase' },
        { option: 'Diode', value: 'diode' },
        { option: 'Analog Value', value: 'analogValue' },
        { option: 'Digital Flag', value: 'digitalFlag' },
        { option: 'Connection', value: 'connection' }
      ],
      modules: modules,
      userlevel: storeData.stateData.userlevel,
      modulesData: storeData.modelData.modulesignals,
      signalAnalog: signalAnalog,
      signalDigital: signalDigital
    };
  };

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      addComponentToSchematicCallback: (componentData: any) => dispatch(addComponentToSchematic(componentData))
    };
  };

  const mergeProps = (dataProps: any, functionProps: any, ownProps: any) => {
    let routedDispatchers = {
      addComponentToSchematicCallback: (componentData: any) => {
        functionProps.addComponentToSchematicCallback(componentData);
      }
    };
    return Object.assign({}, dataProps, routedDispatchers, ownProps);
  };

  const TranslatedComponent = withTranslation('translation')(presentationComponent);
  return withRouter(connect(mapStateToProps, mapDispatchToProps, mergeProps)(TranslatedComponent));
};
