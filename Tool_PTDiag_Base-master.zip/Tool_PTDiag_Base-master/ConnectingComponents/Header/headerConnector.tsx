import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';
import { updateShowloginStatus } from '../../Datastore/ErrorData/errorActionCreator';
import { logoutRequest } from '../../Datastore/ModelData/modelActionCreator';

export const HeaderConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    return {
      userLevel: storeData.stateData.userlevel,
      date: storeData.stateData.date,
      isOnline: storeData.errorData.errorHandler.isOnline,
      hostname: storeData.modelData.systemInfo.hostname
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      logoutCallback: () => { dispatch(logoutRequest()) },
      updateShowloginStatusCallback: () => { dispatch(updateShowloginStatus()) }
    }
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);
  return connect(mapStateToProps, mapDispatchToProps)(TranslatedComponent);
}