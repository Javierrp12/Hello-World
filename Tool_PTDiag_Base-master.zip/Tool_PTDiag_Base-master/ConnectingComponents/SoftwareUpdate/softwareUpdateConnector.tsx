import { connect } from "react-redux";
import { IInitialData } from '../../Datastore/InitialDataInterfaces';
import { withTranslation } from 'react-i18next';

export const SoftwareUpdateConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    return {
      appInfo: storeData.modelData.appInfo,
      systemInfo: storeData.modelData.systemInfo,
      fileData: storeData.modelData.softwareupdate,
      userlevel: storeData.stateData.userlevel
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      startUpdateProcess: (data: any) => { },
      sendPackageCallback: (file: File) => { }
    }
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);
  return connect(mapStateToProps, mapDispatchToProps)(TranslatedComponent);
}