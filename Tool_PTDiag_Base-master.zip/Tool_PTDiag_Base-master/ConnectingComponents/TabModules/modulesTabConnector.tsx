import { connect } from 'react-redux';
import { Modules } from '../../Datastore/ModelData/modulesTypes';
import { updateModuleActive } from '../../Datastore/StateData/stateActionCreator';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';

export const ModulesTabConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    return {
      activeModule: storeData.stateData.activeModule,
      modulesState: storeData.stateData.modulesState
    }
  }

  const mapDispatchToProps = (dispatch: Function) => ({
    handleClickCallback: (data: keyof typeof Modules) => dispatch(updateModuleActive(data)),
  });

  return connect(mapStateToProps, mapDispatchToProps)(presentationComponent);
}