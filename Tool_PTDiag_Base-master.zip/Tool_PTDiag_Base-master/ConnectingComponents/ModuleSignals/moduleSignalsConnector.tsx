import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { withTranslation } from 'react-i18next';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';
import { ViewTypes } from '../../Datastore/ModelData/viewTypes';
import { Help } from '../../Datastore/ModelData/viewTypes';
import { updateShowInactiveSignals } from '../../Datastore/StateData/stateActionCreator';
import {
  updateHelpActiveList, updateHelpActiveSignal, updateSelectedItem, updateSelectedItemType,
  updateDataStore, updateCategory, updateForceInfo
} from '../../Datastore/StateData/stateActionCreator';
import { getModuleSignals } from '../../CommonFunctions/functionsSupport';

interface IDataModify {
  name: string;
  type: string;
  datastore: string;
  category: string;
  module: string;
}

export const ModuleSignalsConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    const activeModule = storeData.stateData.activeModule;
    const userlevel = storeData.stateData.userlevel;
    const showOnlyActiveSignals = storeData.stateData.showOnlyActiveSignals;
    const digitalData = getModuleSignals(storeData.modelData.modulesignals, activeModule, 'digital', userlevel);
    const analogData = getModuleSignals(storeData.modelData.modulesignals, activeModule, 'analog', userlevel);
    const selectedItem = storeData.stateData.selectedItem;
    const selectedItemType = storeData.stateData.selectedItemType;
    const forceInfo = storeData.stateData.modulesignals.info[activeModule];

    return {
      activeModule: activeModule,
      analogData: analogData,
      digitalData: digitalData,
      showOnlyActiveSignals: showOnlyActiveSignals,
      selectedItem: selectedItem,
      selectedItemType: selectedItemType,
      forceInfo: forceInfo,
      userlevel: userlevel
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      updateForceInfo: () => dispatch(updateForceInfo()),
      showInactiveSignalsCallback: () => dispatch(updateShowInactiveSignals()),
      modifyCallback: (data: IDataModify) => {
        dispatch(updateSelectedItem(data.name));
        dispatch(updateSelectedItemType(data.type));
        dispatch(updateDataStore(ViewTypes.ModuleSignals, { module: data.module, datastore: data.datastore }));
        dispatch(updateCategory(ViewTypes.ModuleSignals, { module: data.module, category: data.category }));
      },
      signalDescriptionCallback: (data: any) => {
        dispatch(updateHelpActiveList(data.list));
        dispatch(updateHelpActiveSignal(`${data.module}_${data.signal}`));
      }
    }
  }

  const mergeProps = (dataProps: any, functionProps: any, ownProps: any) => {
    let routedDispatchers = {
      updateForceInfo: () => { functionProps.updateForceInfo() },
      showInactiveSignalsCallback: () => { functionProps.showInactiveSignalsCallback() },
      modifyCallback: (data: any) => functionProps.modifyCallback({ ...data, module: dataProps.activeModule }),
      signalDescriptionCallback: () => {
        functionProps.signalDescriptionCallback({ signal: dataProps.selectedItem, list: dataProps.selectedItemType, module: dataProps.activeModule });
        ownProps.history.push(`/${Help}`);
      }
    }
    return Object.assign({}, dataProps, routedDispatchers, ownProps);
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);

  return withRouter(connect(mapStateToProps,
    mapDispatchToProps, mergeProps)(TranslatedComponent));
}