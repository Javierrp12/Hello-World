import { connect } from "react-redux";
import { withTranslation } from 'react-i18next';
import { closeErrorModalCallback } from '../../Datastore/ErrorData/errorActionCreator';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';

export const ErrorModalConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    return {
      errorInfo: storeData.errorData.errorHandler
    }
  }
  const mapDispatchToProps = (dispatch: Function) => {
    return {
      closeErrorModalCallback: () => dispatch(closeErrorModalCallback())
    }
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);
  return connect(mapStateToProps, mapDispatchToProps)(TranslatedComponent);
}