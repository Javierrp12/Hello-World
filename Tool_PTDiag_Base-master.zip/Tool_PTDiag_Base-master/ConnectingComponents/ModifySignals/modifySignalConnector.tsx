import { connect } from "react-redux";
import { withTranslation } from 'react-i18next';
import { withRouter } from "react-router-dom";
import { forceSignal, updateSelectedItem, updateSelectedItemType } from '../../Datastore/StateData/stateActionCreator';
import { ViewTypes } from '../../Datastore/ModelData/viewTypes';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';
import { safeObjectSearch } from '../../CommonFunctions/functionsSupport';

export const ModifySignalConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    const activeModule = storeData.stateData.activeModule;
    const currentDatastore = storeData.stateData.modulesignals.currentDatastore[activeModule];
    const currentCategory = storeData.stateData.modulesignals.currentCategory[activeModule];
    const selectedItemType = storeData.stateData.selectedItemType;
    const selectedItem = storeData.stateData.selectedItem;
    const getItemData = safeObjectSearch(`${activeModule}.${selectedItemType}.${currentDatastore}.${currentCategory}.${selectedItem}`);
    const itemData = getItemData(storeData.modelData.modulesignals).getOrElse({});
    const forceInfo = storeData.stateData.modulesignals.info[activeModule];
    const getForceSignal = safeObjectSearch(`${currentDatastore}.${currentCategory}.${selectedItem}`);

    return {
      activeModule: activeModule,
      signalType: selectedItemType,
      datastore: currentDatastore,
      category: currentCategory,
      signalDataDigital: (selectedItemType === "digital") ? itemData : {},
      signalDataAnalog: (selectedItemType === "analog") ? itemData : {},
      forceSignal: getForceSignal(forceInfo).matchWith({
        Just: () => true,
        Nothing: () => false
      })
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      forceSignalCallback: (data: any) => {
        dispatch(forceSignal(ViewTypes.ModuleSignals, data));
        dispatch(updateSelectedItem(''));
        dispatch(updateSelectedItemType('analog'));
      },
      cancelCallback: () => {
        dispatch(updateSelectedItem(''));
        dispatch(updateSelectedItemType('analog'));
      }
    }
  }

  const mergeProps = (dataProps: any, functionProps: any, ownProps: any) => {
    let routedDispatchers = {
      forceSignalCallback: (data: any) => {
        functionProps.forceSignalCallback({ ...data, module: dataProps.activeModule, datastore: dataProps.datastore, category: dataProps.category, type: dataProps.signalType });
      },
      cancelCallback: (data: any) => {
        functionProps.cancelCallback(data);
      }
    }
    return Object.assign({}, dataProps, routedDispatchers, ownProps);
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);

  return withRouter(connect(mapStateToProps,
    mapDispatchToProps, mergeProps)(TranslatedComponent));
}