import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { closeInfoModal } from '../../../Base/Datastore/ErrorData/errorActionCreator';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';

export const InfoModalConnector = (presentationComponent: any) => {
  const mapStateToProps = (storeData: IInitialData) => {
    return {
      info: storeData.errorData.info
    };
  };
  const mapDispatchToProps = (dispatch: Function) => {
    return {
      closeInfoModalCallback: (): void => {
        dispatch(closeInfoModal());
      }
    };
  };

  const TranslatedComponent = withTranslation('translation')(presentationComponent);
  return connect(mapStateToProps, mapDispatchToProps)(TranslatedComponent);
};
