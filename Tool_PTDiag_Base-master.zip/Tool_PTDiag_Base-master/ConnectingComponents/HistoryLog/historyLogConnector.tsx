import { connect } from "react-redux";
import { IInitialData } from '../../Datastore/InitialDataInterfaces';
import { getHistorylog, clearHistorylog } from '../../Datastore/ModelData/modelActionCreator';
import { withTranslation } from 'react-i18next';

export const HistoryLogConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    return {
      appInfo: storeData.modelData.appInfo,
      systemInfo: storeData.modelData.systemInfo,
      historyLogEntries: storeData.modelData.historylog,
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      getHistorylog: () => { dispatch(getHistorylog()) },
      clearHistorylog: () => { dispatch(clearHistorylog()) }
    }
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);

  return connect(mapStateToProps, mapDispatchToProps)(TranslatedComponent);
}