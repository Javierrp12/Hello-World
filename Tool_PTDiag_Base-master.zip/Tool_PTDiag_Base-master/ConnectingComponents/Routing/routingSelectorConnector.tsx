import { connect } from "react-redux";
import { updateShowloginStatus, updateUnauthorized } from '../../Datastore/ErrorData/errorActionCreator';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';

export const RoutingSelectorConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    return {
      restart: storeData.stateData.settings.restart,
      option: storeData.stateData.settings.option,
      isAuthenticated: storeData.errorData.isAuthenticated,
      userLevel: storeData.stateData.userlevel,
      showLogin: storeData.errorData.showLogin,
      hostname: storeData.modelData.systemInfo.hostname
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      updateShowloginStatusCallback: () => { dispatch(updateShowloginStatus()) },
      updateUnauthorizedCallback: (data: boolean) => { dispatch(updateUnauthorized(data)) }
    }
  }

  return connect(mapStateToProps, mapDispatchToProps)(presentationComponent);
}