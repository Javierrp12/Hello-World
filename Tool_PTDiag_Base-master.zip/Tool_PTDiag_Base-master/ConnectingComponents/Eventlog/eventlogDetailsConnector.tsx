import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { withTranslation } from 'react-i18next';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';
import { PTDeveloper } from '../../Datastore/StateData/userLevelTypes';
import { EventLog } from '../../Datastore/ModelData/viewTypes';
import { selectedSnapshotIndex, clearSnapshotData } from '../../Datastore/StateData/stateActionCreator';
import { getModuleSignals, maybeA, getModuleSignalsSnapshot } from '../../CommonFunctions/functionsSupport';

export const EventlogDetailsConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    const activeModule = storeData.stateData.activeModule;
    const eventLogEntries = storeData.modelData.eventlog[activeModule];
    const selectedSnapshotIndex = storeData.stateData.selectedSnapshotIndex;
    const snapshotData = storeData.stateData.snapshotData;
    const analogData = getModuleSignalsSnapshot(maybeA(snapshotData.analog).getOrElse({}));
    const digitalData = getModuleSignalsSnapshot(maybeA(snapshotData.digital).getOrElse({}));
    const eventlogItem = maybeA(eventLogEntries[selectedSnapshotIndex]).getOrElse({});
    const digitalModuleSignals = getModuleSignals(storeData.modelData.modulesignals, activeModule, 'digital', PTDeveloper);

    return {
      eventlogItem: eventlogItem || {},
      analogData: analogData,
      digitalData: digitalData,
      digitalModuleSignals: digitalModuleSignals
    }
  }

  const mapDispatchToProps = (dispatch: any) => {
    return {
      detailsCancelCallback: () => {
        dispatch(selectedSnapshotIndex(-1));
        dispatch(clearSnapshotData());
      }
    }
  }

  const mergeProps = (dataProps: any, functionProps: any, ownProps: any) => {
    let routedDispatchers = {
      detailsCancelCallback: () => {
        functionProps.detailsCancelCallback();
        ownProps.history.push(`/${EventLog}`);
      },
    }
    return Object.assign({}, dataProps, routedDispatchers, ownProps);
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);

  return withRouter(connect(mapStateToProps, mapDispatchToProps, mergeProps)(TranslatedComponent));
}