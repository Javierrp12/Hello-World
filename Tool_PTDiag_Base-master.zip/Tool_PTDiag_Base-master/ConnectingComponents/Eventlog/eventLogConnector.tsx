import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { EventLog } from '../../Datastore/ModelData/viewTypes';
import {
  updateHelpActiveList, updateHelpActiveSignal, selectedSnapshotIndex,
  updateSnapshotData, updateModuleActive, updateShowAllModules
} from '../../Datastore/StateData/stateActionCreator';
import { getEventlog, clearEventLog } from '../../Datastore/ModelData/modelActionCreator';
import { Help } from '../../Datastore/ModelData/viewTypes';
import { IInitialData, IEventLogItem } from '../../Datastore/InitialDataInterfaces';
import { HelpListCategories } from '../../Datastore/StateData/helpSystemListTypes';
import { withTranslation } from 'react-i18next';

export interface IDetailsCallback {
  index: number;
  module?: string;
}

export interface ISignalDescriptionCallback {
  list: keyof typeof HelpListCategories;
  signal: string;
  module: string;
}

export const EventLogConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    return {
      activeModule: storeData.stateData.activeModule,
      eventLogEntries: storeData.modelData.eventlog,
      showAllModules: storeData.stateData.eventlog.showAllModules,
      userlevel: storeData.stateData.userlevel
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      getEventlog: () => { dispatch(getEventlog()) },
      clearEventLogCallback: (module: string) => { dispatch(clearEventLog(module)) },
      signalDescriptionCallback: (data: ISignalDescriptionCallback) => {
        dispatch(updateHelpActiveList(data.list));
        dispatch(updateHelpActiveSignal(`${data.module}_${data.signal}`));
      },
      detailsCallback: (data: any) => {
        dispatch(updateModuleActive(data.module));
        dispatch(selectedSnapshotIndex(data.index));
        dispatch(updateSnapshotData({ snapshot: data.snapshot, module: data.module }));
      },
      showAllModulesCallback: () => {
        dispatch(updateShowAllModules());
      }
    }
  }

  const mergeProps = (dataProps: any, functionProps: any, ownProps: any) => {
    let routedDispatchers = {
      signalDescriptionCallback: (data: ISignalDescriptionCallback) => {
        const moduleName = (!data.module) ? dataProps.activeModule : data.module;
        functionProps.signalDescriptionCallback({ ...data, module: moduleName });
        ownProps.history.push(`/${Help}`);
      },
      clearEventLogCallback: () => {
        functionProps.clearEventLogCallback(dataProps.activeModule);
      },
      getEventlog: () => {
        functionProps.getEventlog();
      },
      detailsCallback: (data: IDetailsCallback) => {
        const moduleName = (!data.module) ? dataProps.activeModule : data.module;
        const snapshot = dataProps.eventLogEntries[moduleName].find((item: IEventLogItem) => item.index === data.index).snapshot;
        functionProps.detailsCallback({ ...data, snapshot, module: moduleName });
        ownProps.history.push(`/${EventLog}/details`)
      },
      showAllModulesCallback: () => {
        functionProps.showAllModulesCallback();
      }
    }
    return Object.assign({}, dataProps, routedDispatchers, ownProps);
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);
  return withRouter(connect(mapStateToProps, mapDispatchToProps, mergeProps)(TranslatedComponent));
}