import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { withTranslation } from 'react-i18next';
import { restart } from '../../Datastore/StateData/stateActionCreator';
import { Service, PTService, PTDeveloper } from '../../Datastore/StateData/userLevelTypes';
import { filterPerUserLevel } from '../../CommonFunctions/functionsSupport';
import { filter, safeProp } from '../../CommonFunctions/pointfreeUtilities';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';

const curry = require('folktale/core/lambda/curry');

export interface IOption {
  option: string;
  userlevel: string;
  value: string;
}

export const RestartModalConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    const userlevel: string = storeData.stateData.userlevel;
    const restartOptions: IOption[] = [
      { option: 'Restart App', value: 'restartApp', userlevel: PTDeveloper },
      { option: 'Restart system', value: 'rebootSystem', userlevel: Service },
      { option: 'Stop App', value: 'terminateApp', userlevel: PTService }];

    const filterUserLevel = curry(2, (userlevel: string, option: IOption) => filterPerUserLevel(userlevel, safeProp('userlevel', option).getOrElse('')));
    const filterRestartOptions = filter(filterUserLevel(userlevel));
    return {
      options: filterRestartOptions(restartOptions),
      userlevel: userlevel
    }
  }
  const mapDispatchToProps = (dispatch: Function) => {
    return {
      restartCallback: (option: string) => dispatch(restart(option))
    }
  }

  const mergeProps = (dataProps: any, functionProps: any, ownProps: any) => {
    let routedDispatchers = {
      restartCallback: (option: string) => { functionProps.restartCallback(option); },
    }
    return Object.assign({}, dataProps, routedDispatchers, ownProps);
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);
  return withRouter(connect(mapStateToProps, mapDispatchToProps, mergeProps)(TranslatedComponent));
}