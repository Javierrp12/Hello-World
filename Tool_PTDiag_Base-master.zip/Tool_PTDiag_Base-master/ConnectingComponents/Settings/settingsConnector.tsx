import { connect } from "react-redux";
import { IInitialData } from '../../Datastore/InitialDataInterfaces';
import { getAppInfo, getSystemInfo } from '../../Datastore/ModelData/modelActionCreator';
import { withTranslation } from 'react-i18next';

export const SettingsConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    return {
      systemInfo: storeData.modelData.systemInfo,
      appInfo: storeData.modelData.appInfo,
      userlevel: storeData.stateData.userlevel,
      ptdiagVersion: storeData.stateData.ptdiagVersion,
      year: storeData.stateData.year,
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      getDeviceInformation: () => {
        dispatch(getAppInfo());
        dispatch(getSystemInfo());
      }
    }
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);

  return connect(mapStateToProps, mapDispatchToProps)(TranslatedComponent);
}