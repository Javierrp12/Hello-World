import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { setDateTime, IDateTime } from '../../Datastore/StateData/stateActionCreator';
import { withTranslation } from 'react-i18next';

export const SetDateTimeModalConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: any) => {
    return {}
  }

  const mapDispatchToProps = (dispatch: any) => {
    return {
      setDateTimeCallback: (data: IDateTime) => dispatch(setDateTime(data))
    }
  }

  const mergeProps = (dataProps: any, functionProps: any, ownProps: any) => {
    let routedDispatchers = {
      setDateTimeCallback: (data: any) => { functionProps.setDateTimeCallback(data); },
    }
    return Object.assign({}, dataProps, routedDispatchers, ownProps);
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);

  return withRouter(connect(mapStateToProps, mapDispatchToProps, mergeProps)(TranslatedComponent));
}