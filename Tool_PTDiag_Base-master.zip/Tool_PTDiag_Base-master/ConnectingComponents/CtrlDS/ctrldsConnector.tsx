import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { withTranslation } from 'react-i18next';
import { ViewTypes } from '../../Datastore/ModelData/viewTypes';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';
import {
  updateCategory, updateSelectedItem, updateSelectedItemType, IChangeCategory,
  updateCtrlInfo
} from '../../Datastore/StateData/stateActionCreator';
import { chain, map, sortBy, eq, safeHead } from '../../CommonFunctions/pointfreeUtilities';
import { safeGetKeysObject, safeObjectSearch, safeGetValuesObject } from "../../CommonFunctions/functionsSupport";

const compose = require('folktale/core/lambda/compose');
const identity = require('folktale/core/lambda/identity');

export interface IDataModify {
  name: string;
  type: string;
}

export const CTRLDSConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    const activeModule = storeData.stateData.activeModule;
    const currentCategory = storeData.stateData.ctrlds.currentCategory[activeModule];
    const getCategories = compose(map(sortBy(identity)), chain(safeGetKeysObject));
    const categories = getCategories(safeObjectSearch(`${activeModule}.digital`, storeData.modelData.ctrlds)).getOrElse([]);
    const category = (eq(currentCategory, '')) ? safeHead(categories).getOrElse('') : currentCategory;
    const getDigitalSignalsData = compose(chain(safeGetValuesObject), safeObjectSearch(`${activeModule}.digital.${category}`));
    const getAnalogSignalsData = compose(chain(safeGetValuesObject), safeObjectSearch(`${activeModule}.analog.${category}`));
    const getCtrlInfo = safeObjectSearch(`info.${activeModule}.${category}`);

    return {
      activeModule: activeModule,
      categories: categories,
      category: category,
      digitalData: getDigitalSignalsData(storeData.modelData.ctrlds).getOrElse([]),
      analogData: getAnalogSignalsData(storeData.modelData.ctrlds).getOrElse([]),
      ctrlInfo: getCtrlInfo(storeData.stateData.ctrlds).getOrElse({})
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      updateCtrlInfo: () => dispatch(updateCtrlInfo()),
      categoryChangeCallback: (data: IChangeCategory) => dispatch(updateCategory(ViewTypes.CtrlDS, data)),
      modifyCallback: (data: IDataModify) => {
        dispatch(updateSelectedItem(data.name));
        dispatch(updateSelectedItemType(data.type));
      }
    }
  }

  const mergeProps = (dataProps: any, functionProps: any, ownProps: any) => {
    let routedDispatchers = {
      updateCtrlInfo: () => { functionProps.updateCtrlInfo() },
      categoryChangeCallback: (data: any) => {
        functionProps.categoryChangeCallback({ ...data, module: dataProps.activeModule });
      },
      modifyCallback: (data: any) => {
        functionProps.modifyCallback(data);
      }
    }
    return Object.assign({}, dataProps, routedDispatchers, ownProps);
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);

  return withRouter(connect(mapStateToProps,
    mapDispatchToProps, mergeProps)(TranslatedComponent));
}