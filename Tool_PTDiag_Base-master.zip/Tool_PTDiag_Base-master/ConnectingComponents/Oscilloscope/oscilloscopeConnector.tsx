import { connect } from "react-redux";
import { withTranslation } from 'react-i18next';
import { withRouter } from "react-router-dom";
import { updateSignalType } from '../../Datastore/StateData/stateActionCreator';
import { startStopOscilloscope } from '../../Datastore/ModelData/modelActionCreator';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';

export const OscilloscopeConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    return {
      showingAnalog: storeData.stateData.oscilloscope.showingAnalog,
      showingDigital: storeData.stateData.oscilloscope.showingDigital,
      oscilloscopeData: storeData.modelData.oscilloscope.data,
      analogChannel: storeData.modelData.oscilloscope.Analog,
      digitalChannel: storeData.modelData.oscilloscope.Digital,
      dateTime: storeData.modelData.oscilloscope.date,
      oscilloscopeStatus: storeData.modelData.oscilloscope.running
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      updateSignalType: (type: string) => dispatch(updateSignalType(type)),
      startStopOscilloscope: () => dispatch(startStopOscilloscope())
    }
  }

  const mergeProps = (dataProps: any, functionProps: any, ownProps: any) => {
    let routedDispatchers = {
      updateSignalType: (type: string) => { functionProps.updateSignalType(type) },
      startStopOscilloscope: () => { functionProps.startStopOscilloscope() }
    }
    return Object.assign({}, dataProps, routedDispatchers, ownProps);
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);

  return withRouter(connect(mapStateToProps,
    mapDispatchToProps, mergeProps)(TranslatedComponent));
}