import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { withTranslation } from 'react-i18next';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';
import { Channels } from '../../Datastore/StateData/oscilloscopeChannel';
import { IChannels } from '../../Datastore/InitialDataInterfaces';
import { clearChannel, addChannel } from '../../Datastore/ModelData/modelActionCreator';
import { IClearChannel } from '../../Datastore/ModelData/modelActionCreator';
import { updateShowingScope, IScopeData } from '../../Datastore/StateData/stateActionCreator';
import { safeHead, prop, safeProp, toLowerCase } from '../../CommonFunctions/pointfreeUtilities';
import { safeGetKeysObject, safeGetValuesObject, getModuleSignals, alt } from '../../CommonFunctions/functionsSupport';

export const SignalSelectionConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    const userlevel = storeData.stateData.userlevel;
    const signalType = safeProp('signalType', storeData.stateData.oscilloscope).getOrElse('');
    const modulesData = storeData.modelData.modulesignals;
    const modules = safeGetKeysObject(modulesData).getOrElse([]);
    const getChannelData = safeProp(signalType);
    const channelsData = getChannelData(storeData.modelData.oscilloscope).getOrElse({});
    const module = safeProp('module', safeProp('Ch1', channelsData).getOrElse({})).getOrElse(safeHead(modules).getOrElse(''));
    const signalData = safeHead(getModuleSignals(modulesData, module, toLowerCase(signalType), userlevel)).getOrElse({});
    const getSignal = safeProp('Ch1');
    const signalSelected = getSignal(channelsData).getOrElse(signalData);
    const getSignalName = alt(prop('name'), prop('signal'));
    const channelStatus = (prop('Ch1', channelsData)) ? true : false;
    const oscilloscopeChannels = safeGetValuesObject(Channels).getOrElse([]);

    return {
      signalType: signalType,
      channels: oscilloscopeChannels,
      modules: modules,
      modulesData: modulesData,
      channelsData: channelsData,
      module: module,
      signal: `${safeProp('category', signalSelected).getOrElse('')}_${getSignalName(signalSelected)}`,
      channel: safeHead(oscilloscopeChannels).getOrElse('Ch1'),
      channelStatus: channelStatus,
      userlevel: userlevel
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      clearChannel: (channelData: IClearChannel) => { dispatch(clearChannel(channelData)) },
      addChannel: (type: string, channelData: IChannels) => { dispatch(addChannel(type, channelData)) },
      updateShowingScope: (data: IScopeData) => { dispatch(updateShowingScope(data)); }
    }
  }

  const mergeProps = (dataProps: any, functionProps: any, ownProps: any) => {
    let routedDispatchers = {
      clearChannel: (data: any) => { functionProps.clearChannel(data); },
      addChannel: (type: string, channelData: IChannels) => { functionProps.addChannel(type, channelData); },
      updateShowingScope: (data: IScopeData) => { functionProps.updateShowingScope(data) }
    }
    return Object.assign({}, dataProps, routedDispatchers, ownProps);
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);

  return withRouter(connect(mapStateToProps,
    mapDispatchToProps, mergeProps)(TranslatedComponent));
}