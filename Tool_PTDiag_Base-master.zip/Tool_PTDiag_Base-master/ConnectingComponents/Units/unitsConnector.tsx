import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { withTranslation } from 'react-i18next';
import { ViewTypes } from '../../Datastore/ModelData/viewTypes';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';
import {
  updateCategory, updateParameterUnitsInfo, saveParametersUnits,
  factorySettingsUnitsCallback, IChangeCategory, changeParameterTemporarily, resetParameterTemporarily
} from '../../Datastore/StateData/stateActionCreator';
import { IParameterData } from '../../Datastore/StateData/stateActionCreator';
import { chain, map, sortBy, eq, safeHead, filter, safeProp } from '../../CommonFunctions/pointfreeUtilities';
import { safeGetKeysObject, safeObjectSearch, safeGetValuesObject, eq3 } from "../../CommonFunctions/functionsSupport";
import { toLowerCase } from '../../CommonFunctions/pointfreeUtilities';

const compose = require('folktale/core/lambda/compose');

export interface IParametersDataModify {
  parameter: string;
  value?: string;
}

export const UnitsConnector = (presentationComponent: any) => {
  const mapStateToProps = (storeData: IInitialData) => {
    const activeModule = storeData.stateData.activeModule;
    const currentCategory = storeData.stateData.units.currentCategory[activeModule];
    const getCategories = compose(map(sortBy(toLowerCase)), chain(safeGetKeysObject));
    const categories = getCategories(safeObjectSearch(`${activeModule}`, storeData.modelData.units)).getOrElse([]);
    const category = (eq(currentCategory, '')) ? safeHead(categories).getOrElse('') : currentCategory;
    const getUnitsData = compose(chain(safeGetValuesObject), safeObjectSearch(`${activeModule}.${category}`));
    const getParameterInfo = compose(chain(safeProp('units')), compose(chain(safeHead), compose(map(filter(eq3(category, 'name'))), safeObjectSearch(`info.${activeModule}`))));

    return {
      activeModule: activeModule,
      unitsData: getUnitsData(storeData.modelData.units).getOrElse([]),
      categories: categories,
      category: category,
      parameterInfoData: getParameterInfo(storeData.stateData.units).getOrElse([])
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      updateParameterUnitsInfo: () => dispatch(updateParameterUnitsInfo()),
      categoryChangeCallback: (data: IChangeCategory) => dispatch(updateCategory(ViewTypes.Units, data)),
      saveParametersUnits: (module: string) => dispatch(saveParametersUnits(module)),
      factorySettingsUnitsCallback: (module: string) => dispatch(factorySettingsUnitsCallback(module)),
      changeParameterCallback: (data: IParameterData) => dispatch(changeParameterTemporarily(ViewTypes.Units, data)),
      resetParameterCallback: (data: IParameterData) => (dispatch(resetParameterTemporarily(ViewTypes.Units, data))),
    }
  }

  const mergeProps = (dataProps: any, functionProps: any, ownProps: any) => {
    let routedDispatchers = {
      updateParameterUnitsInfo: () => { functionProps.updateParameterUnitsInfo() },
      saveParametersUnits: () => { functionProps.saveParametersUnits(dataProps.activeModule) },
      factorySettingsUnitsCallback: () => { functionProps.factorySettingsUnitsCallback(dataProps.activeModule) },
      categoryChangeCallback: (data: any) => {
        functionProps.categoryChangeCallback({ ...data, module: dataProps.activeModule });
      },
      changeParameterCallback: (data: IParametersDataModify) => {
        functionProps.changeParameterCallback({ ...data, module: dataProps.activeModule, category: dataProps.category });
      },
      resetParameterCallback: (data: IParametersDataModify) => {
        functionProps.resetParameterCallback({ ...data, module: dataProps.activeModule, category: dataProps.category });
      }
    }
    return Object.assign({}, dataProps, routedDispatchers, ownProps);
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);

  return withRouter(connect(mapStateToProps,
    mapDispatchToProps, mergeProps)(TranslatedComponent));
}