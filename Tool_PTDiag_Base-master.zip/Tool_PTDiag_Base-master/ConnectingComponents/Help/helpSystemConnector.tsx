import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { updateHelpActiveList, updateHelpActiveSignal } from '../../Datastore/StateData/stateActionCreator';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';
import { HelpListCategories } from '../../Datastore/StateData/helpSystemListTypes';
import { chain, safeProp, filter, map, safeHead } from '../../CommonFunctions/pointfreeUtilities';
import { eq3 } from '../../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

export const HelpSystemConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    const activeList = storeData.stateData.help.activeList;
    const getSignalTypeSignal = compose(map(filter(eq3(activeList, 'type'))), safeProp('signalsData'));
    const getFirstHelpSignal = compose(chain(safeHead), getSignalTypeSignal);
    const firstHelpSignal = getFirstHelpSignal(storeData.modelData.help).getOrElse({});
    const activeSignals = getSignalTypeSignal(storeData.modelData.help).getOrElse([]);
    const activeSignal = ((activeSignals.length > 0) && (storeData.stateData.help.activeSignal === '')) ? `${safeProp('module', firstHelpSignal).getOrElse('')}_${safeProp('name', firstHelpSignal).getOrElse('')}` : storeData.stateData.help.activeSignal;

    return {
      signalsData: activeSignals,
      possibleCauses: storeData.modelData.help.possibleCauses,
      correctiveActions: storeData.modelData.help.correctiveActions,
      activeList: activeList,
      activeSignal: activeSignal,
    }
  }

  const mapDispatchToProps = (dispatch: Function) => ({
    changeSignalCallback: (data: string) => dispatch(updateHelpActiveSignal(data)),
    changeListCallback: (data: keyof typeof HelpListCategories) => {
      dispatch(updateHelpActiveList(data));
      dispatch(updateHelpActiveSignal(""));
    }
  });

  const TranslatedComponent = withTranslation('translation')(presentationComponent);

  return connect(mapStateToProps, mapDispatchToProps)(TranslatedComponent);
}