import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { ViewTypes } from '../../Datastore/ModelData/viewTypes';
import { forceSignal, updateSelectedItem, updateSelectedItemType } from '../../Datastore/StateData/stateActionCreator';
import { chain, map, sortBy, eq, safeHead, safeProp } from '../../CommonFunctions/pointfreeUtilities';
import { safeGetKeysObject, safeObjectSearch } from "../../CommonFunctions/functionsSupport";

const compose = require('folktale/core/lambda/compose');
const identity = require('folktale/core/lambda/identity');

export const ModifySignalConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: any) => {
    const activeModule = storeData.stateData.activeModule;
    const currentCategory = storeData.stateData[ViewTypes.CtrlDS].currentCategory[activeModule];
    const selectedItemType = storeData.stateData.selectedItemType;
    const getCategories = compose(map(sortBy(identity)), chain(safeGetKeysObject));
    const categories = getCategories(safeObjectSearch(`${activeModule}.${selectedItemType}`, storeData.modelData.ctrlds)).getOrElse([]);
    const category = (eq(currentCategory, '')) ? safeHead(categories).getOrElse('') : currentCategory;
    const selectedItem = storeData.stateData.selectedItem;
    const getItemData = safeObjectSearch(`${activeModule}.${selectedItemType}.${category}.${selectedItem}`);
    const itemData = getItemData(storeData.modelData.ctrlds).getOrElse({});
    const getCtrlInfo = safeObjectSearch(`info.${activeModule}.${category}`);
    const ctrlInfo = getCtrlInfo(storeData.stateData.ctrlds).getOrElse({})

    return {
      activeModule: activeModule,
      category: category,
      signalDataDigital: (selectedItemType === "digital") ? ({ ...itemData, status: safeProp(selectedItem, ctrlInfo).getOrElse(false) }) : {},
      signalDataAnalog: (selectedItemType === "analog") ? ({ ...itemData, value: safeProp(selectedItem, ctrlInfo).getOrElse(0) }) : {},
      signalType: selectedItemType
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      forceSignalCallback: (data: any) => {
        dispatch(forceSignal(ViewTypes.CtrlDS, data));
        dispatch(updateSelectedItem(''));
        dispatch(updateSelectedItemType('analog'));
      },
      cancelCallback: () => {
        dispatch(updateSelectedItem(''));
        dispatch(updateSelectedItemType('analog'));
      }
    }
  }

  const mergeProps = (dataProps: any, functionProps: any, ownProps: any) => {
    let routedDispatchers = {
      forceSignalCallback: (data: any) => {
        functionProps.forceSignalCallback({ ...data, module: dataProps.activeModule, category: dataProps.category, type: dataProps.signalType });
      },
      cancelCallback: () => {
        functionProps.cancelCallback();
      }
    }
    return Object.assign({}, dataProps, routedDispatchers, ownProps);
  }

  return withRouter(connect(mapStateToProps,
    mapDispatchToProps, mergeProps)(presentationComponent));
}