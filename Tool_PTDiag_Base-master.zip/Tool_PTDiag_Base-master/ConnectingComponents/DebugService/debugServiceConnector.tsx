import { connect } from "react-redux";
import { withTranslation } from 'react-i18next';
import { withRouter } from "react-router-dom";
import { updateDebugInfo, setCommandDebug } from '../../Datastore/StateData/stateActionCreator';
import { getDebugMessages, clearDebugMessages } from '../../Datastore/ModelData/modelActionCreator';
import { IDebugCommand } from '../../Datastore/StateData/stateActionCreator';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';

export const DebugServiceConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {
    const activeModule = storeData.stateData.activeModule;
    return {
      activeModule: activeModule,
      debugStatus: storeData.stateData.debugservice.modulesStates[activeModule],
      flagsStatus: storeData.stateData.debugservice.flags,
      levelStatus: storeData.stateData.debugservice.levels,
      debugMessages: storeData.modelData.debugservice[activeModule]
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      updateDebugInfo: () => dispatch(updateDebugInfo()),
      getDebugMessages: () => dispatch(getDebugMessages()),
      setCommandDebug: (data: IDebugCommand) => dispatch(setCommandDebug(data)),
      clearDebugMessages: (data: string) => dispatch(clearDebugMessages(data))
    }
  }

  const mergeProps = (dataProps: any, functionProps: any, ownProps: any) => {
    let routedDispatchers = {
      updateDebugInfo: () => { functionProps.updateDebugInfo() },
      getDebugMessages: () => { functionProps.getDebugMessages() },
      setCommandDebug: (data: any) => { functionProps.setCommandDebug({ ...data, module: dataProps.activeModule }) },
      clearDebugMessages: () => { functionProps.clearDebugMessages(dataProps.activeModule) }
    }
    return Object.assign({}, dataProps, routedDispatchers, ownProps);
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);

  return withRouter(connect(mapStateToProps,
    mapDispatchToProps, mergeProps)(TranslatedComponent));
}