import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
import { IInitialData } from '../../Datastore/InitialDataInterfaces';
import { setCounter } from '../../Datastore/ModelData/modelActionCreator';

export interface ICounterUpdateData {
  counter: string;
  value?: string;
}

export const SystemCountersConnector = (presentationComponent: any) => {

  const mapStateToProps = (storeData: IInitialData) => {

    return {
      countersData: storeData.modelData.systemcounters.counters,
      accessLevel: storeData.modelData.systemcounters.accessLevel,
      userlevel: storeData.stateData.userlevel
    }
  }

  const mapDispatchToProps = (dispatch: Function) => {
    return {
      updateCounterCallback: (data: ICounterUpdateData) => dispatch(setCounter(data)),
    }
  }

  const TranslatedComponent = withTranslation('translation')(presentationComponent);

  return connect(mapStateToProps,
    mapDispatchToProps)(TranslatedComponent);
}