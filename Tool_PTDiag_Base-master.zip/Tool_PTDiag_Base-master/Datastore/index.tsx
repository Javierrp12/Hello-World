import { createStore, combineReducers, compose, applyMiddleware } from "redux";
import { createRestMiddleware } from '../WebServices/restMiddleware';
import modelReducer from './ModelData/modelReducer';
import stateReducer from './StateData/stateReducer';
import errorReducer from './ErrorData/errorReducer';

export default createStore(combineReducers({
  modelData: modelReducer,
  stateData: stateReducer,
  errorData: errorReducer,
}), compose(applyMiddleware(createRestMiddleware)));