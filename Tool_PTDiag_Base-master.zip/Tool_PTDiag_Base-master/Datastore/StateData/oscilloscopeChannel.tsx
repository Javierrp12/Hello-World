export const Channels = {
  Ch1: 'Ch1',
  Ch2: 'Ch2',
  Ch3: 'Ch3',
  Ch4: 'Ch4',
  Ch5: 'Ch5',
  Ch6: 'Ch6',
  Ch7: 'Ch7',
  Ch8: 'Ch8'
}

export const Ch1 = 'Ch1';
export const Ch2 = 'Ch2';
export const Ch3 = 'Ch3';
export const Ch4 = 'Ch4';
export const Ch5 = 'Ch5';
export const Ch6 = 'Ch6';
export const Ch7 = 'Ch7';
export const Ch8 = 'Ch8';