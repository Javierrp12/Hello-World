export const Default = 'Default';
export const Service = 'Service';
export const PTService = 'PTService';
export const PTDeveloper = 'PTDeveloper';