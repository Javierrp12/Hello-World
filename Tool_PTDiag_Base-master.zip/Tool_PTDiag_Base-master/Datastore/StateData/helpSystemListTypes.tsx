export const HelpListCategories = {
  digital: 'digital',
  analog: 'analog'
}

export const digital = 'digital';
export const analog = 'analog';
