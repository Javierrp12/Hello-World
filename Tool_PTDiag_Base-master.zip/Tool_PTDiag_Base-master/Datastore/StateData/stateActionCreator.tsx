import { ViewTypes } from '../ModelData/viewTypes';
import { IAction } from '../InitialDataInterfaces';
import {
  UPDATE_ACTIVE_MODULE, UPDATE_DATASTORE, UPDATE_CATEGORY, UPDATE_SHOW_INACTIVE_SIGNALS,
  UPDATE_HELP_ACTIVE_LIST, UPDATE_HELP_ACTIVE_SIGNAL, UPDATE_SELECTED_ITEM, UPDATE_SELECTED_ITEM_TYPE,
  FORCE_SIGNAL, UPDATE_PARAMETER_TEMPORARY, UPDATE_SELECTED_SNAPSHOT, UPDATE_SNAPSHOT_DATA,
  CLEAR_SNAPSHOT_DATA, UPDATE_CTRL_INFO, UPDATE_FORCE_INFO, UPDATE_PARAMETER_INFO,
  UPDATE_PARAMETERUNITS_INFO, FACTORY_SETTINGS_PARAMETERS, SAVE_PARAMETERS, SAVE_PARAMETERS_UNITS,
  FACTORY_SETTINGS_PARAMETERS_UNITS, RESET_PARAMETER_TEMPORARY, GET_DATE_TIME, GET_USER_LEVEL,
  SET_DATE_TIME, UPDATE_DEBUG_INFO, SET_COMMAND_DEBUG, UPDATE_SIGNAL_TYPE, UPDATE_SCOPE_STATUS_OSCILLOSCOPE,
  UPDATE_PARAMETER_FILE_TEMPORARY, UPDATE_SHOW_ALL_MODULES, UPDATE_SOFTWARE_PROCESS_STATUS,
  START_UNPACK_CHECK, UNPACK_PROGRESS, START_UPDATE_PROCESS, GET_UPDATER_PORT, RESTART, CHECK_UPDATER
} from './stateActionTypes';
import { HelpListCategories } from './helpSystemListTypes';
import { Modules } from '../ModelData/modulesTypes';

export interface IChangeCategory {
  module: string;
  category: string;
}

export interface IChangeDatastore {
  module: string;
  datastore: string;
}

export interface IForceSignalData {
  module: string;
  category: string;
  name: string;
  value: number | boolean | undefined;
  type: string;
  datastore: string;
  command: string;
}

export interface IForceCTRLSignalData {
  module: string;
  category: string;
  name: string;
  value: number | boolean;
  type: string;
}

export interface IParameterData {
  module: string;
  category: string;
  parameter: string;
  value: string;
}

export interface IParameterDataFile {
  module: string;
  category: string;
  parameter: string;
  value: number | boolean;
}

export interface IDateTime {
  date: string;
  time: string;
}

export interface IDebugCommand {
  module: string;
  command: string;
  level?: string;
}

export interface IScopeData {
  scope: string;
  value: boolean;
}

export interface ISoftwareUpdate {
  process: string,
  uploadFile: boolean,
  validFile: boolean
}

export interface IUpdateFlags {
  forceUpdating: string;
  ignoreUpdating: string;
}

export const updateModuleActive = (module: keyof typeof Modules): IAction => {
  return {
    type: UPDATE_ACTIVE_MODULE,
    dataType: "",
    payload: module
  }
}

export const updateCategory = (dataType: string, categoryData: IChangeCategory): IAction => {
  return {
    type: UPDATE_CATEGORY,
    dataType: dataType,
    payload: categoryData
  }
}

export const updateDataStore = (dataType: string, datastoreData: IChangeDatastore): IAction => {
  return {
    type: UPDATE_DATASTORE,
    dataType: dataType,
    payload: datastoreData
  }
}

export const updateShowInactiveSignals = (): IAction => {
  return {
    type: UPDATE_SHOW_INACTIVE_SIGNALS,
    dataType: "",
  }
}

export const updateHelpActiveList = (newActiveSignal: keyof typeof HelpListCategories): IAction => {
  return {
    type: UPDATE_HELP_ACTIVE_LIST,
    dataType: ViewTypes.Help,
    payload: newActiveSignal
  }
}

export const updateHelpActiveSignal = (newActiveSignal: string): IAction => {
  return {
    type: UPDATE_HELP_ACTIVE_SIGNAL,
    dataType: ViewTypes.Help,
    payload: newActiveSignal
  }
}

export const updateSelectedItem = (itemName: string): IAction => {
  return {
    type: UPDATE_SELECTED_ITEM,
    dataType: "",
    payload: itemName
  }
}

export const updateSelectedItemType = (itemType: string): IAction => {
  return {
    type: UPDATE_SELECTED_ITEM_TYPE,
    dataType: "",
    payload: itemType
  }
}

export const forceSignal = (dataType: string, signalData: IForceSignalData): IAction => {
  return {
    type: FORCE_SIGNAL,
    dataType: dataType,
    payload: signalData
  }
}

export const changeParameterTemporarily = (dataType: string, parameterData: IParameterData): IAction => {
  return {
    type: UPDATE_PARAMETER_TEMPORARY,
    dataType: dataType,
    payload: parameterData
  }
}

export const resetParameterTemporarily = (dataType: string, parameterData: IParameterData): IAction => {
  return {
    type: RESET_PARAMETER_TEMPORARY,
    dataType: dataType,
    payload: parameterData
  }
}

export const selectedSnapshotIndex = (index: number): IAction => {
  return {
    type: UPDATE_SELECTED_SNAPSHOT,
    dataType: "",
    payload: index
  }
}

export const updateSnapshotData = (snapshotData: any): IAction => {
  return {
    type: UPDATE_SNAPSHOT_DATA,
    dataType: "",
    payload: snapshotData
  }
}

export const clearSnapshotData = (): IAction => {
  return {
    type: CLEAR_SNAPSHOT_DATA,
    dataType: "",
  }
}

export const updateCtrlInfo = (): IAction => {
  return {
    type: UPDATE_CTRL_INFO,
    dataType: "",
  }
}

export const updateForceInfo = (): IAction => {
  return {
    type: UPDATE_FORCE_INFO,
    dataType: "",
  }
}

export const updateParameterInfo = (): IAction => {
  return {
    type: UPDATE_PARAMETER_INFO,
    dataType: "",
  }
}

export const updateParameterUnitsInfo = (): IAction => {
  return {
    type: UPDATE_PARAMETERUNITS_INFO,
    dataType: "",
  }
}

export const saveParameters = (module: string): IAction => {
  return {
    type: SAVE_PARAMETERS,
    dataType: "",
    payload: module
  }
}

export const saveParametersUnits = (module: string): IAction => {
  return {
    type: SAVE_PARAMETERS_UNITS,
    dataType: "",
    payload: module
  }
}

export const restoreToFactorySettings = (module: string): IAction => {
  return {
    type: FACTORY_SETTINGS_PARAMETERS,
    dataType: "",
    payload: module
  }
}

export const factorySettingsUnitsCallback = (module: string): IAction => {
  return {
    type: FACTORY_SETTINGS_PARAMETERS_UNITS,
    dataType: "",
    payload: module
  }
}

export const setDateTime = (data: IDateTime): IAction => {
  return {
    type: SET_DATE_TIME,
    dataType: "",
    payload: data
  }
}

export const getDateTime = (): IAction => {
  return {
    type: GET_DATE_TIME,
    dataType: "",
  }
}

export const getUserLevel = (): IAction => {
  return {
    type: GET_USER_LEVEL,
    dataType: "",
  }
}

export const updateDebugInfo = (): IAction => {
  return {
    type: UPDATE_DEBUG_INFO,
    dataType: "",
  }
}

export const setCommandDebug = (data: IDebugCommand): IAction => {
  return {
    type: SET_COMMAND_DEBUG,
    dataType: "",
    payload: data
  }
}

export const updateSignalType = (type: string): IAction => {
  return {
    type: UPDATE_SIGNAL_TYPE,
    dataType: ViewTypes.Oscilloscope,
    payload: type
  }
}

export const updateShowingScope = (flagsData: IScopeData): IAction => {
  return {
    type: UPDATE_SCOPE_STATUS_OSCILLOSCOPE,
    dataType: ViewTypes.Oscilloscope,
    payload: flagsData
  }
}

export const changeTemporalyFile = (parametersfile: IParameterDataFile[]): IAction => {
  return {
    type: UPDATE_PARAMETER_FILE_TEMPORARY,
    dataType: "",
    payload: parametersfile
  }
}

export const updateShowAllModules = (): IAction => {
  return {
    type: UPDATE_SHOW_ALL_MODULES,
    dataType: ViewTypes.EventLog
  }
}

export const updateUpdateProcessStatus = (data: ISoftwareUpdate): IAction => {
  return {
    type: UPDATE_SOFTWARE_PROCESS_STATUS,
    dataType: ViewTypes.SoftwareUpdate,
    payload: data
  }
}

export const startUnpackCheck = (): IAction => {
  return {
    type: START_UNPACK_CHECK,
    dataType: "",
  }
}

export const getUnpackProgress = (): IAction => {
  return {
    type: UNPACK_PROGRESS,
    dataType: "",
  }
}

export const startUpdateProcess = (data: IUpdateFlags): IAction => {
  return {
    type: START_UPDATE_PROCESS,
    dataType: "",
    payload: data
  }
}

export const getUpdaterPort = (): IAction => {
  return {
    type: GET_UPDATER_PORT,
    dataType: "",
  }
}

export const checkUpdaterStatus = (): IAction => {
  return {
    type: CHECK_UPDATER,
    dataType: "",
  }
}

export const restart = (option: string): IAction => {
  return {
    type: RESTART,
    dataType: "",
    payload: option
  }
}