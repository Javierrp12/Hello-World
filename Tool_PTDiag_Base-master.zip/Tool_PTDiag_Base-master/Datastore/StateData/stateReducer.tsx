import { InitialData } from '../initialData';
import { IStateData } from '../InitialDataInterfaces';
import {
  UPDATE_ACTIVE_MODULE, UPDATE_DATASTORE, UPDATE_CATEGORY, UPDATE_SHOW_INACTIVE_SIGNALS,
  UPDATE_SELECTED_ITEM, UPDATE_SELECTED_ITEM_TYPE, UPDATE_HELP_ACTIVE_LIST, UPDATE_HELP_ACTIVE_SIGNAL,
  UPDATE_MODULES_STATE, UPDATE_SELECTED_SNAPSHOT, UPDATE_SNAPSHOT_DATA, CLEAR_SNAPSHOT_DATA,
  UPDATE_INFO, UPDATE_DATE_TIME_USER, RESTART, UPDATE_SIGNAL_TYPE,
  UPDATE_SCOPE_STATUS_OSCILLOSCOPE, UPDATE_SHOW_ALL_MODULES
} from './stateActionTypes';
import { prop } from '../../CommonFunctions/pointfreeUtilities';
import { IAction } from '../InitialDataInterfaces';

export default function (storeData: IStateData, action: IAction) {
  switch (action.type) {
    case UPDATE_ACTIVE_MODULE:
      return {
        ...storeData,
        activeModule: action.payload
      }

    case UPDATE_MODULES_STATE:
      return {
        ...storeData,
        modulesState: {
          ...storeData.modulesState,
          [action.payload.module]: action.payload.state
        }
      }

    case UPDATE_DATASTORE:
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          currentDatastore: {
            ...prop(action.dataType, storeData).currentDatastore,
            [action.payload.module]: action.payload.datastore
          }
        }
      }

    case UPDATE_CATEGORY:
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          currentCategory: {
            ...prop(action.dataType, storeData).currentCategory,
            [action.payload.module]: action.payload.category
          }
        }
      }

    case UPDATE_SELECTED_ITEM:
      return {
        ...storeData,
        selectedItem: action.payload
      }

    case UPDATE_SELECTED_ITEM_TYPE:
      return {
        ...storeData,
        selectedItemType: action.payload
      }

    case UPDATE_SHOW_INACTIVE_SIGNALS:
      return {
        ...storeData,
        showOnlyActiveSignals: !storeData.showOnlyActiveSignals
      }

    case UPDATE_HELP_ACTIVE_LIST:
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          activeList: action.payload
        }
      }

    case UPDATE_HELP_ACTIVE_SIGNAL:
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          activeSignal: action.payload
        }
      }

    case UPDATE_SELECTED_SNAPSHOT:
      return {
        ...storeData,
        selectedSnapshotIndex: action.payload
      }

    case UPDATE_SNAPSHOT_DATA:
      return {
        ...storeData,
        snapshotData: action.payload
      }

    case CLEAR_SNAPSHOT_DATA:
      return {
        ...storeData,
        snapshotData: { analog: {}, digital: {} }
      }

    case UPDATE_INFO:
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          info: {
            ...prop(action.dataType, storeData).info,
            [action.payload.module]: action.payload.data
          }
        }
      }

    case RESTART:
      return {
        ...storeData,
        [action.dataType]: {
          restart: action.payload.restart,
          option: action.payload.option
        }
      }

    case UPDATE_DATE_TIME_USER:
      return {
        ...storeData,
        [action.dataType]: action.payload
      }

    case UPDATE_SIGNAL_TYPE:
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          signalType: action.payload
        }
      }

    case UPDATE_SCOPE_STATUS_OSCILLOSCOPE:
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          [action.payload.scope]: action.payload.value
        }
      }

    case UPDATE_SHOW_ALL_MODULES:
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          showAllModules: !prop(action.dataType, storeData).showAllModules
        }
      }

    default:
      return storeData || InitialData.stateData;
  }
}