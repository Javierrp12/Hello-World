import { ViewTypes } from './viewTypes';
import {
  CREATE_MODULE_DATA, UPDATE_SYSTEM_CONFIG_DATA, UPDATE_UNITS_DATA, GET_APP_INFO,
  GET_SYSTEM_INFO, GET_ONLINE_DATA, GET_EVENTLOG_DATA, GET_HISTORYLOG_DATA, CLEAR_EVENTLOG_DATA,
  LOG_OUT, GET_DEBUG_MSG, CLEAR_DEBUG_MSG, CLEAR_HISTORYLOG_DATA, CLEAR_CHANNEL_OSCILLOSCOPE,
  ADD_CHANNEL_OSCILLOSCOPE, UPDATE_STATUS_OSCILLOSCOPE, UPDATE_ANALOGVALUE_POSITION,
  UPDATE_DIGITALVALUE_POSITION, UPDATE_COMPONENT_POSITION, ADD_COMPONENT, DELETE_COMPONENT,
  DELETE_ANALOGVALUE, DELETE_DIGITALFLAG, UPDATE_EDIT_MODE_STATUS, UPDATE_COMPONENT_SIZE,
  SEND_PACKAGE, UPDATE_SOFTWARE_UPDATE_DATA, SET_COUNTER
} from './modelActionTypes';
import { IAction, IChannels } from '../InitialDataInterfaces';

export interface IClearChannel {
  type: string,
  channel: string
}

export interface ISignalsData {
  module: string,
  data: any
}

export interface IAnalogData {
  component: string;
  module: string;
  datastore: string;
  category: string;
  name: string;
  xPosition: number;
  yPosition: number;
}

export interface IDeleteAnalogData {
  component: string;
  module: string;
  name: string;
}

export interface IDigitalData {
  component: string;
  module: string;
  datastore: string;
  category: string;
  name: string;
  xPosition: number;
  yPosition: number;
}

export interface IDeleteDigitalData {
  component: string;
  module: string;
  name: string;
}

export interface IComponentData {
  component: string;
  key: string;
  xPosition: number;
  yPosition: number;
}

export interface IComponentSize {
  component: string;
  key: string;
  height: number;
  width: number;
}

export interface IDeleteComponentData {
  component: string;
  key: string;
}

interface ISoftwareUpdateData {
  propertyName: string,
  value: string
}

interface ICounterUpdateData {
  counter: string;
  value?: string;
}

export const createModulesData = (signalsData: ISignalsData): IAction => {
  return {
    type: CREATE_MODULE_DATA,
    dataType: ViewTypes.ModuleSignals,
    payload: signalsData
  }
}

export const updateUnitsData = (): IAction => {
  return {
    type: UPDATE_UNITS_DATA,
    dataType: "",
  }
}

export const updateSytemConfigData = (): IAction => {
  return {
    type: UPDATE_SYSTEM_CONFIG_DATA,
    dataType: "",
  }
}

export const getAppInfo = (): IAction => {
  return {
    type: GET_APP_INFO,
    dataType: "",
  }
}

export const getSystemInfo = (): IAction => {
  return {
    type: GET_SYSTEM_INFO,
    dataType: "",
  }
}

export const logoutRequest = (): IAction => {
  return {
    type: LOG_OUT,
    dataType: "",
  }
}

export const getOnlineData = (): IAction => {
  return {
    type: GET_ONLINE_DATA,
    dataType: "",
  }
}

export const getEventlog = (): IAction => {
  return {
    type: GET_EVENTLOG_DATA,
    dataType: "",
  }
}

export const getHistorylog = (): IAction => {
  return {
    type: GET_HISTORYLOG_DATA,
    dataType: "",
  }
}

export const clearHistorylog = (): IAction => {
  return {
    type: CLEAR_HISTORYLOG_DATA,
    dataType: "",
  }
}

export const clearEventLog = (module: string): IAction => {
  return {
    type: CLEAR_EVENTLOG_DATA,
    dataType: "",
    payload: module
  }
}

export const getDebugMessages = (): IAction => {
  return {
    type: GET_DEBUG_MSG,
    dataType: "",
  }
}

export const clearDebugMessages = (module: string): IAction => {
  return {
    type: CLEAR_DEBUG_MSG,
    dataType: ViewTypes.DebugService,
    payload: module
  }
}

export const clearChannel = (channelData: IClearChannel): IAction => {
  return {
    type: CLEAR_CHANNEL_OSCILLOSCOPE,
    dataType: ViewTypes.Oscilloscope,
    payload: channelData
  }
}

export const addChannel = (type: string, channelData: IChannels): IAction => {
  return {
    type: ADD_CHANNEL_OSCILLOSCOPE,
    dataType: ViewTypes.Oscilloscope,
    payload: { type, channelData }
  }
}

export const startStopOscilloscope = (): IAction => {
  return {
    type: UPDATE_STATUS_OSCILLOSCOPE,
    dataType: ViewTypes.Oscilloscope
  }
}

export const updateAnalogValuePosition = (analogData: IAnalogData): IAction => {
  return {
    type: UPDATE_ANALOGVALUE_POSITION,
    dataType: ViewTypes.SystemOverview,
    payload: analogData
  }
}

export const updateDigitalFlagPosition = (digitalData: IDigitalData): IAction => {
  return {
    type: UPDATE_DIGITALVALUE_POSITION,
    dataType: ViewTypes.SystemOverview,
    payload: digitalData
  }
}

export const deleteAnalogValue = (analogData: IDeleteAnalogData) => {
  return {
    type: DELETE_ANALOGVALUE,
    dataType: ViewTypes.SystemOverview,
    payload: analogData
  }
}

export const deleteDigitalValue = (digitalData: IDeleteDigitalData): IAction => {
  return {
    type: DELETE_DIGITALFLAG,
    dataType: ViewTypes.SystemOverview,
    payload: digitalData
  }
}

export const updateComponentPosition = (componentData: IComponentData): IAction => {
  return {
    type: UPDATE_COMPONENT_POSITION,
    dataType: ViewTypes.SystemOverview,
    payload: componentData
  }
}

export const updateComponentSize = (componentData: IComponentSize): IAction => {
  return {
    type: UPDATE_COMPONENT_SIZE,
    dataType: ViewTypes.SystemOverview,
    payload: componentData
  }
}

export const deleteComponent = (componentData: IDeleteComponentData): IAction => {
  return {
    type: DELETE_COMPONENT,
    dataType: ViewTypes.SystemOverview,
    payload: componentData
  }
}

export const addComponentToSchematic = (componentData: any): IAction => {
  return {
    type: ADD_COMPONENT,
    dataType: ViewTypes.SystemOverview,
    payload: componentData
  }
}

export const updateEditMode = (): IAction => {
  return {
    type: UPDATE_EDIT_MODE_STATUS,
    dataType: ViewTypes.SystemOverview,
  }
}

export const sendPackageCallback = (file: File): IAction => {
  return {
    type: SEND_PACKAGE,
    dataType: "",
    payload: file
  }
}

export const updateSoftwareUpdateData = (data: ISoftwareUpdateData): IAction => {
  return {
    type: UPDATE_SOFTWARE_UPDATE_DATA,
    dataType: ViewTypes.SoftwareUpdate,
    payload: data
  }
}

export const setCounter = (data: ICounterUpdateData): IAction => {
  return {
    type: SET_COUNTER,
    dataType: "",
    payload: data
  }
}