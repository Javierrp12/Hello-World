import { InitialData } from '../initialData';
import {
  CREATE_MODULE_DATA, CREATE_PROJECT_DATA, UPDATE_COMPONENT_DATA, UPDATE_ANALOG_VALUES,
  UPDATE_DIGITAL_FLAGS, UPDATE_OSCILLOSCOPE_VALUES, CLEAR_CHANNEL_OSCILLOSCOPE, ADD_CHANNEL_OSCILLOSCOPE,
  UPDATE_STATUS_OSCILLOSCOPE, UPDATE_DATE_TIME_OSCILLOSCOPE, UPDATE_ANALOGVALUE_POSITION,
  UPDATE_COMPONENT_POSITION, ADD_COMPONENT, DELETE_COMPONENT, DELETE_ANALOGVALUE, DELETE_DIGITALFLAG,
  UPDATE_EDIT_MODE_STATUS, UPDATE_DIGITALVALUE_POSITION, UPDATE_COMPONENT_SIZE, UPDATE_DEBUG_MSG, CLEAR_DEBUG_MSG,
  UPDATE_COUNTERS_DATA, UPDATE_COUNTERS_ACCESS_LEVEL
} from './modelActionTypes';
import { IModelData } from '../InitialDataInterfaces';
import { prop, eq, deq, filter, map, reduce, safeProp } from '../../CommonFunctions/pointfreeUtilities';
import {
  safeGetKeysObject, safeObjectSearch, objectSearch, getNewEntries, addNewOsciData,
  updateComponentsStateData, updateAnalogValuesSchematic, updateDigitalFlagsSchematic
} from '../../CommonFunctions/functionsSupport';
import { IAction } from '../InitialDataInterfaces';

const compose = require('folktale/core/lambda/compose');

export default function (storeData: IModelData, action: IAction) {

  switch (action.type) {
    case CREATE_MODULE_DATA:
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          [action.payload.module]: action.payload.data
        }
      }

    case CREATE_PROJECT_DATA:
      return {
        ...storeData,
        [action.dataType]: action.payload
      }

    case UPDATE_DEBUG_MSG:
      const MaxDebugMessages = 1000;
      const debugMessagesOld = safeObjectSearch(`${action.dataType}.${action.payload.module}`, storeData).getOrElse([]);
      const newDebugMessages = safeProp('payload.data', action).getOrElse([]);
      const debugMessages = (newDebugMessages.length > 0) ?
        (((debugMessagesOld.length + newDebugMessages.length) > MaxDebugMessages) ?
          ((newDebugMessages.length > MaxDebugMessages) ?
            newDebugMessages.slice(newDebugMessages.length - MaxDebugMessages)
            : debugMessagesOld.slice(((debugMessagesOld.length + newDebugMessages.length) - MaxDebugMessages)).concat(newDebugMessages))
          : debugMessagesOld.concat(newDebugMessages))
        : debugMessagesOld;

      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          [action.payload.module]: debugMessages
        }
      }

    case CLEAR_DEBUG_MSG:
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          [action.payload]: []
        }
      }

    case UPDATE_COMPONENT_DATA:
      return eq(safeObjectSearch(`${action.dataType}.editMode`, storeData).getOrElse(true), false) ?
        ({
          ...storeData,
          [action.dataType]: {
            ...prop(action.dataType, storeData),
            schematicComponents: updateComponentsStateData(safeObjectSearch(`${action.dataType}.schematicComponents`, storeData).getOrElse({}), action.payload)
          }
        }) : ({ ...storeData });

    case UPDATE_ANALOG_VALUES:
      return eq(safeObjectSearch(`${action.dataType}.editMode`, storeData).getOrElse(true), false) ?
        ({
          ...storeData,
          [action.dataType]: {
            ...prop(action.dataType, storeData),
            schematicAnalogValues: {
              ...objectSearch(`${action.dataType}.schematicAnalogValues`, storeData),
              [action.payload.module]: updateAnalogValuesSchematic(prop(action.dataType, storeData).schematicAnalogValues[action.payload.module], action.payload)
            }
          }
        }) : ({ ...storeData });

    case UPDATE_DIGITAL_FLAGS:
      return eq(safeObjectSearch(`${action.dataType}.editMode`, storeData).getOrElse(true), false) ?
        ({
          ...storeData,
          [action.dataType]: {
            ...prop(action.dataType, storeData),
            schematicDigitalFlags: {
              ...objectSearch(`${action.dataType}.schematicDigitalFlags`, storeData),
              [action.payload.module]: updateDigitalFlagsSchematic(prop(action.dataType, storeData).schematicDigitalFlags[action.payload.module], action.payload)
            }
          }
        }) : ({ ...storeData });

    case UPDATE_OSCILLOSCOPE_VALUES:
      const getOscilloscopeData = compose(map(addNewOsciData(action.payload.data)), safeObjectSearch(`${action.dataType}.data.${action.payload.module}`));
      const newData = eq(safeObjectSearch(`${action.dataType}.running`, storeData).getOrElse(false), true) ?
        getOscilloscopeData(storeData) :
        safeObjectSearch(`${action.dataType}.data.${action.payload.module}`, storeData);
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          data: {
            ...objectSearch(`${action.dataType}.data`, storeData),
            [action.payload.module]: newData.getOrElse([])
          }
        }
      }

    case ADD_CHANNEL_OSCILLOSCOPE:
      const { channel, ...dataChannels } = action.payload.channelData;
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          [action.payload.type]: {
            ...objectSearch(`${action.dataType}.${action.payload.type}`, storeData), [channel]: dataChannels
          }
        }
      }

    case CLEAR_CHANNEL_OSCILLOSCOPE:
      const getStoreChannels = safeObjectSearch(`${action.dataType}.${action.payload.type}`);
      const createNewChannels = map(reduce(getNewEntries(getStoreChannels(storeData).getOrElse({})), {}));
      const getChannels = compose(createNewChannels, compose(map(filter(deq(safeProp('channel', action.payload).getOrElse('')))), safeGetKeysObject));
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          [action.payload.type]: getChannels(getStoreChannels(storeData).getOrElse({})).getOrElse({})
        }
      }

    case UPDATE_STATUS_OSCILLOSCOPE:
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          running: !prop(action.dataType, storeData).running
        }
      }

    case UPDATE_DATE_TIME_OSCILLOSCOPE:
      const date = eq(safeObjectSearch(`${action.dataType}.running`, storeData).getOrElse(false), true) ?
        action.payload :
        safeProp('date', safeProp(action.dataType, storeData).getOrElse('')).getOrElse('');
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          date: date
        }
      }

    case UPDATE_EDIT_MODE_STATUS:
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          editMode: !prop(action.dataType, storeData).editMode
        }
      }

    case UPDATE_ANALOGVALUE_POSITION:
      const analogValues = objectSearch(`${action.dataType}.${action.payload.component}.${action.payload.module}`, storeData);
      const { xAPosition, yAPosition, ...analogValueData } = safeProp(action.payload.name, analogValues).getOrElse({});

      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          [action.payload.component]: {
            ...objectSearch(`${action.dataType}.${action.payload.component}`, storeData),
            [action.payload.module]: { ...analogValues, [action.payload.name]: { ...analogValueData, xAPosition: action.payload.xPosition, yAPosition: action.payload.yPosition } }
          }
        }
      }

    case UPDATE_DIGITALVALUE_POSITION:
      const digitalFlags = objectSearch(`${action.dataType}.${action.payload.component}.${action.payload.module}`, storeData);
      const { xDPosition, yDPosition, ...digitalValueData } = safeProp(action.payload.name, digitalFlags).getOrElse({});

      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          [action.payload.component]: {
            ...objectSearch(`${action.dataType}.${action.payload.component}`, storeData),
            [action.payload.module]: { ...digitalFlags, [action.payload.name]: { ...digitalValueData, xDPosition: action.payload.xPosition, yDPosition: action.payload.yPosition } }
          }
        }
      }

    case UPDATE_COMPONENT_POSITION:
      const component = objectSearch(`${action.dataType}.${action.payload.component}.${action.payload.key}`, storeData);
      const { xPosition, yPosition, ...componentData } = component;
      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          [action.payload.component]: { ...objectSearch(`${action.dataType}.${action.payload.component}`, storeData), [action.payload.key]: { ...componentData, xPosition: action.payload.xPosition, yPosition: action.payload.yPosition } }
        }
      }

    case UPDATE_COMPONENT_SIZE:
      const _componentData = objectSearch(`${action.dataType}.${action.payload.component}.${action.payload.key}`, storeData);
      const { width, height, ...componentDataSize } = _componentData;

      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          [action.payload.component]: { ...objectSearch(`${action.dataType}.${action.payload.component}`, storeData), [action.payload.key]: { ...componentDataSize, width: action.payload.width, height: action.payload.height } }
        }
      }

    case ADD_COMPONENT:
      const { componentType, ...data } = action.payload;
      const modulesSignals = objectSearch(`${action.dataType}.${componentType}.${data.module}`, storeData);
      const schematicData = objectSearch(`${action.dataType}.${componentType}`, storeData);
      return (eq(componentType, 'schematicAnalogValues') || eq(componentType, 'schematicDigitalFlags')) ?
        ({
          ...storeData,
          [action.dataType]: {
            ...prop(action.dataType, storeData),
            [componentType]: {
              ...objectSearch(`${action.dataType}.${componentType}`, storeData),
              [data.module]: { ...modulesSignals, [data.name]: data }
            }
          }
        }) :
        ({
          ...storeData,
          [action.dataType]: {
            ...prop(action.dataType, storeData),
            [componentType]: { ...schematicData, [data.name.toLowerCase()]: data }
          }
        })

    case DELETE_COMPONENT:
      const getStoreComponents = safeObjectSearch(`${action.dataType}.${action.payload.component}`);
      const createNewComponents = map(reduce(getNewEntries(getStoreComponents(storeData).getOrElse({})), {}));
      const getComponents = compose(createNewComponents, compose(map(filter(deq(safeProp('key', action.payload).getOrElse('')))), safeGetKeysObject));

      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          [action.payload.component]: getComponents(getStoreComponents(storeData).getOrElse({})).getOrElse({})
        }
      }

    case DELETE_DIGITALFLAG:
      const getStoreDigitalFlags = safeObjectSearch(`${action.dataType}.${action.payload.component}.${action.payload.module}`);
      const createNewDigitalFlags = map(reduce(getNewEntries(getStoreDigitalFlags(storeData).getOrElse({})), {}));
      const getDigitalFlags = compose(createNewDigitalFlags, compose(map(filter(deq(safeProp('name', action.payload).getOrElse('')))), safeGetKeysObject));

      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          [action.payload.component]: {
            ...objectSearch(`${action.dataType}.${action.payload.component}`, storeData),
            [action.payload.module]: getDigitalFlags(getStoreDigitalFlags(storeData).getOrElse({})).getOrElse({})
          }
        }
      }

    case DELETE_ANALOGVALUE:
      const getStoreAnalogValues = safeObjectSearch(`${action.dataType}.${action.payload.component}.${action.payload.module}`);
      const createNewAnalogValues = map(reduce(getNewEntries(getStoreAnalogValues(storeData).getOrElse({})), {}));
      const getAnalogValues = compose(createNewAnalogValues, compose(map(filter(deq(safeProp('name', action.payload).getOrElse('')))), safeGetKeysObject));

      return {
        ...storeData,
        [action.dataType]: {
          ...prop(action.dataType, storeData),
          [action.payload.component]: {
            ...objectSearch(`${action.dataType}.${action.payload.component}`, storeData),
            [action.payload.module]: getAnalogValues(getStoreAnalogValues(storeData).getOrElse({})).getOrElse({})
          }
        }
      }

      case UPDATE_COUNTERS_DATA:
        return {
          ...storeData,
          [action.dataType]: {
            ...prop(action.dataType, storeData),
            counters: action.payload
          }
        }

      case UPDATE_COUNTERS_ACCESS_LEVEL: 
        return {
          ...storeData,
          [action.dataType]: {
            ...prop(action.dataType, storeData),
            accessLevel: action.payload
          }
        }

    default:
      return storeData || InitialData.modelData;
  }
}