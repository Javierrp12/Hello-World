export const ViewTypes = {
  SystemOverview: 'systemoverview',
  CtrlDS: 'ctrlds',
  ModuleSignals: 'modulesignals',
  Parameters: 'parameters',
  SystemCounters: "systemcounters",
  Units: 'units',
  EventLog: 'eventlog',
  DebugService: 'debugservice',
  Oscilloscope: 'oscilloscope',
  HistoryLog: 'historylog',
  SoftwareUpdate: 'softwareupdate',
  SoftwareUpdater: 'softwareupdater',
  Help: 'help',
  Settings: 'settings'
}

export const SystemOverview = 'systemoverview';
export const CtrlDS = 'ctrlds';
export const ModuleSignals = 'modulesignals';
export const SystemCounters ='systemcounters';
export const Parameters = 'parameters';
export const Units = 'units';
export const EventLog = 'eventlog';
export const DebugService = 'debugservice';
export const Oscilloscope = 'oscilloscope';
export const HistoryLog = 'historylog';
export const SoftwareUpdate = 'softwareupdate';
export const SoftwareUpdater = 'softwareupdater';
export const Help = 'help';
export const Settings = 'settings';