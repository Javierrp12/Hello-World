export const MU = 'MU';
export const IVPS = 'IVPS';
export const INV = 'INV';
export const LVPS = 'LVPS';

export const Modules = {
  MU: 'MU',
  IVPS: 'IVPS',
  INV: 'INV',
  LVPS: 'LVPS',
}