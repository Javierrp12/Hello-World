import {
  UPDATE_ERROR_STATUS, UPDATE_ERROR_MODAL_STATUS, UPDATE_IS_AUTH,
  UPDATE_SHOW_LOGIN, UPDATE_INFO_STATUS, UPDATE_INFO_MODAL_STATUS
} from './errorActionTypes';
import { IAction } from '../InitialDataInterfaces';

export interface IErrorInfo {
  isOnline: boolean,
  error: string
}

export const updateErrorStatus = (errorInfo: IErrorInfo): IAction => {
  return {
    type: UPDATE_ERROR_STATUS,
    dataType: 'errorHandler',
    payload: errorInfo
  }
}

export const closeErrorModalCallback = (): IAction => {
  return {
    type: UPDATE_ERROR_MODAL_STATUS,
    dataType: 'errorHandler',
  }
}

export const updateUnauthorized = (data: boolean): IAction => {
  return {
    type: UPDATE_IS_AUTH,
    dataType: "",
    payload: data
  }
}

export const updateShowloginStatus = (): IAction => {
  return {
    type: UPDATE_SHOW_LOGIN,
    dataType: ""
  }
}

export const updateInfoStatus = (Infodata: string): IAction => {
  return {
    type: UPDATE_INFO_STATUS,
    dataType: 'errorHandler',
    payload: Infodata
  }
}

export const closeInfoModal = (): IAction => {
  return {
    type: UPDATE_INFO_MODAL_STATUS,
    dataType: ""
  }
}