import { InitialData } from '../initialData';
import { IErrorData } from '../InitialDataInterfaces';
import {
  UPDATE_ERROR_STATUS, UPDATE_ERROR_MODAL_STATUS,
  UPDATE_IS_AUTH, UPDATE_SHOW_LOGIN, UPDATE_INFO_MODAL_STATUS
} from './errorActionTypes';
import { IAction } from '../InitialDataInterfaces';

export default function (storeData: IErrorData, action: IAction) {
  switch (action.type) {
    case UPDATE_ERROR_STATUS:
      return {
        ...storeData,
        showErrorModal: true,
        [action.dataType]: {
          isOnline: action.payload.isOnline,
          error: action.payload.error,
        }
      }

    case UPDATE_ERROR_MODAL_STATUS:
      return {
        ...storeData,
        showErrorModal: false
      }

    case UPDATE_INFO_MODAL_STATUS:
      return {
        ...storeData,
        showInfoModal: false,
        info: ''
      }

    case UPDATE_IS_AUTH:
      return {
        ...storeData,
        isAuthenticated: action.payload
      }

    case UPDATE_SHOW_LOGIN:
      return {
        ...storeData,
        showLogin: !storeData.showLogin
      }

    default:
      return storeData || InitialData.errorData;
  }
}