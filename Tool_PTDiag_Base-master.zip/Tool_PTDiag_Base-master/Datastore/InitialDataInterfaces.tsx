import { SystemOverview, ModuleSignals,SystemCounters, Parameters, Units, Oscilloscope, EventLog, HistoryLog, SoftwareUpdate, Help, CtrlDS, Settings, DebugService } from './ModelData/viewTypes';
import { MU, INV, LVPS, IVPS, Modules } from './ModelData/modulesTypes';
import { Ch1, Ch2, Ch3, Ch4, Ch5, Ch6, Ch7, Ch8 } from './StateData/oscilloscopeChannel';

/* Languages */
export const en = 'en';
export const de = 'de';
export const fr = 'fr';
export const es = 'es';
export const Languages = {
  en: 'en',
  de: 'de',
  fr: 'fr',
  es: 'es'
}

/* Interfaces */
export interface IInitialData {
  modelData: IModelData;
  stateData: IStateData;
  errorData: IErrorData;
}

export interface IModelData {
  appInfo: IAppInfo;
  systemInfo: ISytemInfo;
  [SystemOverview]: ISystemOverview;
  [CtrlDS]: ICtrlDS;
  [ModuleSignals]: IModulesSignals;
  [SystemCounters]: ISystemCounters;
  [Parameters]: IParameters;
  [Units]: IUnits;
  [Oscilloscope]: IOscilloscope;
  [EventLog]: IEventLog;
  [HistoryLog]: Array<IHistoryLogItem>;
  [DebugService]: IDebugService;
  [SoftwareUpdate]: ISoftwareUpdateModel;
  [Help]: IHelpModel;
}

export interface IStateData {
  ptdiagVersion: string;
  year: string;
  userlevel: string;
  date: string;
  activeModule: keyof typeof Modules;
  modulesState: IModulesState;
  showOnlyActiveSignals: boolean;
  selectedItem: string;
  selectedItemType: string;
  selectedSnapshotIndex: number;
  snapshotData: ISnapshotData;
  [CtrlDS]: ICtrlDSState;
  [ModuleSignals]: IModulesSignalsState;
  [Parameters]: IParametersState;
  [Units]: IUnitsState;
  [EventLog]: IEventLogState;
  [DebugService]: IDebugServiceState;
  [Oscilloscope]: IOscilloscopeState;
  [Help]: IHelpState;
  [Settings]: ISettingsState;
}

export interface IErrorData {
  isAuthenticated: boolean;
  showErrorModal: boolean;
  showLogin: boolean;
  errorHandler: { isOnline: boolean; error: string; };
  showInfoModal: boolean;
  info: string;
}

export interface IHelpModel {
  signalsData: IHelpSystemDataEntry[];
  possibleCauses: IPossibleCausesEntry[];
  correctiveActions: ICorrectiveActionsEntry[];
}

export interface IAppInfo {
  project: IProject;
  software: ISoftware;
}

export interface ISytemInfo {
  update_receiver: string;
  hostname: string;
  os_version: string;
}

export interface ISystemOverview {
  schematicComponents: any;
  schematicExtraComponents: any;
  schematicConnections: any;
  schematicAnalogValues: any;
  schematicDigitalFlags: any;
  editMode: boolean;
}

export interface ICtrlDS {
  [MU]: ISignalsModel;
  [IVPS]: ISignalsModel;
  [LVPS]: ISignalsModel;
  [INV]: ISignalsModel;
}

export interface IModulesSignals {
  [MU]: ISignalsModel;
  [IVPS]: ISignalsModel;
  [LVPS]: ISignalsModel;
  [INV]: ISignalsModel;
}

export interface ISystemCounters {
  counters:ICounter[];
  accessLevel: string;
}

export interface IParameters {
  [MU]: any;
  [IVPS]: any;
  [LVPS]: any;
  [INV]: any;
}

export interface IUnits {
  [MU]: any;
  [IVPS]: any;
  [LVPS]: any;
  [INV]: any;
}

export interface IOscilloscope {
  running: boolean;
  data: IOsciData;
  Analog: {};
  Digital: {};
  date: string;
}

export interface IEventLog {
  [MU]: Array<IEventLogItem>;
  [IVPS]: Array<IEventLogItem>;
  [LVPS]: Array<IEventLogItem>;
  [INV]: Array<IEventLogItem>;
}

export interface IDebugService {
  [MU]: IDebugServiceMsg[];
  [IVPS]: IDebugServiceMsg[];
  [LVPS]: IDebugServiceMsg[];
  [INV]: IDebugServiceMsg[];
}

interface IDebugServiceMsg {
  entry: string;
}

export interface ISoftwareUpdateModel {
  os_version: string;
  package_version: string;
  project_name: string;
  project_id: string;
  isSameProject: boolean;
  file_name: string;
}

interface ISignalsModel {
  analog: any;
  digital: any;
}

interface IOsciData {
  [MU]: any;
  [IVPS]: any;
  [LVPS]: any;
  [INV]: any;
}

interface ISignals {
  analog: IAnalog;
  digital: IDigital;
}

export interface IAnalog {
  category: string;
  datastore: string;
  name: string;
  qFormat: number;
  unit: string;
  value: number;
  visibleBy: string
}

export interface IDigital {
  category: string;
  datastore: string;
  isFlag: boolean;
  name: string;
  severity: string;
  status: boolean;
  visibleBy: string;
}

export interface ICTRLAnalog {
  category: string;
  name: string;
  unit: string;
  value: number;
}

export interface ICTRLDigital {
  category: string
  isFlag: boolean
  name: string
  severity: string
  severity_Customer: string
  status: boolean
  visibleBy: string
}

export interface IProject {
  name: string;
  version: string;
  buildDate: string;
  projectID: string;
  packageName: string
}

export interface ISoftware {
  MU: IMU;
  RUs: IRUS[];
}

export interface IMU {
  type: string;
  version: string
}

export interface IRUS {
  name: string;
  CANnode: string;
  type: string;
  SWversions: any[]
}

export interface ISWversions {
  type: string;
  fpga: string;
  bootloader: string;
}

export interface IHelpSystemData {
  signalsData: IHelpSystemDataEntry[];
  possibleCauses?: IPossibleCausesEntry[];
  correctiveActions?: ICorrectiveActionsEntry[];
}

export interface IHelpSystemDataEntry {
  module: string;
  type: string;
  name: string;
  language: ILanguageDataEntry
  possibleCauses?: string[]
}

export interface ILanguageDataEntry {
  [en]: {
    title: string;
    description: string;
  }
  [de]: {
    title: string;
    description: string;
  }
  [fr]: {
    title: string;
    description: string;
  }
  [es]: {
    title: string;
    description: string;
  }
}

export interface IPossibleCausesEntry {
  name: string;
  language: ILanguagePossibleCausesEntry;
  correctiveActions: string[];
}

interface ILanguagePossibleCausesEntry {
  [en]: {
    description: string;
  }
  [de]: {
    description: string;
  }
  [fr]: {
    description: string;
  }
  [es]: {
    description: string;
  }
}

export interface ICorrectiveActionsEntry {
  name: string;
  language: ILanguageCorrectiveActions;
  description: string;
  steps?: string[];
}

export interface ILanguageCorrectiveActions {
  [en]: {
    description: string;
    steps?: string[];
  }
  [de]: {
    description: string;
    steps?: string[];
  }
  [fr]: {
    description: string;
    steps?: string[];
  }
  [es]: {
    description: string;
    steps?: string[];
  }
}

export interface IHistoryLogItem {
  dateTime: string;
  user: string;
  moduleName: string;
  action: string;
  info: string
}

export interface IEventLogItem {
  flag: string;
  datastore: string;
  category: string;
  severity: string;
  count: ICountEventLog;
  timestamp: string;
  sequenceNumber: number;
  ticksSinceLastSnapshot: number;
  snapshot: ISnapshotEventlog;
  index: number;
  module?: string;
}

interface ISnapshotEventlog {
  flags: string[];
  values: string[]
}

export interface ICountEventLog {
  max: number;
  this: number
}

interface ICtrlDSState {
  currentCategory: ICurrentCategory;
  info: IDataInfo;
}

interface IModulesSignalsState {
  currentDatastore: ICurrentCategory;
  currentCategory: ICurrentCategory;
  info: IDataInfo;
}

interface ICurrentCategory {
  [MU]: string;
  [IVPS]: string;
  [LVPS]: string;
  [INV]: string;
}

interface IDataInfo {
  [MU]: any;
  [IVPS]: any;
  [LVPS]: any;
  [INV]: any
}

interface IInfo {
  [MU]: IInfoObject;
  [IVPS]: IInfoObject;
  [LVPS]: IInfoObject;
  [INV]: IInfoObject
}

export interface IInfoObject {
  category: IInfoCategory
}

export interface IInfoCategory {
  signal: number | boolean
}

export interface IModulesState {
  [MU]: string;
  [IVPS]: string;
  [LVPS]: string;
  [INV]: string
}

export interface IHelpState {
  activeList: string;
  activeSignal: string;
}

export interface IParametersState {
  currentCategory: IModulesState;
  info: IDataInfo;
}

export interface IUnitsState {
  currentCategory: IModulesState;
  info: IDataInfo;
}

export interface IDebugServiceState {
  modulesStates: IModulesState;
  flags: { keepRunning: boolean; runOnBoot: boolean; };
  levels: { Error: boolean; Warning: boolean; Info: boolean; Debug: boolean; };
}

export interface IOscilloscopeState {
  showingAnalog: boolean;
  showingDigital: boolean;
  signalType: string;
}

export interface IEventLogState {
  showAllModules: boolean;
}

export interface IUnitsSymbolItem {
  name: string;
  value: string;
  dataType: string;
}

export interface IUnitsItem {
  name: string;
  minimum: string;
  maximum: string;
  value: string;
  defaultValue: string;
  dataType: string;
}

export interface IParametersItem {
  name: string;
  range_Service: IRange;
  range_PTService: IRange;
  value: boolean | number | string;
  defaultValue: string;
  dataType: string;
  unit: string;
  changeableOnTheFly: boolean;
  changeableBy: string;
  visibleBy: string;
}

interface IRange {
  min: number;
  max: number
}

export interface IDebug {
  modulesStates: IModulesState;
  flags: IFlags;
  levels: ILevels
}

export interface IFlags {
  keepRunning: boolean;
  runOnBoot: boolean
}

export interface ILevels {
  Error: boolean;
  Warning: boolean;
  Info: boolean;
  Debug: boolean;
}

export interface IChannelsData {
  [Ch1]: IChannels
  [Ch2]: IChannels
  [Ch3]: IChannels
  [Ch4]: IChannels
  [Ch5]: IChannels
  [Ch6]: IChannels
  [Ch7]: IChannels
  [Ch8]: IChannels
}

export interface IChannels {
  channel: string;
  module: string;
  datastore: string;
  category: string;
  signal: string;
  offset: number
  scaleFactor: number;
  unit: string
}

interface ISnapshotData {
  analog: any;
  digital: any;
}

export interface ISettingsState {
  restart: boolean;
  option: string;
}

export interface IAction {
  type: string;
  dataType: string;
  payload?: any;
}

export interface ICounter {
  name: string;
  value: number;
  unit: string;
}