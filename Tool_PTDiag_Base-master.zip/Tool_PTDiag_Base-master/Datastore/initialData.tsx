import { SystemOverview, ModuleSignals,SystemCounters, Parameters, Units, Oscilloscope, EventLog, HistoryLog, SoftwareUpdate, Help, CtrlDS, Settings, DebugService } from './ModelData/viewTypes';
import { MU, INV, LVPS, IVPS } from './ModelData/modulesTypes';
import { HelpListCategories } from './StateData/helpSystemListTypes';
import { IInitialData, IHelpSystemDataEntry, IPossibleCausesEntry, ICorrectiveActionsEntry } from './InitialDataInterfaces';
import {PTDeveloper} from './StateData/userLevelTypes';
import { safeObjectSearch } from '../CommonFunctions/functionsSupport';
import { safeProp } from '../CommonFunctions/pointfreeUtilities';

declare global {
  interface Window {
    helpSystemData: {
      signalsData: IHelpSystemDataEntry[];
      possibleCauses: IPossibleCausesEntry[];
      correctiveActions: ICorrectiveActionsEntry[];
    };
    schematicComponents: any;
    schematicExtraComponents: any;
    schematicConnections: any;
    schematicAnalogValues: any;
    schematicDigitalFlags: any;
    ptDiagData: any;
  }
}

export const InitialData: IInitialData = {
  modelData: {
    appInfo: safeObjectSearch('ptDiagData.appInfo', window).getOrElse({ project: { name: '', version: '', buildDate: '', projectID: '', packageName: '' }, software: { MU: { type: '', version: '' }, RUs: [] } }),
    systemInfo: safeObjectSearch('ptDiagData.systemInfo', window).getOrElse({ update_receiver: '', hostname: '', os_version: '' }),
    [SystemOverview]: {
      schematicComponents: safeProp('schematicComponents', window).getOrElse({}),
      schematicExtraComponents: safeProp('schematicExtraComponents', window).getOrElse({}),
      schematicConnections: safeProp('schematicConnections', window).getOrElse({}),
      schematicAnalogValues: safeProp('schematicAnalogValues', window).getOrElse({ "MU": {}, "IVPS": {}, "INV": {}, "LVPS": {} }),
      schematicDigitalFlags: safeProp('schematicDigitalFlags', window).getOrElse({ "MU": {}, "IVPS": {}, "INV": {}, "LVPS": {} }),
      editMode: false
    },
    [CtrlDS]: { [MU]: { analog: {}, digital: {} }, [INV]: { analog: {}, digital: {} }, [LVPS]: { analog: {}, digital: {} }, [IVPS]: { analog: {}, digital: {} } },
    [ModuleSignals]: { [MU]: { analog: {}, digital: {} }, [INV]: { analog: {}, digital: {} }, [LVPS]: { analog: {}, digital: {} }, [IVPS]: { analog: {}, digital: {} } },
    [SystemCounters]:{counters:[], accessLevel:PTDeveloper },
    [Parameters]: { [MU]: {}, [INV]: {}, [LVPS]: {}, [IVPS]: {} },
    [Units]: { [MU]: {}, [INV]: {}, [LVPS]: {}, [IVPS]: {} },
    [Oscilloscope]: { running: true, data: { [MU]: [], [INV]: [], [LVPS]: [], [IVPS]: [] }, Analog: {}, Digital: {}, date: safeObjectSearch('ptDiagData.datetime', window).getOrElse('') },
    [EventLog]: { [MU]: [], [INV]: [], [LVPS]: [], [IVPS]: [] },
    [HistoryLog]: [],
    [DebugService]: { [MU]: [], [INV]: [], [LVPS]: [], [IVPS]: [] },
    [SoftwareUpdate]: { os_version: 'MU_OS_00_08_03_00', package_version: '00_05_00_00', project_name: 'Zuerich', project_id: '', file_name: '0360B4PA-Zuerich_firmware_00_05_00_00.ccon', isSameProject: true },
    [Help]: {
      signalsData: safeObjectSearch('helpSystemData.signalsData', window).getOrElse([]),
      possibleCauses: safeObjectSearch('helpSystemData.possibleCauses', window).getOrElse([]),
      correctiveActions: safeObjectSearch('helpSystemData.correctiveActions', window).getOrElse([])
    }
  },
  stateData: {
    ptdiagVersion: '01_03_00_00',
    year: '2021',
    userlevel: safeObjectSearch('ptDiagData.user', window).getOrElse('Default'),
    date: safeObjectSearch('ptDiagData.datetime', window).getOrElse(''),
    activeModule: MU,
    modulesState: { [MU]: 'Undefined', [INV]: 'Undefined', [LVPS]: 'Undefined', [IVPS]: 'Undefined' },
    showOnlyActiveSignals: false,
    selectedItem: '',
    selectedItemType: 'analog',
    selectedSnapshotIndex: -1,
    snapshotData: { analog: {}, digital: {} },
    [CtrlDS]: {
      currentCategory: { [MU]: '', [INV]: '', [LVPS]: '', [IVPS]: '' },
      info: { [MU]: {}, [INV]: {}, [LVPS]: {}, [IVPS]: {} }
    },
    [ModuleSignals]: {
      currentDatastore: { [MU]: '', [INV]: '', [LVPS]: '', [IVPS]: '' },
      currentCategory: { [MU]: '', [INV]: '', [LVPS]: '', [IVPS]: '' },
      info: { [MU]: {}, [INV]: {}, [LVPS]: {}, [IVPS]: {} }
    },
    [Parameters]: {
      currentCategory: { [MU]: '', [INV]: '', [LVPS]: '', [IVPS]: '' },
      info: { [MU]: [], [INV]: [], [LVPS]: [], [IVPS]: [] }
    },
    [Units]: {
      currentCategory: { [MU]: '', [INV]: '', [LVPS]: '', [IVPS]: '' },
      info: {
        [MU]: [], [INV]: [], [LVPS]: [], [IVPS]: []
      }
    },
    [EventLog]: {
      showAllModules: true
    },
    [DebugService]: {
      modulesStates: { [MU]: 'stopped', [INV]: 'stopped', [LVPS]: 'stopped', [IVPS]: 'stopped' },
      flags: { keepRunning: false, runOnBoot: false },
      levels: { Error: false, Warning: false, Info: false, Debug: false }
    },
    [Oscilloscope]: {
      showingAnalog: false,
      showingDigital: false,
      signalType: 'Analog'
    },
    [Help]: {
      activeList: HelpListCategories.digital,
      activeSignal: '',
    },
    [Settings]: {
      restart: false,
      option: ''
    }
  },
  errorData: {
    isAuthenticated: true,
    showLogin: false,
    showErrorModal: false,
    errorHandler: { isOnline: true, error: '' },
    showInfoModal: false,
    info: ''
  }
}