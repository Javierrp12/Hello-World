import React from 'react';
import { connect } from "react-redux";
import { withTranslation } from 'react-i18next';
import { ViewTypes } from '../Datastore/ModelData/viewTypes';
import { SystemOverviewConnector } from '../ConnectingComponents/SystemOverview/systemOverviewConnector';
import { SystemOverview } from '../Components/Views/SystemOverview/systemOverview';
import { CTRLDSConnector } from '../ConnectingComponents/CtrlDS/ctrldsConnector';
import { CTRLDS } from '../Components/Views/CtrlDS/ctrlds';
import { ModuleSignalsConnector } from '../ConnectingComponents/ModuleSignals/moduleSignalsConnector';
import { ModuleSignals } from '../Components/Views/ModuleSignals/moduleSignals';
import {SystemCountersConnector} from '../ConnectingComponents/SystemCounters/systemCountersConnector';
import { SystemCounters } from '../Components/Views/SystemCounters/systemcounters';
import { ParametersConnector } from '../ConnectingComponents/Parameters/parametersConnector';
import { Parameters } from '../Components/Views/Parameters/parameters';
import { UnitsConnector } from '../ConnectingComponents/Units/unitsConnector';
import { Units } from '../Components/Views/Units/units';
import { EventLogConnector } from '../ConnectingComponents/Eventlog/eventLogConnector';
import { EventLog } from '../Components/Views/Eventlog/eventlog';
import { HistoryLogConnector } from '../ConnectingComponents/HistoryLog/historyLogConnector';
import { HistoryLog } from '../Components/Views/Historylog/historylog';
import { DebugServiceConnector } from '../ConnectingComponents/DebugService/debugServiceConnector';
import { DebugService } from '../Components/Views/DebugService/debugService';
import { OscilloscopeConnector } from '../ConnectingComponents/Oscilloscope/oscilloscopeConnector';
import { Oscilloscope } from '../Components/Views/Oscilloscope/oscilloscope';
import { Help } from '../Components/Views/Help/help';
import { SoftwareUpdateConnector } from '../ConnectingComponents/SoftwareUpdate/softwareUpdateConnector';
import { SoftwareUpdate } from '../Components/Views/SoftwareUpdate/softwareUpdate';
import { SettingsConnector } from '../ConnectingComponents/Settings/settingsConnector';
import { Settings } from '../Components/Views/Settings/settings';
import { ErrorModalConnector } from '../ConnectingComponents/ErrorModal/errorModalConnector';
import { ErrorModal } from '../Components/error';
import { updateUnitsData, updateSytemConfigData, getOnlineData, getAppInfo, getSystemInfo } from '../Datastore/ModelData/modelActionCreator';
import { getDateTime, getUserLevel } from '../Datastore/StateData/stateActionCreator';
import { IInitialData } from '../Datastore/InitialDataInterfaces';
import { eq } from '../CommonFunctions/pointfreeUtilities';
import '../Components/Views/view.css';

export interface IRoutingDisplayViewProps {
  showErrorModal: boolean;
  updateSytemConfigData: () => void;
  updateUnitsData: () => void;
  getOnlineData: () => void;
}

export interface IMatch {
  params: IParams;
}

interface IParams {
  mode: string;
  id: string;
  dataType: string;
}

export const RoutingDisplayView = (view: keyof typeof ViewTypes) => {
  const ConnectorSystemOverview = SystemOverviewConnector(SystemOverview);
  const ConnectorCTRLDS = CTRLDSConnector(CTRLDS);
  const ConnectorModuleSignals = ModuleSignalsConnector(ModuleSignals);
  const ConnectorSystemCounters = SystemCountersConnector(SystemCounters);
  const ConnectorParameters = ParametersConnector(Parameters);
  const ConnectorUnits = UnitsConnector(Units);
  const ConnectorEventLog = EventLogConnector(EventLog);
  const ConnectorHistoryLog = HistoryLogConnector(HistoryLog);
  const ConnectorDebugService = DebugServiceConnector(DebugService);
  const ConnectorOscilloscope = OscilloscopeConnector(Oscilloscope);
  const ConnectorSoftwareUpdate = SoftwareUpdateConnector(SoftwareUpdate);
  const ConnectorSettings = SettingsConnector(Settings);
  const ConnectorErrorModal = ErrorModalConnector(ErrorModal);

  const mapStateToProps = (storeData: IInitialData) => {
    return {
      showErrorModal: storeData.errorData.showErrorModal
    }
  }

  const mapDispatchToProps = {
    updateUnitsData,
    updateSytemConfigData,
    getOnlineData,
    getDateTime,
    getAppInfo,
    getSystemInfo,
    getUserLevel
  }

  const component: any = class extends React.Component<IRoutingDisplayViewProps> {

    render() {
      const { showErrorModal } = this.props;
      return (
        <React.Fragment>
          {eq(showErrorModal, true) &&
            <ConnectorErrorModal />
          }
          {this.selectedView(view)}
        </React.Fragment>
      );
    }

    componentDidMount() {
      /* initialize DataStore */
      this.props.updateUnitsData();
      this.props.updateSytemConfigData();
      this.props.getOnlineData();
    }

    private selectedView = (view: keyof typeof ViewTypes) => {
      switch (view) {
        case ViewTypes.SystemOverview:
          return <ConnectorSystemOverview />;

        case ViewTypes.CtrlDS:
          return <ConnectorCTRLDS />;

        case ViewTypes.ModuleSignals:
          return <ConnectorModuleSignals />;

        case ViewTypes.SystemCounters:
          return <ConnectorSystemCounters />;

        case ViewTypes.Parameters:
          return <ConnectorParameters />;

        case ViewTypes.Units:
          return <ConnectorUnits />;

        case ViewTypes.EventLog:
          return <ConnectorEventLog />;

        case ViewTypes.DebugService:
          return <ConnectorDebugService />;

        case ViewTypes.Oscilloscope:
          return <ConnectorOscilloscope />;

        case ViewTypes.HistoryLog:
          return <ConnectorHistoryLog />;

        case ViewTypes.SoftwareUpdate:
          return <ConnectorSoftwareUpdate />;

        case ViewTypes.Help:
          return <Help />;

        case ViewTypes.Settings:
          return <ConnectorSettings />;

        default:
          return <div>{view}</div>;
      }
    }

  }

  const TranslatedComponent = withTranslation('translation')(component);
  return connect(mapStateToProps, mapDispatchToProps)(TranslatedComponent);
}
