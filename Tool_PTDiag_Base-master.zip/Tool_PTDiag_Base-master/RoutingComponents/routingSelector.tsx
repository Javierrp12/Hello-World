import React, { Children } from 'react';
import { HashRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import { HeaderConnector } from '../ConnectingComponents/Header/headerConnector';
import { Header } from '../Components/header';
import { Navegation } from '../Components/navegation';
import { RoutingDisplayView } from '../RoutingComponents/routingDisplayView';
import { Restart } from '../Components/restart';
import { Authenticator } from '../Components/authenticator';
import { ViewTypes } from '../Datastore/ModelData/viewTypes'
import { map, chain, filter, safeProp, safeHead, eq } from '../CommonFunctions/pointfreeUtilities';
import { filterPerUserLevel, safeNewArray, safeObjectSearch } from '../CommonFunctions/functionsSupport';

const compose = require('folktale/core/lambda/compose');

interface IRoutingSelectorProps {
  restart: boolean;
  option: string;
  isAuthenticated: boolean;
  showLogin: boolean;
  userLevel: string;
  children: any;
  hostname: string;
  updateShowloginStatusCallback: () => void;
  updateUnauthorizedCallback: (status: boolean) => void;
}

interface IRoute {
  name: string;
  url: string;
  view: keyof typeof ViewTypes;
  userLevel: string;
}

const ConnectorHeader = HeaderConnector(Header);

export class RoutingSelector extends React.Component<IRoutingSelectorProps> {

  render() {
    const { userLevel, restart, option, showLogin, isAuthenticated, children, hostname } = this.props;
    const { updateShowloginStatusCallback, updateUnauthorizedCallback } = this.props;

    const filterViews = (view: IRoute) => filterPerUserLevel(userLevel, safeProp('userLevel', view).getOrElse(''));
    const serializeRoutes = (children: any) => Children.toArray(children).map(child => ({
      name: safeObjectSearch('props.name', child).getOrElse(''),
      url: `/${safeObjectSearch('props.view', child).getOrElse('')}`,
      view: safeObjectSearch('props.view', child).getOrElse(''),
      userLevel: safeObjectSearch('props.userLevel', child).getOrElse('')
    }));
    const getRoutes = compose(compose(map(filter(filterViews)), map(serializeRoutes)), safeNewArray);
    const getFirstRoute = compose(chain(safeHead), getRoutes);
    const switchRoute = (item: IRoute) => <Route key={safeProp('url', item).getOrElse('')} path={`/:view(${safeProp('view', item).getOrElse('')})/:mode?`} component={RoutingDisplayView(safeProp('view', item).getOrElse(''))} />
    const getSwitchRoute = compose(map(map(switchRoute)), getRoutes);

    if (eq(restart, true)) {
      return <Restart option={option} hostname={hostname} />
    }

    if (eq(isAuthenticated, false) || eq(showLogin, true)) {
      return <Authenticator updateShowloginStatusCallback={updateShowloginStatusCallback} updateUnauthorizedCallback={updateUnauthorizedCallback} showLogin={showLogin} hostname={hostname} />;
    }

    return (
      <Router>
        <ConnectorHeader />
        <div className='container-fluid'>
          <div className='row'>
            <div className='col-12 p-0'>
              <Navegation routes={getRoutes(children).getOrElse([])} />
            </div>
          </div>
          <div className='row'>
            <div className='col m-2'>
              <Switch>
                {getSwitchRoute(children).getOrElse([])}
                <Redirect to={safeProp('url', getFirstRoute(children).getOrElse({})).getOrElse('')} />
              </Switch>
            </div>
          </div>
        </div>
      </Router>
    );
  }

}
