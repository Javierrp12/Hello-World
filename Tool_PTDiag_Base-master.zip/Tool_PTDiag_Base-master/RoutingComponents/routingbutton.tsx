import React from 'react';
import { Route, Link } from 'react-router-dom';
import i18next from "i18next";
import Tooltip from "@reach/tooltip";
import "@reach/tooltip/styles.css";

interface IButtonRoutingProps {
  to: string;
  exact: boolean;
  children: string;
  view: string;
}

export class ButtonRouting extends React.Component<IButtonRoutingProps> {

  render() {
    const { to, exact, children, view } = this.props;
    return (
      <Route path={to} exact={exact} children={(routeProps => {
        const baseClass = 'nav-link nav-routing';
        const activeClass = routeProps.match ? 'active' : '';
        const combineClass = `${baseClass} ${activeClass}`;

        return (
          <li className='nav-item'>
            <Tooltip label={i18next.t(children)} style={{
              background: "hsla(0, 0%, 0%, 0.75)",
              color: "white",
              border: "none",
              borderRadius: "4px",
              padding: "0.5em 1em",
            }}>
              <Link className={`${combineClass} icon-${view}`} to={to} data-cy={`icon-${view}`} />
            </Tooltip>
          </li>
        );
      })} />
    );
  }

}
