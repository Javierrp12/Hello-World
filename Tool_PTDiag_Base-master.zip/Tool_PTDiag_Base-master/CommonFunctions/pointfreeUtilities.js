import { compose, curry } from 'folktale/core/lambda';
import Maybe from 'folktale/maybe';

// add :: Number -> Number -> Number
export const add = curry(2, (a, b) => a + b);

// chain :: monad m =>(a -> m b) -> m a -> m b
export const chain = curry(2, (fn, m) => m.chain(fn));

// concat :: String -> String -> String 
export const concat = curry(2, (a, b) => a.concat(b));

// flip :: (a -> b -> c) -> b -> a -> c
export const flip = curry(2, (fn, a, b) => fn(b, a));

// append :: String -> String -> String
export const append = flip(concat);

// eq :: Eq a => a -> a -> Boolean;
export const eq = curry(2, (a, b) => a === b);

// deq :: Deq a => a -> a -> Boolean;
export const deq = curry(2, (a, b) => a !== b);

// filter :: ( a -> Boolean) -> [a] -> [a]
export const filter = curry(2, (fn, xs) => xs.filter(fn));

// forEach :: (a -> ()) -> [a] ->()
export const forEach = curry(2, (fn, xs) => xs.forEach(fn));

// head :: [a] -> a;
export const head = xs => xs[0];

// intercalate :: String -> [String] -> String
export const intercalate = curry(2, (str, xs) => xs.join(str));

// join :: Monad m => m (m a) -> m a
export const join = m => m.join(m);

// last :: [a] -> a
export const last = xs => xs[xs.length - 1];

// map : Functor f => (a -> b) -> f a -> f b
export const map = curry(2, (fn, f) => f.map(fn));

// match :: RegExp -> String -> Boolean
export const match = curry(2, (re, str) => re.test(str));

// prop :: String -> Object -> a
export const prop = curry(2, (p, obj) => obj[p]);

// reduce :: (b -> a -> b) -> b -> [a] -> b
export const reduce = curry(3, (fn, zero, xs) => xs.reduce(fn, zero));

// replace :: RegExp -> String -> String -> String
export const replace = curry(3, (re, rpl, str) => str.replace(re, rpl));

// reverse :: [a] -> [a]
export const reverse = x => (Array.isArray(x) ? x.reverse() : x.split('').reverse().join(''));

// safeHead :: [a] -> Maybe a
export const safeHead = compose(Maybe.fromNullable, head);

// safeLast :: [a] -> Maybe a
export const safeLast = compose(Maybe.fromNullable, last);

// safeProp :: String -> Object -> Maybe a
export const safeProp = curry(2, (p, obj = {}) => compose(Maybe.fromNullable, prop(p))(obj));

// sortBy :: Ord b => (a -> b) ->[a] -> [a]
export const sortBy = curry(2, (fn, xs) => xs.sort((a, b) => {
    if (fn(a) === fn(b)) {
        return 0;
    }

    return fn(a) > fn(b) ? 1 : -1;
}));

// split :: String -> String -> [String]
export const split = curry(2, (sep, str) => str.split(sep));

// take :: Number -> [a] -> [a]
export const take = curry(2, (n, xs) => xs.slice(0, n));

// toLowerCase :: String -> String
export const toLowerCase = s => s.toLowerCase();

// toString :: a -> String
export const toString = String;

// toUpperCase :: String -> String
export const toUpperCase = s => s.toUpperCase();

// length :: String -> Number
export const length = str => str.length;