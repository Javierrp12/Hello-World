import { Default, Service, PTService, PTDeveloper } from '../Datastore/StateData/userLevelTypes';
import { compose, curry, identity } from 'folktale/core/lambda';
import { safeProp, safeHead, chain, split, intercalate, eq, toLowerCase, prop, map, concat, filter, reduce, sortBy, replace, toString, length, deq } from './pointfreeUtilities';
import Maybe from 'folktale/maybe';
import Result from 'folktale/result';
import { task } from 'folktale/concurrency/task';
import Axios from 'axios';

// alt :: (a -> b) -> (a -> b) -> a -> a
export const alt = curry(3, (fn1, fn2, val) => fn1(val) || fn2(val));

// altBo :: (a -> b) -> (a -> b) -> a -> a
export const altBo = curry(3, (fn1, fn2, val) => {
  const checkForFalse = (x) => (eq(toString(x), 'false') ? 'false' : x);
  return checkForFalse(fn1(val)) || checkForFalse(fn2(val));
});

// fork :: (a -> b) -> (a -> b) -> (a -> b) -> a -> a
export const fork = curry(4, (join, fn1, fn2, val) => join(fn1(val), fn2(val)));

// checkObjectData :: m  -> Boolean
export const checkObjectData = (m) => {
  return m.matchWith({
    Just: () => true,
    Nothing: () => false
  });
};

// checkAppData :: Object -> Boolean
export const checkAppData = compose(checkObjectData, safeProp('project'));

// checkSystemData :: Object -> Boolean
export const checkSystemData = compose(checkObjectData, safeProp('hostname'));

// printWindow :: Maybe a -> _
export const printWindow = (m) => {
  m.print();
};

// reloadWindow :: Maybe a -> _
export const reloadWindow = (m) => {
  m.reload();
};

// maybeA :: a -> Maybe a
export const maybeA = (a) => Maybe.fromNullable(a);

// getKeysObject :: Object -> [String]
export const getKeyObject = (obj) => Object.keys(obj);

// safeGetKeysObject :: Object -> [String]
export const safeGetKeysObject = (obj = {}) => compose(Maybe.fromNullable, getKeyObject)(obj);

// getValuesObject :: Object -> [a]
export const getValuesObject = (obj) => Object.values(obj);

// safeGetValuesObject :: Object -> [a]
export const safeGetValuesObject = (obj = {}) => compose(Maybe.fromNullable, getValuesObject)(obj);

// getFirstValueOption :: [a] -> [String]
export const getFirstValueOption = compose(chain(safeProp('value')), safeHead);

// getUserLevelInt :: String -> Int
export const userLevelStringtoInt = (userLevel) => {
  const userLevels = {
    [Default]: 3,
    [Service]: 2,
    [PTService]: 1,
    [PTDeveloper]: 0
  };
  return safeProp(userLevel, userLevels).getOrElse(3);
};

// filterPerUserLevel :: String -> String -> Boolean
export const filterPerUserLevel = curry(2, (currentUserLevel, userlevel) => userLevelStringtoInt(currentUserLevel) <= userLevelStringtoInt(userlevel));

// objectSearch :: String -> Object -> a
export const objectSearch = curry(2, (p, obj = {}) => {
  const [first, ...remaning] = split('.', p);

  if (remaning.length > 0) {
    return objectSearch(intercalate('.', remaning), obj[first]);
  }
  return obj[first];
});

// safeObjectSearch :: String -> Object -> Maybe a
export const safeObjectSearch = curry(2, (p, obj = {}) => compose(Maybe.fromNullable, objectSearch(p))(obj));

// addComponentKeyToComponent :: Array => Array => Object => [Array]
export const addComponentKeyToComponent = curry(3, (ys, acc, x) => {
  acc = [...acc, { ...ys[x], componentKey: x }];
  return acc;
});

// deleteComponent :: String-> Object -> [Object]
export const deleteComponent = curry(2, (component = '', obj = {}) => {
  return {
    component,
    key: safeObjectSearch('currentTarget.attrs.componentKey', obj).getOrElse('')
  };
});

// deleteAnalog :: String-> Object -> [Object]
export const deleteAnalog = curry(2, (component = '', obj = {}) => {
  return {
    component,
    key: safeObjectSearch('currentTarget.attrs.componentKey', obj).getOrElse(''),
    module: safeObjectSearch('currentTarget.attrs.analogModule', obj).getOrElse(''),
    name: safeObjectSearch('currentTarget.attrs.analogName', obj).getOrElse('')
  };
});

// deleteDigital :: String-> Object -> [Object]
export const deleteDigital = curry(2, (component = '', obj = {}) => {
  return {
    component,
    key: safeObjectSearch('currentTarget.attrs.componentKey', obj).getOrElse(''),
    module: safeObjectSearch('currentTarget.attrs.digitalModule', obj).getOrElse(''),
    name: safeObjectSearch('currentTarget.attrs.digitalName', obj).getOrElse('')
  };
});

//dragEndComponent :: String-> Object -> [Object]
export const dragEndComponent = curry(2, (component = '', obj = {}) => {
  return {
    component,
    key: safeObjectSearch('currentTarget.attrs.componentKey', obj).getOrElse(''),
    xPosition: safeObjectSearch('currentTarget.attrs.x', obj).getOrElse(1),
    yPosition: safeObjectSearch('currentTarget.attrs.y', obj).getOrElse(1)
  };
});

//dragEndAnalog :: String-> Object -> [Object]
export const dragEndAnalog = curry(2, (component = '', obj = {}) => {
  return {
    component,
    datastore: safeObjectSearch('currentTarget.attrs.analogDatastore', obj).getOrElse(''),
    category: safeObjectSearch('currentTarget.attrs.analogCategory', obj).getOrElse(''),
    module: safeObjectSearch('currentTarget.attrs.analogModule', obj).getOrElse(''),
    name: safeObjectSearch('currentTarget.attrs.analogName', obj).getOrElse(''),
    xPosition: safeObjectSearch('currentTarget.attrs.x', obj).getOrElse(1),
    yPosition: safeObjectSearch('currentTarget.attrs.y', obj).getOrElse(1)
  };
});

//dragEndDigital :: String-> Object -> [Object]
export const dragEndDigital = curry(2, (component = '', obj = {}) => {
  return {
    component,
    datastore: safeObjectSearch('currentTarget.attrs.digitalDatastore', obj).getOrElse(''),
    category: safeObjectSearch('currentTarget.attrs.digitalCategory', obj).getOrElse(''),
    module: safeObjectSearch('currentTarget.attrs.digitalModule', obj).getOrElse(''),
    name: safeObjectSearch('currentTarget.attrs.digitalName', obj).getOrElse(''),
    xPosition: safeObjectSearch('currentTarget.attrs.x', obj).getOrElse(1),
    yPosition: safeObjectSearch('currentTarget.attrs.y', obj).getOrElse(1)
  };
});

//SizeEndComponent :: String-> Object -> [Object]
export const SizeEndComponent = curry(2, (component = '', obj = {}) => {
  const checksizeChange = curry(2, (currentSize = 1, factor = 1) => Math.round(currentSize * factor * 100) / 100);

  return {
    component,
    key: safeObjectSearch('currentTarget.attrs.componentKey', obj).getOrElse(''),
    height: checksizeChange(safeObjectSearch('currentTarget.attrs.height', obj).getOrElse(1), safeObjectSearch('currentTarget.attrs.scaleY', obj).getOrElse(1)),
    width: checksizeChange(safeObjectSearch('currentTarget.attrs.width', obj).getOrElse(1), safeObjectSearch('currentTarget.attrs.scaleX', obj).getOrElse(1))
  };
});

//SizeEndConnection :: Object -> String -> Object -> [Object]
export const SizeEndConnection = curry(3, (x, component = '', obj = {}) => {
  const checksizeChange = curry(4, (connection, type, currentSize = 1, factor = 1) => {
    if ((eq(toLowerCase(prop('orientation', connection)), 'horizontal') && eq(toLowerCase(type), 'height')) || (eq(toLowerCase(prop('orientation', connection)), 'vertical') && eq(toLowerCase(type), 'width'))) {
      return currentSize;
    }
    return Math.round(currentSize * factor * 100) / 100;
  });

  return {
    component,
    key: safeObjectSearch('currentTarget.attrs.componentKey', obj).getOrElse(''),
    height: checksizeChange(x, 'height', safeObjectSearch('currentTarget.attrs.height', obj).getOrElse(1), safeObjectSearch('currentTarget.attrs.scaleY', obj).getOrElse(1)),
    width: checksizeChange(x, 'width', safeObjectSearch('currentTarget.attrs.width', obj).getOrElse(1), safeObjectSearch('currentTarget.attrs.scaleX', obj).getOrElse(1))
  };
});

// checkComponentCondition :: Boolean -> Object -> Either a
export const checkComponentCondition = curry(2, (cond = true, obj = {}) => (eq(cond, true) ? Result.Ok(obj) : Result.Error('Error')));

// checkConditionDbClick :: Booelan -> String -> Object -> Either a
export const checkConditionDbClick = curry(3, (cond = true, str = '', obj = {}) => (eq(cond, false) ? Result.Ok(str) : Result.Error(obj)));

// checkComponentType :: (a -> b) -> String -> String -> Either a -> _
export const checkComponentType = curry(4, (fn, module, MU, x) => {
  if (eq(x, 'Module')) {
    fn(module);
  }
  if (eq(x, 'Contactors')) {
    fn(MU);
  }
});

// createArrayComponents :: Array => [Array]
export const createArrayComponents = curry(2, (acc, x) => {
  const items = getValuesObject(x);
  acc = concat(acc, map(identity, items));
  return acc;
});

// objToString :: Object -> [String]
export const objToString = (x) => JSON.stringify(x, null, 4);

// clearComponentData :: Object -> [String]
export const clearComponentData = curry(3, (ys, acc, x) => {
  const { state, isOnline, ...component } = ys[x];
  acc[x] = { ...component, state: 'Undefined', isOnline: component.type === 'Info' || component.type === 'Legend' ? false : true };
  return acc;
});

// clearComponentData :: Object -> [String]
export const clearAnalogValuesData = curry(4, (z, y, acc, x) => {
  const { value, ...analogValue } = z[y][x];
  acc[x] = { ...analogValue, value: '0' };
  return acc;
});

// clearComponentData :: Object -> [String]
export const clearDigitalFlagsData = curry(4, (z, y, acc, x) => {
  const { status, ...digitalFlag } = z[y][x];
  acc[x] = { ...digitalFlag, status: false };
  return acc;
});

// clearComponentData :: Object -> [String]
export const clearData = curry(4, (fn, ys, acc, x) => {
  const ysKeys = getKeyObject(ys[x]);
  acc[x] = ysKeys.reduce(fn(ys, x), {});
  return acc;
});

// schematicFormat :: String -> String -> String -> String -> String -> String -> [String]
export const schematicFormat = curry(6, (schematicComponents, schematicExtraComponents, schematicConnections, schematicAnalogValues, schematicDigitalFlags, format) =>
  format.replace('schematicComponents', schematicComponents).replace('schematicExtraComponents', schematicExtraComponents).replace('schematicConnections', schematicConnections).replace('schematicAnalogValues', schematicAnalogValues).replace('schematicDigitalFlags', schematicDigitalFlags)
);

// titleText :: String -> String -> String -> [String]
export const titleText = curry(3, (str, separator, what) => `${what}${separator} ${str}`);

// getFirstModule :: Object -> a
export const getFirstModule = compose(chain(safeHead), safeGetKeysObject);

// getModuleSignals :: Object -> String -> String -> String -> [Array]
export const getModuleSignals = (signals, module, type, userlevel) => {
  const getSelectedSignals = curry(3, (signals, module, type) => signals[module][type]);
  const createArraySignals = curry(3, (_signals, _acc, _datastore) => {
    const addPropertiesToEntries = curry(4, (__signals, __datastore, __acc, __category) => {
      const filterStrings = (entry) => typeof entry !== 'string';
      const addDatastoreCategory = (xs) => ({ ...xs, datastore: __datastore, category: __category });
      const filterInvalidEntriesAddProperties = compose(map(addDatastoreCategory), filter(filterStrings));
      __acc = concat(__acc, filterInvalidEntriesAddProperties(getValuesObject(_signals[__datastore][__category])));
      return __acc;
    });
    const createArray = reduce(addPropertiesToEntries(getSelectedSignals(signals, module, type), _datastore), []);
    _acc = concat(_acc, createArray(getKeyObject(_signals[_datastore])));
    return _acc;
  });
  const filterByUserLevel = (entry) => userLevelStringtoInt(userlevel) <= userLevelStringtoInt(entry.visibleBy);
  const sortByName = (x) => toLowerCase(x.name);
  const geModulesSignals = compose(sortBy(sortByName), compose(compose(filter(filterByUserLevel), reduce(createArraySignals(getSelectedSignals(signals, module, type)), [])), compose(sortBy(identity), getKeyObject)));
  return geModulesSignals(getSelectedSignals(signals, module, type));
};

// getModuleSignalsSnapshot :: Object -> String -> String -> String -> [Array]
export const getModuleSignalsSnapshot = (signalsData) => {
  const getDatastores = compose(map(sortBy(identity)), safeGetKeysObject);
  const filterDatastores = curry(3, (signals, acc_datastores, datastore) => {
    const getcategories = compose(map(sortBy(identity)), safeGetKeysObject);
    const filterCategories = curry(3, (_signals, acc_categories, category) => {
      const filterSignals = curry(3, (__signals, acc_signals, signal) => {
        acc_signals = concat(acc_signals, { ...__signals[signal], datastore, category, name: signal });
        return acc_signals;
      });
      const getSignals = compose(map(sortBy(identity)), safeGetKeysObject);
      const getSignalsData = reduce(filterSignals(safeProp(category, _signals).getOrElse({})), []);
      acc_categories = concat(acc_categories, getSignalsData(getSignals(safeProp(category, _signals).getOrElse({})).getOrElse([])));
      return acc_categories;
    });

    const getCategoriesSignals = reduce(filterCategories(safeProp(datastore, signals).getOrElse({})), []);
    acc_datastores = concat(acc_datastores, getCategoriesSignals(getcategories(safeProp(datastore, signals).getOrElse({})).getOrElse([])));
    return acc_datastores;
  });
  const getDatastoreSignals = reduce(filterDatastores(signalsData), []);
  return getDatastoreSignals(getDatastores(signalsData).getOrElse([]));
};

// addComponentData :: m a -> m b -> [m a]
export const addComponentData = curry(2, (a, b) => ({ ...a.getOrElse({}), ...b }));

// getIconColumn :: String -> String -> Boolean -> [String]
export const getIconColumn = curry(4, (direction, icon, currentColumn, column) => (eq(currentColumn, column) ? `${icon}-${direction}` : `${icon}`));

// getColumnDirection :: String -> String -> [String]
export const getColumnDirection = curry(2, (column, currentColumn) => (eq(currentColumn, column) ? 'up' : 'down'));

// checkDirection :: String -> String -> [String]
export const checkDirection = curry(2, (direction, currentDirection) => (eq(direction, currentDirection) ? 'down' : currentDirection));

// newArray :: [a] -> [a]
export const newArray = map(identity);

// safeNewArray :: [a] -> Maybe a
export const safeNewArray = (x = []) => Maybe.fromNullable(x);

// byColumn :: String -> [a] -> [a]
export const byColumn = curry(3, (column, dateColumn, a) => (column === dateColumn ? Date.parse(a[column].replace(' ', 'T')) : a[column]));

// reverseArray :: String -> [a]
export const reverseArray = curry(2, (direction, x) => (direction === 'up' ? x.reverse() : x));

// historylogEntryToString :: Object ->[String]
export const historylogEntryToString = (x) => `DateTime: ${x.dateTime}, User: ${x.user}, Action: ${x.action}, Info: ${x.info}, Module: ${x.moduleName}`;

// historyLogFormat :: String -> String -> String -> String -> [String]
export const historyLogFormat = curry(4, (projectname, projectPackage, data, format) => format.replace('Project', projectname).replace('Package', projectPackage).replace('Data', data));

// filterModule :: Boolean -> String -> [a] -> [a]
export const filterModule = curry(3, (showAllModules, module, modules) => (eq(showAllModules, true) ? modules : filter(eq(module), modules)));

// getModulesArray :: Object -> String -> [a]
export const getModulesArray = curry(3, (ys, acc, module) => {
  acc = concat(
    acc,
    ys[module].map((entry) => ({ ...entry, module: module }))
  );
  return acc;
});

// addSeverityProperty :: Object -> [a]
export const addSeverityProperty = curry(3, (ys, acc, x) => {
  const signalName = eq3(safeProp('name', x).getOrElse(''), 'name');
  const filterSignal = compose(safeHead, filter(signalName));
  acc = concat(acc, { ...x, severity: safeProp('severity', filterSignal(ys).getOrElse({})).getOrElse('None') });
  return acc;
});

// eq2 :: Boolean -> String -> Object -> Boolean
export const eq2 = curry(3, (boolean, key, x) => eq(boolean, safeProp(key, x).getOrElse(false)));

// eq3 :: String -> String -> Object -> Boolean
export const eq3 = curry(3, (what, key, x) => eq(what, safeProp(key, x).getOrElse('')));

// filterSearchString :: String -> String -> Object -> [Boolean];
export const filterSearchStringSignal = curry(3, (str, key, x) => (eq(str, '') ? true : toLowerCase(safeProp(key, x).getOrElse('')).includes(toLowerCase(str))));

// getForceFlag :: String -> Object -> Object -> String
export const getForceFlag = (flag, signal, info) => {
  const getFlag = safeObjectSearch(`${safeProp('datastore', signal).getOrElse('')}.${safeProp('category', signal).getOrElse('')}.${safeProp('name', signal).getOrElse('')}`);
  return getFlag(info).matchWith({
    Just: () => flag,
    Nothing: () => ''
  });
};

// getDigitalStatus :: String -> Object -> Object -> String
export const getDigitalStatus = (flag, signal, info) => {
  const valueTrue = (boolean) => (eq(boolean, true) ? Maybe.Just(true) : Maybe.Nothing(false));
  const getFlag = compose(chain(valueTrue), safeObjectSearch(`${safeProp('name', signal).getOrElse('')}`));
  return getFlag(info).matchWith({
    Just: () => safeProp(flag, signal).getOrElse(),
    Nothing: () => ''
  });
};

// getAnalogValue :: String -> Object -> Object -> String
export const getAnalogValue = (signal, info) => {
  const getFlag = safeObjectSearch(`${safeProp('name', signal).getOrElse('')}`);
  return getFlag(info).matchWith({
    Just: (value) => value.getOrElse(),
    Nothing: () => safeProp('value', signal).getOrElse(0)
  });
};

// filterActiveSignalIfActive :: Boolean -> String -> Object -> Boolean
export const filterActiveSignalIfActive = curry(3, (boolean, key, x) => (eq(boolean, false) ? true : eq2(true, key, x)));

// filterSignal :: String ->Object ->Boolean
export const filterSignal = curry(2, (str = '', x) => eq(str, `${x.module}_${x.name}`));

// addEntryToArray :: String -> Array => Array => Object => [Array]
export const addEntryToArray = curry(3, (key, ys, acc, x) => {
  const filterdata = compose(safeHead, filter(eq3(x, key)));
  filterdata(ys).matchWith({
    Just: (value) => (acc = concat(acc, value.getOrElse([]))),
    Nothing: () => {}
  });
  return acc;
});

// dateTimeFormat :: String -> [String]
export const dateTimeFormat = (dateTime) => replace(' ', 'T', dateTime);

// getDateTime :: String -> Date
export const getDateTime = (dateTime) => new Date(dateTime);

// serializeClockTime :: Date -> Object
export const serializeClockTime = (date) => ({
  hours: date.getHours(),
  minutes: date.getMinutes(),
  seconds: date.getSeconds()
});

// serializeClockDateTime :: Date -> Object
export const serializeClockDateTime = (date) => ({
  year: date.getFullYear(),
  month: date.getMonth() + 1,
  day: date.getDate(),
  hours: date.getHours(),
  minutes: date.getMinutes(),
  seconds: date.getSeconds()
});

// prependZero :: String -> Object -> [Object]
export const prependZero = curry(2, (key, clockTime) => ({ ...clockTime, [key]: clockTime[key] < 10 ? '0' + clockTime[key] : clockTime[key] }));

// formatDateTimeClock :: String -> Object -> [String]
export const formatDateTimeClock = curry(2, (format, datetime) => format.replace('YYYY', datetime.year).replace('MM', datetime.month).replace('DD', datetime.day).replace('hh', datetime.hours).replace('mm', datetime.minutes).replace('ss', datetime.seconds));

// getOscilloscopeChannelsData :: String ->[a] -> Object -> Date -> [String]
export const getOscilloscopeChannelsData = curry(4, (modelType, channels, currentDate, oscilloscopeData) => {
  const prepareChannelValues = curry(3, (channel, acc, x) => {
    const getValue = safeObjectSearch(`${modelType}.${safeProp('datastore', channel).getOrElse('')}.${safeProp('category', channel).getOrElse('')}.${safeProp('signal', channel).getOrElse('')}`);
    const getSignalValue = alt(prop('value'), prop('status'));
    acc = concat(acc, getSignalValue(getValue(x).getOrElse({})));
    return acc;
  });
  const prepareChannelExport = curry(4, (currentDate, acc, x, index) => {
    const formatClock = curry(2, (format, time) => format.replace('hh', time.hours).replace('mm', time.minutes).replace('ss', time.seconds));
    const getFormatDate = compose(formatClock('hh:mm:ss'), compose(compose(compose(prependZero('hours'), prependZero('minutes')), prependZero('seconds')), serializeClockTime));
    const subtractSecond = (x) => x.setSeconds(x.getSeconds() - index);
    const subtractSecondToDate = compose(getFormatDate, compose(getDateTime, subtractSecond));
    const getTime = compose(getDateTime, dateTimeFormat);
    const getvalueTime = compose(subtractSecondToDate, getTime);
    acc = concat(acc, [`;;${index};${getvalueTime(currentDate)};${replace('.', ',', toString(x))}`]);
    return acc;
  });
  const prepareChannelsData = curry(3, (channels, acc, x) => {
    const getChannelValues = compose(
      compose(
        reduce(prepareChannelExport(currentDate), []),
        reduce((acc, x) => [x].concat(acc), [])
      ),
      reduce(prepareChannelValues(channels[x]), [])
    );
    acc = concat(acc, intercalate('\n', [`\n;Channel; ${x}\n;;Module; ${safeProp('module', channels[x]).getOrElse('')}\n;;Index;Time;${safeProp('signal', channels[x]).getOrElse('')}(${safeProp('unit', channels[x]).getOrElse('(-)')})\n`]));
    acc = concat(acc, intercalate('\n', getChannelValues(safeProp(safeProp('module', channels[x]).getOrElse(''), oscilloscopeData).getOrElse([]))));
    return acc;
  });
  const getOscilloscopeData = reduce(prepareChannelsData(channels), []);
  return intercalate('', getOscilloscopeData(safeGetKeysObject(channels).getOrElse([])));
});

// getOscilloscopeChannelDatasets :: String ->[a] -> Object -> Date -> [String]
export const getOscilloscopeChannelDatasets = curry(4, (modelType, channels, currentDate, oscilloscopeData) => {
  const colors = {
    Ch1: '#4169e1',
    Ch2: '#228b22',
    Ch3: '#daa520',
    Ch4: '#6a5acd',
    Ch5: '#a0522d',
    Ch6: '#dc143c',
    Ch7: 'ff7f50',
    Ch8: '#800080'
  };
  const maximumPointsInScope = 30;
  const prepareChannelValues = curry(3, (channel, acc, x) => {
    const getValue = safeObjectSearch(`${modelType}.${safeProp('datastore', channel).getOrElse('')}.${safeProp('category', channel).getOrElse('')}.${safeProp('signal', channel).getOrElse('')}`);
    const getSignalValue = alt(prop('value'), prop('status'));
    acc = concat(acc, getSignalValue(getValue(x).getOrElse({})));
    return acc;
  });
  const prepareChannelExport = curry(4, (currentDate, acc, x, index) => {
    const subtractSecond = (x) => x.setSeconds(x.getSeconds() - index);
    const subtractSecondToDate = compose(getDateTime, subtractSecond);
    const getTime = compose(getDateTime, dateTimeFormat);
    const getvalueTime = compose(subtractSecondToDate, getTime);
    if (maximumPointsInScope - index >= 0) {
      /* Maximum 30 points in the chartView */
      acc = concat(acc, { x: getvalueTime(currentDate), y: x });
    }
    return acc;
  });
  const prepareChannelsData = curry(3, (channels, acc, x) => {
    const offsetScallingFactor = (value) => value / safeProp('scaleFactor', channels[x]).getOrElse(1) + safeProp('offset', channels[x]).getOrElse(0);
    const getChannelValues = compose(map(offsetScallingFactor), reduce(prepareChannelValues(channels[x]), []));
    const getDatasetData = compose(map(reduce(prepareChannelExport(currentDate), [])), compose(map(reduce((acc, x) => [x].concat(acc), [])), compose(map(getChannelValues), safeNewArray)));
    acc = concat(acc, [
      {
        label: `${x}-${safeProp('module', channels[x]).getOrElse('')} ${safeProp('signal', channels[x]).getOrElse('')}(${safeProp('unit', channels[x]).getOrElse('')})`,
        data: getDatasetData(safeProp(safeProp('module', channels[x]).getOrElse(''), oscilloscopeData).getOrElse([])).getOrElse([]),
        fill: 'none',
        pointRadius: 2,
        borderWidth: 1,
        lineTension: 0,
        backgroundColor: safeProp(x, colors).getOrElse(''),
        borderColor: safeProp(x, colors).getOrElse('')
      }
    ]);
    return acc;
  });
  const getOscilloscopeData = compose(map(reduce(prepareChannelsData(channels), [])), safeNewArray);
  return getOscilloscopeData(safeGetKeysObject(channels).getOrElse([])).getOrElse([]);
});

// findeSelectedSignal :: String -> Object -> [a]
export const findeSelectedSignal = curry(2, (what, obj = {}) => eq(what, `${safeProp('category', obj).getOrElse('')}_${safeProp('name', obj).getOrElse('')}`));

// getParameterFlag :: String -> String -> M a -> String
export const getParameterFlag = curry(3, (flag, key, info) => {
  const getFlag = safeProp(key);
  return getFlag(info.getOrElse({})).matchWith({
    Just: () => flag,
    Nothing: () => ''
  });
});

// checkValue :: Boolean -> Object -> Either a
export const checkValue = (value) => (isNaN(value) || eq('', value) ? Result.Ok('disabled') : Result.Error('valid number'));

// filterCategoriesPerUserLevel :: Object -> String -> String -> Boolean
export const filterCategoriesPerUserLevel = curry(3, (categories, userLevel, category) => filterPerUserLevel(userLevel, safeObjectSearch(`${category}.visibleBy`, categories).getOrElse('')));

// checkCategory :: String -> String -> Object -> Either a
export const checkCategory = curry(3, (category, userLevel, categoryObj) => (eq(filterPerUserLevel(userLevel, safeObjectSearch(`${category}.visibleBy`, categoryObj).getOrElse('')), true) ? Result.Ok(category) : Result.Error('Invalid Category')));

// filterParameterPerUserLevelVisibility :: String -> Object -> Boolean
export const filterParameterPerUserLevelVisibility = curry(3, (userlevel, key, parameter) => filterPerUserLevel(userlevel, safeProp(key, parameter).getOrElse()));

// parametersFormat :: String -> String -> String -> String -> [String]
export const parametersFormat = curry(4, (projectname, projectPackage, data, format) => format.replace('Project', projectname).replace('Package', projectPackage).replace('Data', data));

// parameterEntryToString :: String -> Object -> Object -> Object -> Object ->[a]
export const parameterEntryToString = curry(7, (userlevel, appInfo, systemInfo, modulesparameterData, modulesParametersInfoData, acc, module) => {
  const getRUValue = compose(chain(safeHead), chain(safeGetValuesObject));
  const getVersion = compose(chain(safeHead), chain(safeProp('SWversions')));
  const filterRU = compose(chain(safeHead), map(filter(eq3(module, 'name'))));
  const getRUVersion = compose(compose(getRUValue, compose(getVersion, filterRU)), safeObjectSearch('software.RUs'));
  acc = concat(acc, [`Module: ${module}, Version: ${getRUVersion(appInfo).getOrElse() || safeProp('os_version', systemInfo).getOrElse()}`]);

  const getCategoriesData = curry(4, (categoriesInfoData, categoriesData, acc, category) => {
    acc = concat(acc, [`\tCategory: ${category}`]);

    const getParametersData = curry(4, (parametersInfoData, parametersData, acc, parameter) => {
      const parameterData = safeProp(parameter, parametersData).getOrElse({});
      const getFlagParameter = compose(safeHead, compose(chain(filter(eq3(safeProp('name', parameterData).getOrElse(''), 'name'))), safeNewArray));
      const getValue = compose(map(altBo(prop('temp'), prop('stored'))), getFlagParameter);
      const checkDataType = curry(2, (dataType, x) => (eq(dataType, 'Boolean') ? Result.Ok(x) : Result.Error(x)));
      const getDefault = safeProp('defaultValue');
      const getUnit = safeProp('unit');
      const checkUserLevel = safeProp('visibleBy');
      const checkValue = checkDataType(safeProp('dataType', parameterData).getOrElse(''));
      const checkDefault = checkDataType(safeProp('dataType', parameterData).getOrElse(''));
      return eq(filterPerUserLevel(userlevel, checkUserLevel(parameterData).getOrElse('')))
        ? concat(acc, [
            `\t\tParameter name: ${parameter}, Value:${checkValue(getValue(parametersInfoData).getOrElse(safeProp('defaultValue', parameterData).getOrElse('---'))).matchWith({
              Ok: (value) => (eq(typeof value.merge(), 'string') ? toString(eq('1', value.merge())) : value.merge()),
              Error: (value) => value.merge()
            })}, DefaultValue:${checkDefault(getDefault(parameterData).getOrElse('')).matchWith({
              Ok: (value) => toString(eq('1', value.merge())),
              Error: (value) => value.merge()
            })}, Unit:${getUnit(parameterData).getOrElse('---')}`
          ])
        : acc;
    });
    const filterCategory = compose(chain(safeProp('parameters')), chain(safeHead));
    const filterCategoriesInfo = compose(filterCategory, compose(map(filter(eq3(category, 'name'))), safeNewArray));
    const filterStrings = (entry) => entry !== 'visibleBy';
    const getSortedParametersArray = compose(map(filter(filterStrings)), compose(map(sortBy(toLowerCase)), chain(safeGetKeysObject)));
    const getParameterDataArray = map(reduce(getParametersData(filterCategoriesInfo(categoriesInfoData).getOrElse([]), safeProp(category, categoriesData).getOrElse([])), []));
    const getParameters = compose(compose(getParameterDataArray, getSortedParametersArray), safeProp(category));
    acc = concat(acc, getParameters(categoriesData).getOrElse([]));
    return acc;
  });
  const getModuleData = safeProp(module);
  const filterCategoriesUserLevel = map(filter(filterCategoriesPerUserLevel(modulesparameterData, userlevel)));
  const getSortedCategoriesArray = compose(filterCategoriesUserLevel, compose(map(sortBy(toLowerCase)), chain(safeGetKeysObject)));
  const getCategoryDataArray = map(reduce(getCategoriesData(getModuleData(modulesParametersInfoData).getOrElse([]), getModuleData(modulesparameterData).getOrElse([])), []));
  const getcategories = compose(compose(getCategoryDataArray, getSortedCategoriesArray), safeProp(module));
  acc = concat(acc, getcategories(modulesparameterData).getOrElse([]));
  return acc;
});

// parameterChangedEntryToString :: Object -> Object -> Object -> Object ->[a]
export const parameterChangedEntryToString = curry(6, (appInfo, systemInfo, modulesparameterData, modulesParametersInfoData, acc, module) => {
  const getCategoriesData = curry(3, (categoriesData, acc, category) => {
    acc = concat(acc, [`\tCategory: ${safeProp('name', category).getOrElse('')}`]);
    const getParametersData = curry(3, (parametersData, acc, parameter) => {
      const parameterData = safeProp(safeProp('name', parameter).getOrElse(''), parametersData).getOrElse({});
      const getValue = altBo(prop('temp'), prop('stored'));
      const checkDataType = curry(2, (dataType, x) => (eq(dataType, 'Boolean') ? Result.Ok(x) : Result.Error(x)));
      const getDefault = safeProp('defaultValue');
      const checkDefault = checkDataType(safeProp('dataType', parameterData).getOrElse(''));
      const getUnit = safeProp('unit');
      acc = concat(acc, [
        `\t\tParameter name: ${safeProp('name', parameter).getOrElse('')}, Value: ${getValue(parameter)}, DefaultValue: ${checkDefault(getDefault(parameterData).getOrElse('')).matchWith({
          Ok: (value) => toString(eq('1', value.merge())),
          Error: (value) => value.merge()
        })}, Unit: ${getUnit(parameterData).getOrElse('---')}, Parameter Changed: ${getParameterFlag('temporarily', 'temp', maybeA(parameter))} ${getParameterFlag('permanent', 'stored', maybeA(parameter))}`
      ]);
      return acc;
    });
    const toLowerCaseParameter = (x) => toLowerCase(safeProp('name', x).getOrElse(''));
    const getParameters = compose(compose(map(reduce(getParametersData(safeProp(safeProp('name', category).getOrElse(''), categoriesData).getOrElse([])), [])), map(sortBy(toLowerCaseParameter))), safeProp('parameters'));
    acc = concat(acc, getParameters(category).getOrElse([]));
    return acc;
  });

  const getRUValue = compose(chain(safeHead), chain(safeGetValuesObject));
  const getVersion = compose(chain(safeHead), chain(safeProp('SWversions')));
  const filterRU = compose(chain(safeHead), map(filter(eq3(module, 'name'))));
  const getRUVersion = compose(compose(getRUValue, compose(getVersion, filterRU)), safeObjectSearch('software.RUs'));
  acc = concat(acc, [`Module: ${module}, Version: ${getRUVersion(appInfo).getOrElse() || safeProp('os_version', systemInfo).getOrElse()}`]);

  const getModuleData = safeProp(module);
  const toLowerCaseParameter = (x) => toLowerCase(safeProp('name', x).getOrElse(''));
  const getcategories = compose(compose(map(reduce(getCategoriesData(getModuleData(modulesparameterData).getOrElse([])), [])), map(sortBy(toLowerCaseParameter))), safeProp(module));
  acc = concat(acc, getcategories(modulesParametersInfoData).getOrElse([]));
  return acc;
});

// parameterChangedTemporarilyEntryToJSON :: Object -> Object -> Object ->[a]
export const parameterChangedTemporarilyEntryToJSON = curry(5, (appInfo, systemInfo, modulesParametersInfoData, acc, module) => {
  const getRUValue = compose(chain(safeHead), chain(safeGetValuesObject));
  const getVersion = compose(chain(safeHead), chain(safeProp('SWversions')));
  const filterRU = compose(chain(safeHead), map(filter(eq3(module, 'name'))));
  const getRUVersion = compose(compose(getRUValue, compose(getVersion, filterRU)), safeObjectSearch('software.RUs'));

  const getCategoriesData = curry(2, (acc, category) => {
    const getParametersData = curry(3, (category, acc, parameter) => {
      return eq(safeProp('temp', parameter).getOrElse(), undefined)
        ? acc
        : (acc = concat(acc, {
            category: safeProp('name', category).getOrElse(''),
            name: safeProp('name', parameter).getOrElse(''),
            value: safeProp('temp', parameter).getOrElse('')
          }));
    });
    const toLowerCaseParameter = (x) => toLowerCase(safeProp('name', x).getOrElse(''));
    const getParameters = compose(compose(map(reduce(getParametersData(category), [])), map(sortBy(toLowerCaseParameter))), safeProp('parameters'));
    acc = concat(acc, getParameters(category).getOrElse({}));
    return acc;
  });

  const toLowerCaseParameter = (x) => toLowerCase(safeProp('name', x).getOrElse(''));
  const getcategories = compose(compose(map(reduce(getCategoriesData, [])), map(sortBy(toLowerCaseParameter))), safeProp(module));
  acc = concat(acc, {
    module,
    version: getRUVersion(appInfo).getOrElse() || safeProp('os_version', systemInfo).getOrElse(),
    parameters: getcategories(modulesParametersInfoData).getOrElse([])
  });
  return acc;
});

// readFile :: Object -> Task
export const readFile = (file) =>
  task((resolver) => {
    let reader = new FileReader();
    reader.readAsText(file);

    reader.onload = (event) => {
      resolver.resolve(event.target.result.toString());
    };

    reader.onerror = (event) => {
      resolver.reject(event.target.error);
    };
  });

// safeParseJSON :: String -> [Object]
export const safeParseJSON = (x) => {
  try {
    return Result.Ok(JSON.parse(x));
  } catch (error) {
    return Result.Error(error);
  }
};

// validateResultParameterJSON :: Object -> Either a
export const validateResultParameterJSON = (x, appInfo, systemInfo, modulesParametersData, userlevel) => {
  const { project, modules } = x;
  const checkProject = (name) => (eq(name, safeObjectSearch('project.name', appInfo).getOrElse('')) ? Result.Ok(name) : Result.Error('Project file does not match with the device project.'));
  const checkVersion = curry(2, (modules, _) => {
    const checkData = (acc, x) => {
      const getRUValue = compose(chain(safeHead), chain(safeGetValuesObject));
      const getVersion = compose(chain(safeHead), chain(safeProp('SWversions')));
      const filterRU = compose(chain(safeHead), map(filter(eq3(safeProp('module', x).getOrElse(''), 'name'))));
      const getRUVersion = compose(compose(getRUValue, compose(getVersion, filterRU)), safeObjectSearch('software.RUs'));
      return !eq(safeProp('version', x).getOrElse(''), getRUVersion(appInfo).getOrElse() || safeProp('os_version', systemInfo).getOrElse())
        ? concat(acc, Result.Error(`Version mismatch for module ${safeProp('module', x).getOrElse('')}. File version (${safeProp('version', x).getOrElse('')}), Device version (${getRUVersion(appInfo).getOrElse() || safeProp('os_version', systemInfo).getOrElse()}).`))
        : acc;
    };
    const checkProjectModules = compose(safeHead, reduce(checkData, []));
    return checkProjectModules(modules).getOrElse(Result.Ok(modules));
  });
  const checkParameterCategories = (modules) => {
    const checkData = (acc, x) => {
      const checkParameters = curry(3, (parametersData, module, acc, x) => {
        const getCategory = safeProp(safeProp('category', x).getOrElse(''));
        return eq(getCategory(parametersData).getOrElse(), undefined) || eq(filterPerUserLevel(userlevel, safeProp('visibleBy', getCategory(parametersData).getOrElse('')).getOrElse('')), false)
          ? concat(acc, Result.Error(`Category "${safeProp('category', x).getOrElse('')}" was not found on module ${module} or with the current userlevel it is no possible to change it.`))
          : acc;
      });
      const getModuleData = safeProp(safeProp('module', x).getOrElse(''));
      const checkModulesParameter = compose(safeHead, reduce(checkParameters(getModuleData(modulesParametersData).getOrElse({}), safeProp('module', x).getOrElse('')), []));
      acc = concat(acc, checkModulesParameter(safeProp('parameters', x).getOrElse([])).getOrElse([]));
      return acc;
    };
    const checkProjectModules = compose(safeHead, reduce(checkData, []));
    return checkProjectModules(modules).getOrElse(Result.Ok(modules));
  };
  const checkParameterData = (modules) => {
    const checkData = (acc, x) => {
      const checkParameters = curry(4, (parametersData, module, acc, x) => {
        const getCategory = safeProp(safeProp('category', x).getOrElse(''));
        const getParameter = safeProp('name');
        return eq(safeProp(getParameter(x).getOrElse(''), getCategory(parametersData).getOrElse({})).getOrElse(), undefined) || eq(filterPerUserLevel(userlevel, safeProp('changeableBy', safeProp(getParameter(x).getOrElse(''), getCategory(parametersData).getOrElse({})).getOrElse())), false)
          ? concat(acc, Result.Error(`Parameter "${getParameter(x).getOrElse('')}" was not found on module ${module}, category ${safeProp('category', x).getOrElse('')} or with the current userlevel it is no possible to change it.`))
          : acc;
      });
      const getModuleData = safeProp(safeProp('module', x).getOrElse(''));
      const checkModulesParameter = compose(safeHead, reduce(checkParameters(getModuleData(modulesParametersData).getOrElse({}), safeProp('module', x).getOrElse('')), []));
      acc = concat(acc, checkModulesParameter(safeProp('parameters', x).getOrElse([])).getOrElse([]));
      return acc;
    };
    const checkProjectModules = compose(safeHead, reduce(checkData, []));
    return checkProjectModules(modules).getOrElse(Result.Ok(modules));
  };
  const getParameterData = (modules) => {
    const checkData = (acc, x) => {
      const checkParameters = curry(3, (module, acc, x) => {
        acc = concat(acc, { module, category: safeProp('category', x).getOrElse(''), parameter: safeProp('name', x).getOrElse(''), value: safeProp('value', x).getOrElse('') });
        return acc;
      });
      const checkModulesParameter = compose(safeNewArray, reduce(checkParameters(safeProp('module', x).getOrElse('')), []));
      acc = concat(acc, checkModulesParameter(safeProp('parameters', x).getOrElse([])).getOrElse([]));
      return acc;
    };
    const checkProjectModules = compose(safeNewArray, reduce(checkData, []));
    return Result.Ok(checkProjectModules(modules).getOrElse([]));
  };

  const checkParametersEntries = compose(chain(getParameterData), chain(checkParameterData));
  const checkVersionAndCategories = compose(checkParametersEntries, compose(chain(checkParameterCategories), chain(checkVersion(modules))));
  const validateJson = compose(checkVersionAndCategories, checkProject);
  return validateJson(project);
};

// getRequest :: String -> Number -> Task
export const getRequest = (url) =>
  task((resolver) => {
    const timerId = setTimeout(() => {
      Axios.request({
        method: 'GET',
        url: url
      })
        .then((dataRequest) => {
          if (typeof dataRequest.data !== 'object') {
            throw new Error(`Data should be an "JSON" object, url${url}`);
          }
          resolver.resolve(dataRequest);
        })
        .catch(resolver.reject);
    }, 100);

    resolver.cleanup(() => {
      clearTimeout(timerId);
    });
  });

// getRequestDelay :: String -> Number -> Task
export const getRequestDelay = (url, delay = 1000) =>
  task((resolver) => {
    const timerId = setTimeout(() => {
      console.log('%c Timeout finished', 'color:#04286b; font-size=14px');
      Axios.request({
        method: 'GET',
        url: url
      })
        .then(resolver.resolve)
        .catch(resolver.reject);
    }, delay);

    resolver.cleanup(() => {
      clearTimeout(timerId);
    });
  });

// restartProcess :: String -> Number -> Task
export const restartProcess = (url, delay = 1000) =>
  task((resolver) => {
    const timerId = setTimeout(() => {
      console.log('%c Timeout finished', 'color:#04286b; font-size=14px');
      fetch(url, {
        method: 'HEAD',
        mode: 'no-cors'
      })
        .then(resolver.resolve)
        .catch(resolver.reject);
    }, delay);

    resolver.cleanup(() => {
      clearTimeout(timerId);
    });
  });

// postRequest :: String -> File -> Number -> Task
export const postRequest = (url, file) =>
  task((resolver) => {
    let formData = new FormData();
    formData.append('updatePackage', file);
    const timerId = setTimeout(() => {
      Axios.request({
        method: 'POST',
        url: url,
        data: formData
      })
        .then(resolver.resolve)
        .catch(resolver.reject);
    }, 100);

    resolver.cleanup(() => {
      clearTimeout(timerId);
    });
  });

// checkDataFiles :: String ->m a -> Either a;
export const checkDataFiles = curry(3, (errorMessage, x, _) => {
  return eq(x, undefined) ? Result.Error(errorMessage) : Result.Ok(x);
});

// updateUnitConfig :: Object -> Object -> Object -> _
export const updateUnitConfig = curry(4, (reqData, modules, key, acc, x) => {
  const filterPerModule = compose(chain(safeHead), map(filter(eq3(x, 'module'))));
  const getModulesUnit = compose(chain(safeObjectSearch(`${key}`)), maybeA);
  const getModulesUnitConfigData = compose(chain(safeProp('units')), compose(filterPerModule, getModulesUnit));
  const updateUnit = curry(3, (module, data, _) => {
    module.updateUnitModule(data);
    return Result.Ok('Ok');
  });
  const checkData = compose(chain(checkDataFiles(`Module file missing!. Please check if the module file for the module ${x} is missing.`, safeProp(x, modules).getOrElse(undefined))), checkDataFiles('Units data missing', getModulesUnitConfigData(reqData).getOrElse(undefined)));
  const updateModulesData = compose(chain(updateUnit(safeProp(x, modules).getOrElse(), getModulesUnitConfigData(reqData).getOrElse())), checkData);
  const result = updateModulesData(module);
  return eq(result.merge(), 'Ok') ? acc : (acc = concat(acc, result));
});

// updateSystemConfig :: Object -> Object -> _
export const updateSystemConfig = curry(3, (window, modules, acc, x) => {
  const filterPerModule = compose(chain(safeHead), map(filter(eq3(x, 'name'))));
  const getModulesSystemData = compose(chain(safeObjectSearch(`systemConfig.modules`)), maybeA);
  const getModulesSystemConfigData = compose(chain(safeProp('dataStores')), compose(filterPerModule, getModulesSystemData));
  const updateSystemData = curry(3, (module, data, _) => {
    module.updateSystemData(data);
    return Result.Ok('Ok');
  });
  const checkData = compose(chain(checkDataFiles(`Module file missing!. Please check if the module file for the module ${x} is missing. `, safeProp(x, modules).getOrElse(undefined))), checkDataFiles('System data missing', getModulesSystemConfigData(window).getOrElse(undefined)));
  const updateModulesData = compose(chain(updateSystemData(prop(x, modules), getModulesSystemConfigData(window).getOrElse())), checkData);
  const result = updateModulesData(module);
  return eq(result.merge(), 'Ok') ? acc : (acc = concat(acc, result));
});

// addProperty :: String -> Object -> [Object]
export const addProperty = curry(4, (key, ys, acc, x) => {
  acc = { ...acc, [x.name]: { ...ys[x.name], [key]: x[key] } };
  return acc;
});

// updateOnlineData :: Object -> Object -> _
export const updateOnlineData = curry(4, (window, modules, key, acc, x) => {
  const getModulesOnlineData = compose(chain(safeObjectSearch(`${key}`)), maybeA);
  const updateOnlineData = curry(3, (module, data, _) => {
    module.updateData(data);
    return Result.Ok('Ok');
  });
  const checkData = compose(chain(checkDataFiles(`Module file missing!. Please check if the module file for the module ${x} is missing.`, safeProp(x, modules).getOrElse(undefined))), checkDataFiles('Online data missing', getModulesOnlineData(window).getOrElse(undefined)));
  const updateModulesData = compose(chain(updateOnlineData(prop(x, modules), getModulesOnlineData(window).getOrElse())), checkData);
  const result = updateModulesData(module);
  return eq(result.merge(), 'Ok') ? acc : (acc = concat(acc, result));
});

// getNewEntries :: Object -> [Object]
export const getNewEntries = curry(2, (entries, acc, x) => {
  acc = { ...acc, [x]: safeProp(x, entries).getOrElse({}) };
  return acc;
});

// addNewOsciData :: [a] -> a -> [A]
export const addNewOsciData = curry(2, (newData, storeData) => {
  const LimitPoints = 50;
  const shift = (x) => {
    const [, ...remaning] = x;
    return remaning;
  };
  const osciData = length(storeData) >= LimitPoints ? shift(storeData) : storeData;
  return concat(osciData, newData);
});

// updateComponentsStateData :: Object -> Object -> [Object]
export const updateComponentsStateData = curry(2, (schematicComponents, componentsData) => {
  const updateComponentData = curry(4, (components, data, acc, x) => {
    const getComponentType = safeObjectSearch(`${x}.type`);
    const currentComponent = safeProp(x, components).getOrElse({});
    const filterPerComponent = compose(chain(safeHead), map(filter(eq3(safeProp('name', currentComponent).getOrElse(''), 'name'))));
    switch (getComponentType(components).getOrElse('')) {
      case 'Module':
        const filterPerModule = compose(chain(safeHead), map(filter(eq3(safeProp('module', currentComponent).getOrElse(''), 'name'))));
        const getModuleData = compose(filterPerModule, safeProp('modules'));
        const module = getModuleData(data).getOrElse({});
        acc[x] = { ...currentComponent, state: safeProp('state', module).getOrElse('Undefined'), isOnline: safeProp('isOnline', module).getOrElse('true') };
        break;

      case 'Converter':
        const getConverterData = safeObjectSearch('converter');
        const converter = getConverterData(data).getOrElse({});
        acc[x] = { ...currentComponent, state: safeProp('state', converter).getOrElse('Undefined') };
        break;

      case 'Aif':
        const getAifData = compose(filterPerComponent, safeProp('aif'));
        const aif = getAifData(data).getOrElse({});
        acc[x] = { ...currentComponent, state: safeProp('state', aif).getOrElse('Undefined'), isOnline: safeProp('isOnline', aif).getOrElse('true') };
        break;

      case 'Fan':
        const getFanData = compose(filterPerComponent, safeProp('fans'));
        const fan = getFanData(data).getOrElse({});
        acc[x] = { ...currentComponent, state: safeProp('state', fan).getOrElse('Undefined'), isOnline: safeProp('isOnline', fan).getOrElse('true'), speed: `${safeObjectSearch('speed.value', fan).getOrElse('')} ${safeObjectSearch('speed.unit', fan).getOrElse('')}` };
        break;

      case 'Contactors':
        const getContactorData = compose(filterPerComponent, safeProp('contactors'));
        const contactor = getContactorData(data).getOrElse({});
        acc[x] = { ...currentComponent, state: safeProp('state', contactor).getOrElse('Undefined'), isOnline: safeProp('isOnline', contactor).getOrElse('true'), command: safeProp('command', contactor).getOrElse('open') };
        break;

      case 'Fuse':
        const getFuseData = compose(filterPerComponent, safeProp('fuses'));
        const fuse = getFuseData(data).getOrElse({});
        acc[x] = { ...currentComponent, state: safeProp('state', fuse).getOrElse('Undefined'), isOnline: safeProp('isOnline', fuse).getOrElse('true') };
        break;

      case 'Info':
        const getInfoData = safeObjectSearch('faultInputs');
        const info = getInfoData(data).getOrElse([]);
        acc[x] = { ...currentComponent, info: info };
        break;

      default:
        /* Do Nothing */
        acc[x] = { ...currentComponent };
        break;
    }
    return acc;
  });
  const getComponent = compose(map(reduce(updateComponentData(schematicComponents, componentsData), {})), safeGetKeysObject);
  return getComponent(schematicComponents).getOrElse({});
});

// updateAnalogValuesSchematic :: Object -> Object -> [Object]
export const updateAnalogValuesSchematic = (schematicModulesAnalogValues, analogValuesData) => {
  const updateComponentData = curry(4, (analogValues, data, acc, x) => {
    const qFormatFactor = 2.5;
    const currentAnalogValue = safeProp(x, analogValues).getOrElse({});
    const getAnalogData = safeObjectSearch(`data.${prop('dataStore', currentAnalogValue)}.${prop('category', currentAnalogValue)}.${prop('name', currentAnalogValue)}`);
    const analogValue = getAnalogData(data).getOrElse({});
    const decimalPoints = Math.floor(safeProp('qFormat', analogValue).getOrElse(2.5) / qFormatFactor);
    const value = safeProp('value', analogValue).getOrElse(-1);
    acc[x] = { ...currentAnalogValue, value: `${value.toFixed(decimalPoints)} ${safeProp('unit', analogValue).getOrElse('')}` };
    return acc;
  });

  const getAnalog = compose(map(reduce(updateComponentData(schematicModulesAnalogValues, analogValuesData), {})), safeGetKeysObject);
  return getAnalog(schematicModulesAnalogValues).getOrElse({});
};

// updateDigitalFlagsSchematic :: Object -> Object -> [Object]
export const updateDigitalFlagsSchematic = (schematicModulesDigitalFlags, digitalFlagsData) => {
  const updateComponentData = curry(4, (digitalFlags, data, acc, x) => {
    const currentDigitalFlag = safeProp(x, digitalFlags).getOrElse({});
    const getDigitalData = safeObjectSearch(`data.${prop('dataStore', currentDigitalFlag)}.${prop('category', currentDigitalFlag)}.${prop('name', currentDigitalFlag)}`);
    const digitalFlag = getDigitalData(data).getOrElse({});
    acc[x] = { ...currentDigitalFlag, status: safeProp('status', digitalFlag).getOrElse(false) };
    return acc;
  });

  const getDigital = compose(map(reduce(updateComponentData(schematicModulesDigitalFlags, digitalFlagsData), {})), safeGetKeysObject);
  return getDigital(schematicModulesDigitalFlags).getOrElse({});
};

// createTextRectangleSymbol :: (a -> b) -> (a -> b) -> a
export const createTextRectangleSymbol = curry(5, (fn1, fn2, acc, x, index) => {
  acc = [...acc, fn1(x, index), fn2(x, index)];
  return acc;
});

// checkRequestResult ::  Object -> Object -> String -> Either a
export const checkRequestResult = curry(3, (error, data, result) => (eq(result, 'NoError') ? Result.Ok(data) : Result.Error(error)));

// languageSelection :: String -> [String]
export const languageSelection = (language = 'en') => {
  const indexPosition = language.indexOf('-');
  return deq(indexPosition, -1) ? language.substring(0, indexPosition) : language;
};
