interface IFileData {
    expectedString: string;
    type: string;
    name: string;
}

export const prepareToExportData = (filedata: IFileData, reference: React.RefObject<HTMLAnchorElement>): void => {
    const exportData = new Blob([filedata.expectedString], { type: filedata.type });
    reference.current!.href = URL.createObjectURL(exportData);
    reference.current!.download = filedata.name;
    reference.current!.click();
}

export const prepareToExportFile = (url: string, reference: React.RefObject<HTMLAnchorElement>): void => {
    reference.current!.href = url;
    reference.current!.click();
}

export const handleRedirect = (view: string): void => {
    const MUAppPort = 1443;
    window.location.href = `https://${window.location.hostname}:${MUAppPort}/#/${view}`;
}

export const handleRedirectToUpdateReceiver = (): void => {
    const updateReceiverPort = 443;
    window.location.href = `https://${window.location.hostname}:${updateReceiverPort}/#softwareupdate`;
}

export const handleRedirectUpdater = (port: number): void => {
    window.location.href = `https://${window.location.hostname}:${port}`;
}